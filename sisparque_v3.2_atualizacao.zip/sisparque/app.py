import os
import time
import shutil
import json
import re
import platform
import subprocess
import ipaddress
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import wraps
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort, jsonify, session, g
from markupsafe import Markup
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import (
    db, Usuario, Maquina, OpcaoConfig, TIPOS_OPCAO, RotuloCategoria,
    Switch, Impressora, ContatoTI, ContatoSwitch, Telefone, ContatoTelefonia, ConfiguracaoSistema,
    HistoricoManutencao, LogExclusao, CAMPOS_FIXOS_POR_TIPO, ColunaOculta, CampoExtra,
    MAQUINA_CAMPOS_VIA_CONFIGURACOES, MAQUINA_CAMPOS_OBRIGATORIOS, OrdemColuna,
    ModuloPersonalizado, RegistroModulo, ItemMenuConfig, NIVEIS_RCC, LogAuditoria, AbaPagina,
    seed_admin,
)
from pdf_reports import (
    gerar_pdf_maquinas, gerar_pdf_relatorio_setor, gerar_pdf_grafico_setor, gerar_pdf_modulo,
    gerar_etiqueta_maquina, gerar_etiqueta_switch, definir_tema_pdf,
    dados_maquinas, dados_modulo, dados_contatos,
)
from io import BytesIO

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
def _chave_secreta():
    """Chave que assina o cookie de login. Se ela fosse fixa no código, alguém que
    tivesse uma cópia do projeto poderia "fabricar" um login sem senha. Por isso:
    usa a variável de ambiente, se existir; senão cria UMA vez uma chave aleatória
    no arquivo .chave_secreta (só o servidor lê) e reaproveita nas próximas vezes."""
    if os.environ.get("SISPARQUE_SECRET_KEY"):
        return os.environ["SISPARQUE_SECRET_KEY"]
    caminho = os.path.join(BASE_DIR, ".chave_secreta")
    try:
        if os.path.exists(caminho):
            with open(caminho) as f:
                chave = f.read().strip()
                if len(chave) >= 32:
                    return chave
        import secrets
        chave = secrets.token_hex(32)
        try:
            # "x" = só cria se não existir (se 2 processos subirem juntos, ficam com a mesma chave)
            with open(caminho, "x") as f:
                f.write(chave)
            try:
                os.chmod(caminho, 0o600)
            except OSError:
                pass
            return chave
        except FileExistsError:
            import time
            time.sleep(0.2)
            with open(caminho) as f:
                return f.read().strip()
    except OSError:
        # sem permissão de escrita: chave aleatória só enquanto o serviço estiver rodando
        import secrets
        return secrets.token_hex(32)


app.config["SECRET_KEY"] = _chave_secreta()
app.config["SESSION_COOKIE_HTTPONLY"] = True      # o JavaScript da página não lê o cookie de login
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"     # outro site não consegue usar o login de quem está logado
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "sisparque.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# Trilha de auditoria num arquivo separado: importar/restaurar o banco principal não apaga a trilha
app.config["SQLALCHEMY_BINDS"] = {"auditoria": "sqlite:///" + os.path.join(BASE_DIR, "auditoria.db")}

db.init_app(app)


# ---- Robustez do banco (SQLite) para muitos usuários ao mesmo tempo ----
# busy_timeout: se dois salvarem no mesmo instante, o segundo ESPERA a vez (até 15 s)
# em vez de dar erro "database is locked". O banco fica num arquivo SÓ (modo DELETE,
# não WAL): copiar o sisparque.db pelo WinSCP como backup continua pegando tudo.
from sqlalchemy import event as _sa_event  # noqa: E402
from sqlalchemy.engine import Engine as _SaEngine  # noqa: E402


@_sa_event.listens_for(_SaEngine, "connect")
def _sqlite_robusto(conexao, _registro):
    if conexao.__class__.__module__.startswith("sqlite3"):
        cur = conexao.cursor()
        try:
            cur.execute("PRAGMA journal_mode=DELETE")
            cur.execute("PRAGMA busy_timeout=15000")
        finally:
            cur.close()


from auditoria import iniciar_auditoria, registrar_evento  # noqa: E402
iniciar_auditoria()

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Faça login para continuar."


# Módulo Recebimentos (anotação de material que chega — pasta recebimentos/)
from recebimentos import recebimentos_bp
app.register_blueprint(recebimentos_bp)


@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))


from planilhas import planilha_de_tabela, definir_tema_planilha, pasta_xlsx, pasta_ods
from io import BytesIO as _BytesIO

_MIME_PLANILHA = {
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "ods": "application/vnd.oasis.opendocument.spreadsheet",
}


def _exportar_tabela(titulo, dados, nome_base, gerar_pdf, contatos=None):
    """Mesma lista em 3 formatos: ?formato=pdf (padrão), xlsx (Excel) ou ods (LibreOffice Calc).
    As planilhas já saem configuradas para imprimir (A4, ajustada à largura da folha,
    cabeçalho repetido em toda página, filtro e cabeçalho congelado)."""
    formato = request.args.get("formato", "pdf")
    if formato in _MIME_PLANILHA:
        p = planilha_de_tabela(titulo, dados, dados_contatos(contatos) if contatos else None)
        conteudo = p.xlsx() if formato == "xlsx" else p.ods()
        return send_file(_BytesIO(conteudo), as_attachment=True,
                         download_name=f"{nome_base}.{formato}", mimetype=_MIME_PLANILHA[formato])
    return send_file(gerar_pdf(), as_attachment=True,
                     download_name=f"{nome_base}.pdf", mimetype="application/pdf")


@app.before_request
def _tema_dos_pdfs():
    # PDFs saem com a mesma cor escolhida em Aparência (verde musgo ou azul marinho)
    if request.endpoint and "pdf" in request.endpoint:
        cfg = ConfiguracaoSistema.query.first()
        definir_tema_pdf(cfg.modo_visual if cfg else "padrao")
        definir_tema_planilha(cfg.modo_visual if cfg else "padrao")


# ------------------------------------------------------------------
# Segurança: sessão encerra sozinha depois de X minutos sem uso.
# O servidor guarda a hora da última atividade na sessão e confere a cada
# acesso — não adianta deixar a aba aberta. O navegador mostra o cronômetro.
TEMPO_INATIVIDADE_PADRAO = 15
# Pedidos automáticos em segundo plano (ex: Status da Rede atualizando sozinho)
# NÃO contam como atividade — senão a sessão nunca expiraria com aquela tela aberta.
ENDPOINTS_FUNDO = {"status_ping_maquinas", "sessao_status"}
ENDPOINTS_LIVRES = {"static", "login", "logout", "sessao_expirada", "index", "saude"}


def minutos_inatividade():
    cfg = ConfiguracaoSistema.query.first()
    v = cfg.tempo_inatividade_min if cfg and cfg.tempo_inatividade_min is not None else TEMPO_INATIVIDADE_PADRAO
    return max(0, int(v))


@app.before_request
def _checar_inatividade():
    if not current_user.is_authenticated or request.endpoint in ENDPOINTS_LIVRES or request.endpoint is None:
        return None
    limite = minutos_inatividade() * 60
    agora = time.time()
    ultima = session.get("ultima_atividade")
    if limite and ultima and agora - ultima > limite:
        registrar_evento("Sessão encerrada", "Acesso", "Saída automática por inatividade")
        logout_user()
        session.pop("ultima_atividade", None)
        if request.endpoint in ("sessao_ping", "sessao_status") or request.is_json \
                or request.headers.get("X-Requested-With") == "fetch":
            return {"ok": False, "expirou": True}, 401
        flash("Sua sessão foi encerrada por inatividade. Entre de novo.", "erro")
        return redirect(url_for("login"))
    if request.endpoint not in ENDPOINTS_FUNDO or not ultima:
        session["ultima_atividade"] = agora
    return None


@app.route("/saude")
def saude():
    """Pra monitoramento: responde 200 se o sistema e os bancos estão de pé (sem login, sem dados)."""
    try:
        db.session.execute(db.text("SELECT 1"))
        with db.engines["auditoria"].connect() as conn:
            conn.execute(db.text("SELECT 1"))
        return {"ok": True, "versao": VERSAO_SISTEMA}
    except Exception:
        return {"ok": False}, 503


@app.route("/sessao/ping", methods=["POST"])
@login_required
def sessao_ping():
    """O navegador chama quando a pessoa está mexendo na tela (ou clica em 'Continuar conectado')."""
    return {"ok": True, "restante": minutos_inatividade() * 60}


@app.route("/sessao/status")
@login_required
def sessao_status():
    """Quanto falta pela conta do SERVIDOR (sem renovar) — evita derrubar quem está usando outra aba."""
    limite = minutos_inatividade() * 60
    ultima = session.get("ultima_atividade") or time.time()
    return {"ok": True, "restante": max(0, int(limite - (time.time() - ultima))) if limite else None}


@app.route("/sessao/expirada")
def sessao_expirada():
    if current_user.is_authenticated:
        registrar_evento("Sessão encerrada", "Acesso", "Saída automática por inatividade")
        logout_user()
    session.pop("ultima_atividade", None)
    flash("Sua sessão foi encerrada por inatividade. Entre de novo.", "erro")
    return redirect(url_for("login"))


@app.context_processor
def injetar_config_sistema():
    return dict(config_sistema=ConfiguracaoSistema.query.first(),
                tempo_inatividade_seg=(minutos_inatividade() * 60 if current_user.is_authenticated else 0))


def cores_setor():
    """Retorna um dict {nome_do_setor: '#hexcolor'} para colorir as etiquetas."""
    return {o.valor: o.cor or "#004080" for o in OpcaoConfig.query.filter_by(tipo="setor").all()}


def texto_contraste(hexcolor):
    """Decide se o texto da etiqueta deve ser branco ou preto conforme o fundo."""
    try:
        h = hexcolor.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        luminancia = (0.299 * r + 0.587 * g + 0.114 * b)
        return "#000000" if luminancia > 150 else "#ffffff"
    except Exception:
        return "#ffffff"


app.jinja_env.globals["texto_contraste"] = texto_contraste

PALETA_GRAFICO = [
    "#004080", "#c2185b", "#0288d1", "#f57c00", "#00796b", "#7b1fa2",
    "#c62828", "#2e7d32", "#455a64", "#6a1b9a", "#ef6c00", "#00695c",
]


def montar_grafico_pizza(dados):
    """
    dados: lista de tuplas (label, quantidade, cor).
    Retorna (gradiente_css, legenda, total) prontos para o template, com percentuais.
    """
    total = sum(q for _, q, _ in dados)
    legenda = []
    stops = []
    cumulativo = 0.0
    for label, qtd, cor in dados:
        if total == 0:
            continue
        pct = qtd / total * 100
        inicio = cumulativo
        cumulativo += pct
        stops.append(f"{cor} {inicio:.2f}% {cumulativo:.2f}%")
        legenda.append({"label": label, "qtd": qtd, "pct": round(pct, 1), "cor": cor})
    gradiente = "conic-gradient(" + ", ".join(stops) + ")" if stops else None
    return gradiente, legenda, total


def opcoes(tipo):
    """Retorna a lista de valores (strings) cadastrados em Configurações para um tipo."""
    return [o.valor for o in OpcaoConfig.query.filter_by(tipo=tipo).order_by(OpcaoConfig.valor).all()]


def garantir_opcao(tipo, valor):
    """Se o valor digitado for novo, adiciona à lista de sugestões automaticamente."""
    valor = (valor or "").strip()
    if valor and not OpcaoConfig.query.filter_by(tipo=tipo, valor=valor).first():
        db.session.add(OpcaoConfig(tipo=tipo, valor=valor))


def rotulos_categorias():
    """Retorna {tipo: rótulo} - os nomes dos botões de Configurações, editáveis pelo admin."""
    salvos = {r.tipo: r.rotulo for r in RotuloCategoria.query.all()}
    resultado = dict(TIPOS_OPCAO)
    resultado.update(salvos)
    return resultado


app.jinja_env.globals["rotulos_categorias"] = rotulos_categorias


def valores_campos_fixos(row, campos):
    """Monta {chave: valor} dos campos 'de fábrica' de um registro, pra usar no JS de edição."""
    return {chave: getattr(row, chave, None) for chave, _ in campos}


app.jinja_env.globals["valores_campos_fixos"] = valores_campos_fixos


def slugify(texto):
    """Transforma 'Contato Técnico' em 'contato_tecnico', pra usar como chave interna."""
    texto = texto.strip().lower()
    texto = re.sub(r"[àáâãäå]", "a", texto)
    texto = re.sub(r"[èéêë]", "e", texto)
    texto = re.sub(r"[ìíîï]", "i", texto)
    texto = re.sub(r"[òóôõö]", "o", texto)
    texto = re.sub(r"[ùúûü]", "u", texto)
    texto = texto.replace("ç", "c").replace("ñ", "n")
    texto = re.sub(r"[^a-z0-9]+", "_", texto).strip("_")
    return texto or "campo"


def rotulo_campo(tipo, chave, rotulo_padrao):
    """Rótulo (nome de exibição) de um campo de fábrica. Para os campos de Máquina que
    têm lista em Configurações (Setor, Posto, SO...), o nome vem de Configurações — o
    MESMO que aparece no cadastro — pra lista, ficha, Filtrar e PDF ficarem iguais."""
    if tipo == "maquina" and chave in MAQUINA_CAMPOS_VIA_CONFIGURACOES:
        r = RotuloCategoria.query.filter_by(tipo={"departamento_setor": "setor"}.get(chave, chave)).first()
        return r.rotulo if r else rotulo_padrao
    r = RotuloCategoria.query.filter_by(tipo=f"campo_{tipo}_{chave}").first()
    return r.rotulo if r else rotulo_padrao


def rotulos_renomeados_maquina():
    """{campo: nome} só dos campos de Máquina que o admin RENOMEOU (pro cabeçalho do PDF/planilha)."""
    saida = {}
    for chave, padrao in CAMPOS_FIXOS_POR_TIPO["maquina"]:
        r = rotulo_campo("maquina", chave, padrao)
        if r != padrao:
            saida[chave] = r
    return saida


def campos_visiveis(tipo):
    """Lista [(chave, rotulo), ...] dos campos 'de fábrica' NÃO ocultados, na ordem
    customizada pelo admin (tela Editar Colunas → mover pra cima/baixo), ou na ordem
    original declarada em CAMPOS_FIXOS_POR_TIPO se ainda não foi customizada."""
    ocultos = {c.chave for c in ColunaOculta.query.filter_by(tipo=tipo).all()}
    fixos = CAMPOS_FIXOS_POR_TIPO.get(tipo, [])
    ordem_padrao = {chave: i for i, (chave, _) in enumerate(fixos)}
    ordem_customizada = {o.chave: o.ordem for o in OrdemColuna.query.filter_by(tipo=tipo).all()}
    itens = [
        (chave, rotulo_campo(tipo, chave, rotulo_padrao))
        for chave, rotulo_padrao in fixos
        if chave not in ocultos
    ]
    itens.sort(key=lambda item: ordem_customizada.get(item[0], ordem_padrao.get(item[0], 0)))
    return itens


def campos_extra_lista(tipo):
    """Lista de campos personalizados (criados pelo usuário) de um tipo, em ordem."""
    return CampoExtra.query.filter_by(tipo=tipo).order_by(CampoExtra.ordem, CampoExtra.id).all()


ICONES_MENU = {
    "lista": '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
    "telefone": '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
    "pasta": '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    "usuarios": '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "estrela": '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    "caixa": '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
    "email": '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
    "etiqueta": '<path d="M20.59 13.41 13.42 20.59a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
    "ferramenta": '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
    "escudo": '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    "grafico": '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
    "bandeira": '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
    "entrada": '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    "mais": '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    "painel": '<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',
    "rede": '<rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
    "sol": '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
    "menu": '<line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="14" y2="18"/>',
    "engrenagem": '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    "banco": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
    "cadeado": '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    "relogio": '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    "livro": '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    "grade": '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
    "monitor": '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
    "impressora": '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    "wifi": '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
    "globo": '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    "cpu": '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
    "documento": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    "alerta": '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "chave": '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.78 7.78 5.5 5.5 0 0 1 7.78-7.78zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
    "mapa": '<polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>',
    "casa": '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    "lixeira": '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
}
# Versão do sistema (aparece no menu lateral). Cada atualização sobe 0.1: 3.0 → 3.1 → ... → 3.9 → 4.0
VERSAO_SISTEMA = "3.2"
app.jinja_env.globals["VERSAO_SISTEMA"] = VERSAO_SISTEMA
app.jinja_env.globals["ICONES_MENU"] = ICONES_MENU
app.jinja_env.globals["NIVEIS_RCC"] = NIVEIS_RCC


def estrutura_menu():
    """Lista unificada dos itens 'de negócio' do menu lateral (LVA/Switch/Impressoras/
    Telefonia + módulos personalizados criados pelo admin), já com nome/visibilidade
    customizados aplicados. Os fixos nunca são removidos daqui (só ocultados) porque
    têm rotinas próprias (contatos, PDF, filtro especial, etc.) — só os personalizados
    podem ser excluídos de verdade."""
    fixos_padrao = [
        ("cadastrar", "Cadastrar Máquina", "mais", "cadastrar_maquina", {}),
        ("listar", "Listar Máquinas", "lista", "listar_maquinas", {}),
        ("painel", "Painel", "painel", "dashboard", {}),
        ("status_rede", "Rede", "rede", "painel_rede", {}),
        ("lva", "LVA", "lixeira", "listar_maquinas", {"lva": "Sim"}),
        ("switch", "Switch", "caixa", "switch_page", {}),
        ("impressoras", "Impressoras", "pasta", "impressoras_page", {}),
        ("telefonia", "Telefonia", "telefone", "telefonia_page", {}),
        ("recebimentos", "Recebimentos", "entrada", "recebimentos.lista", {}),
        ("aparencia", "Aparência", "sol", "config_aparencia", {}),
    ]
    # Itens da seção "Administração" (só o administrador vê)
    fixos_admin = [
        ("auditoria", "Auditoria", "escudo", "admin_auditoria", {}),
        ("ger_menu", "Gerenciar Menu", "menu", "admin_menu", {}),
        ("usuarios", "Usuários", "usuarios", "admin_usuarios", {}),
        ("configuracoes", "Configurações", "engrenagem", "admin_opcoes", {"tipo": "setor"}),
        ("banco", "Banco de Dados", "banco", "admin_banco_dados", {}),
        ("tela_login", "Tela de Login", "cadeado", "admin_textos_login", {}),
        ("exclusoes", "Histórico de Exclusões", "relogio", "admin_log_exclusoes", {}),
    ]
    config = {c.chave: c for c in ItemMenuConfig.query.all()}
    itens = []
    for i, (secao, chave, nome_padrao, icone_padrao, endpoint, kwargs) in enumerate(
            [("principal",) + f for f in fixos_padrao] + [("admin",) + f for f in fixos_admin]):
        c = config.get(chave)
        if chave == "lva":
            ativo = request.endpoint == endpoint and request.args.get("lva") == "Sim"
        elif chave == "listar":
            ativo = request.endpoint == endpoint and request.args.get("lva") != "Sim"
        elif chave == "status_rede":
            ativo = request.endpoint in ("painel_rede", "faixa_ip")
        elif chave == "recebimentos":
            ativo = (request.endpoint or "").startswith("recebimentos.")
        elif chave == "configuracoes":
            ativo = request.endpoint in ("admin_opcoes", "admin_campos")
        elif chave == "usuarios":
            ativo = request.endpoint in ("admin_usuarios", "admin_cadastrar_usuario", "admin_editar_usuario")
        else:
            ativo = request.endpoint == endpoint
        itens.append({
            "origem": "fixo", "chave": chave, "secao": "principal", "so_admin": secao == "admin",
            "so_geral": chave == "auditoria",
            "nome": (c.nome if c and c.nome else nome_padrao),
            "icone": (c.icone if c and c.icone and c.icone in ICONES_MENU else icone_padrao),
            "url": url_for(endpoint, **kwargs), "ativo": ativo,
            # "Gerenciar Menu" nunca some (senão não teria como mostrar os outros de volta)
            "visivel": True if chave == "ger_menu" else (c.visivel if c else True),
            # ordem fixa (a tela Gerenciar Menu não reordena os fixos; usar c.ordem
            # fazia o item renomeado/ocultado pular pro topo, pois o padrão do banco é 0)
            "ordem": i,
        })
    for m in ModuloPersonalizado.query.all():
        itens.append({
            "origem": "personalizado", "chave": m.slug, "nome": m.nome, "secao": "principal", "so_admin": False,
            "so_geral": False,
            "icone": m.icone, "url": url_for("modulo_generico", slug=m.slug),
            "ativo": request.endpoint == "modulo_generico" and request.view_args and request.view_args.get("slug") == m.slug,
            "modulo_id": m.id, "visivel": True, "ordem": 100 + (m.ordem or 0),
        })
    # Ordem escolhida pelo admin (↑/↓). Item sem posição salva (ex.: criado depois)
    # vai para o fim, na ordem padrão.
    for it in itens:
        c = config.get(_chave_ordem_menu(it))
        it["posicao"] = c.posicao if c and c.posicao is not None else None
    # Menu agora é UMA lista só (sem a divisão "Administração"). Posições gravadas
    # a partir da v3.3 começam em 1000; posições antigas (por seção) são convertidas
    # na hora, com os itens de admin depois dos demais — até você arrastar e salvar.
    def _chave_ordem(i):
        p = i["posicao"]
        if p is None:
            return 10000 + i["ordem"]
        if p >= 1000:
            return p
        return p + (500 if i["so_admin"] else 0)
    itens.sort(key=lambda i: (_chave_ordem(i), i["ordem"]))
    return itens


CHAVES_MENU_FIXAS = ("cadastrar", "listar", "painel", "status_rede", "lva", "switch", "impressoras",
                     "telefonia", "recebimentos", "aparencia",
                     "auditoria", "ger_menu", "usuarios", "configuracoes", "banco", "tela_login", "exclusoes")


def _chave_ordem_menu(item):
    return item["chave"] if item["origem"] == "fixo" else "mod:" + item["chave"]


app.jinja_env.globals["estrutura_menu"] = estrutura_menu

# Campos que nunca podem ser ocultados em Editar Colunas, por tipo.
CAMPOS_OBRIGATORIOS_POR_TIPO = {"maquina": MAQUINA_CAMPOS_OBRIGATORIOS, "recebimento": {"material"}}


def estrutura_colunas(tipo, incluir_ocultos=False):
    """Lista ÚNICA e reordenável de colunas de um tipo — campos 'de fábrica' + colunas
    personalizadas, entrelaçados na mesma sequência, na ordem definida pelo admin em
    Editar Colunas (mover ↑/↓). Cada item é um dict:
    {'origem': 'fixo'|'extra', 'chave': <chave lógica p/ ordenar>, 'rotulo': ...,
     'campo_fixo': <chave real do modelo, só se origem='fixo'>,
     'campo_extra': <objeto CampoExtra, só se origem='extra'>, 'oculto': bool}
    A chave lógica das colunas extras é prefixada com 'extra:' pra nunca colidir com
    a chave de um campo fixo. Por padrão pula os ocultados (uso nas telas de listagem);
    com incluir_ocultos=True eles entram também, marcados (uso em Editar Colunas)."""
    ocultos = {c.chave for c in ColunaOculta.query.filter_by(tipo=tipo).all()}
    fixos = CAMPOS_FIXOS_POR_TIPO.get(tipo, [])
    extras = campos_extra_lista(tipo)

    itens = []
    for chave, rotulo_padrao in fixos:
        oculto = chave in ocultos
        if oculto and not incluir_ocultos:
            continue
        itens.append({
            "origem": "fixo", "chave": chave, "rotulo": rotulo_campo(tipo, chave, rotulo_padrao),
            "campo_fixo": chave, "oculto": oculto,
        })
    for e in extras:
        itens.append({
            "origem": "extra", "chave": f"extra:{e.chave}", "rotulo": e.nome,
            "campo_extra": e, "oculto": False,
        })

    ordem_padrao = {item["chave"]: i for i, item in enumerate(itens)}
    ordem_customizada = {o.chave: o.ordem for o in OrdemColuna.query.filter_by(tipo=tipo).all()}
    itens.sort(key=lambda item: ordem_customizada.get(item["chave"], ordem_padrao[item["chave"]]))
    return itens


# Usado pelo módulo Recebimentos (colunas dos itens vêm do Editar Colunas)
app.extensions["sisparque_colunas"] = lambda tipo: estrutura_colunas(tipo)


def carregar_extras(registro):
    """Lê o JSON de campos extra de um Switch/Impressora/Telefone."""
    if not registro or not registro.extras:
        return {}
    try:
        return json.loads(registro.extras)
    except (ValueError, TypeError):
        return {}


def registrar_exclusao(tipo_objeto, descricao, dados=None):
    """Grava no log de auditoria quem excluiu o quê. Se 'dados' (dict) for passado,
    guarda um snapshot dos campos do registro pra permitir restaurar depois."""
    nome_usuario = current_user.display_name if current_user.is_authenticated else "desconhecido"
    dados_json = json.dumps(dados, ensure_ascii=False) if dados is not None else None
    db.session.add(LogExclusao(
        tipo_objeto=tipo_objeto, descricao=descricao, usuario_nome=nome_usuario, dados_json=dados_json,
    ))


def _snapshot_modelo(instancia, ignorar=("id", "criado_em")):
    """Serializa os campos de uma instância de modelo (exceto id/criado_em) num dict simples,
    pra guardar no log de exclusão e permitir restaurar depois."""
    return {
        c.name: getattr(instancia, c.name)
        for c in instancia.__table__.columns
        if c.name not in ignorar
    }


def admin_required(f):
    @wraps(f)
    def decorado(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("Acesso restrito ao administrador.", "erro")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorado


LIMITE_SENHA_ERRADA_PADRAO = 5   # erros seguidos até bloquear (padrão)
MINUTOS_BLOQUEIO_PADRAO = 1      # tempo de bloqueio em minutos (padrão)


def regras_bloqueio():
    """(tentativas, minutos) — o Administrador geral ajusta em Tela de Login → Segurança."""
    cfg = ConfiguracaoSistema.query.first()
    tent = cfg.bloqueio_tentativas if cfg and cfg.bloqueio_tentativas else LIMITE_SENHA_ERRADA_PADRAO
    minu = cfg.bloqueio_minutos if cfg and cfg.bloqueio_minutos else MINUTOS_BLOQUEIO_PADRAO
    return max(3, min(20, int(tent))), max(1, min(1440, int(minu)))


def _txt_minutos(n):
    return "1 minuto" if n == 1 else f"{n} minutos"


def existe_geral():
    return Usuario.query.filter_by(is_geral=True).first() is not None


def eh_geral():
    return current_user.is_authenticated and bool(getattr(current_user, "is_geral", False))


def pode_gerir_admins():
    """Só o Administrador geral torna/tira admin. Enquanto ninguém foi definido como
    Administrador geral (logo depois de atualizar), os admins seguem como antes."""
    return eh_geral() or (current_user.is_authenticated and current_user.is_admin and not existe_geral())


def geral_required(f):
    @wraps(f)
    def decorado(*args, **kwargs):
        if not eh_geral():
            flash("Acesso restrito ao Administrador geral.", "erro")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorado


app.jinja_env.globals["eh_geral"] = eh_geral


def editar_colunas_required(f):
    """Exclusivo do admin — a permissão delegável que existia antes foi
    removida a pedido: usuário padrão não acessa Editar Colunas/cores
    de jeito nenhum, mesmo que já tenha tido essa permissão concedida no
    passado (o campo antigo 'pode_editar_colunas' não é mais checado aqui)."""
    @wraps(f)
    def decorado(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("Acesso restrito ao administrador.", "erro")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorado


def tema_required(f):
    """Aparência do sistema é liberada pra qualquer usuário logado, admin ou
    padrão — não precisa de permissão especial."""
    @wraps(f)
    def decorado(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorado


# ---------------------------------------------------------------- AUTH ----

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# TEXTOS DA TELA DE LOGIN — tudo editável pelo admin (Configurações → Textos da
# Tela de Login). Guardado em JSON; o que não foi editado usa o padrão abaixo.
# ---------------------------------------------------------------------------
TEXTOS_LOGIN_PADRAO = {
    "nome_1": "SIS", "nome_2": "PARQUE",
    "subtitulo": "Sistema de Controle de Parque Computacional", "subtitulo_exibir": True,
    "slogan": "Gestão do parque de informática da OM", "slogan_exibir": True,
    "recurso1": "Cadastro de computadores", "recurso1_exibir": True,
    "recurso2": "Consulta e localização", "recurso2_exibir": True,
    "recurso3": "Relatórios e planilhas", "recurso3_exibir": True,
    "recurso4": "Controle de acesso", "recurso4_exibir": True,
    "circulos_exibir": True,
    "brasao_tamanho": 190,
    "titulo": "Acesso ao sistema", "titulo_exibir": True,
    "dica": "Entre com seu NIP e senha para continuar.", "dica_exibir": True,
    "rotulo_usuario": "NIP", "placeholder_usuario": "00.0000.00",
    "rotulo_senha": "Senha", "placeholder_senha": "Digite sua senha",
    "botao": "ENTRAR",
    "rodape": "Uso restrito a usuários autorizados", "rodape_exibir": True,
}
_CHAVES_EXIBIR_LOGIN = [k for k, v in TEXTOS_LOGIN_PADRAO.items() if isinstance(v, bool)]


def textos_login():
    t = dict(TEXTOS_LOGIN_PADRAO)
    cfg = ConfiguracaoSistema.query.first()
    if cfg and cfg.login_textos:
        try:
            salvos = json.loads(cfg.login_textos)
            t.update({k: v for k, v in salvos.items() if k in TEXTOS_LOGIN_PADRAO})
        except (ValueError, TypeError):
            pass
    return t


app.jinja_env.globals["textos_login"] = textos_login


@app.route("/admin/configuracao/tela-login/textos", methods=["GET", "POST"])
@login_required
@admin_required
def admin_textos_login():
    cfg = ConfiguracaoSistema.query.first() or ConfiguracaoSistema()
    if request.method == "POST":
        if request.form.get("acao") == "restaurar":
            cfg.login_textos = None
            flash("Textos da tela de login voltaram ao padrão.", "ok")
        else:
            novo = {}
            for chave, padrao in TEXTOS_LOGIN_PADRAO.items():
                if isinstance(padrao, bool):
                    novo[chave] = request.form.get(chave) == "1"
                elif isinstance(padrao, int):
                    try:
                        novo[chave] = max(80, min(320, int(request.form.get(chave, padrao))))
                    except ValueError:
                        novo[chave] = padrao
                else:
                    novo[chave] = request.form.get(chave, "").strip()
            # campos que não podem ficar vazios (senão o login fica sem botão/rótulo)
            for obrig in ("rotulo_usuario", "rotulo_senha", "botao"):
                if not novo[obrig]:
                    novo[obrig] = TEXTOS_LOGIN_PADRAO[obrig]
            cfg.login_textos = json.dumps(novo, ensure_ascii=False)
            flash("Tela de login atualizada.", "ok")
        if not cfg.id:
            db.session.add(cfg)
        db.session.commit()
        return redirect(url_for("admin_textos_login", _anchor="textos"))
    return render_template("admin_textos_login.html", t=textos_login(),
                           cfg=ConfiguracaoSistema.query.first() or ConfiguracaoSistema())


@app.route("/admin/seguranca/bloqueio", methods=["POST"])
@login_required
@geral_required
def admin_regras_bloqueio():
    cfg = ConfiguracaoSistema.query.first()
    if not cfg:
        cfg = ConfiguracaoSistema()
        db.session.add(cfg)
    try:
        cfg.bloqueio_tentativas = max(3, min(20, int(request.form.get("tentativas", LIMITE_SENHA_ERRADA_PADRAO))))
        cfg.bloqueio_minutos = max(1, min(1440, int(request.form.get("minutos", MINUTOS_BLOQUEIO_PADRAO))))
    except ValueError:
        flash("Valores inválidos.", "erro")
        return redirect(url_for("admin_textos_login", _anchor="seguranca"))
    db.session.commit()
    flash(f"Pronto: {cfg.bloqueio_tentativas} senhas erradas seguidas bloqueiam o usuário por {_txt_minutos(cfg.bloqueio_minutos)}.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="seguranca"))


@app.route("/admin/seguranca/inatividade", methods=["POST"])
@login_required
@geral_required
def admin_tempo_inatividade():
    cfg = ConfiguracaoSistema.query.first()
    if not cfg:
        cfg = ConfiguracaoSistema()
        db.session.add(cfg)
    try:
        minutos = int(request.form.get("minutos", TEMPO_INATIVIDADE_PADRAO))
    except ValueError:
        minutos = TEMPO_INATIVIDADE_PADRAO
    cfg.tempo_inatividade_min = max(0, min(480, minutos))
    db.session.commit()
    if cfg.tempo_inatividade_min:
        flash(f"Pronto: depois de {cfg.tempo_inatividade_min} minuto(s) sem uso, o sistema volta pra tela de login.", "ok")
    else:
        flash("Encerramento por inatividade desligado.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="seguranca"))


@app.route("/login", methods=["GET", "POST"])
def login():
    # ?previa=1: o admin vê a tela de login dentro da página de edição (sem sair do sistema)
    previa = request.args.get("previa") == "1" and current_user.is_authenticated and current_user.is_admin
    if current_user.is_authenticated and not previa:
        return redirect(url_for("dashboard"))
    if previa:
        return render_template("login.html", previa=True)
    if request.method == "POST":
        nip = request.form.get("nip", "").strip()
        senha = request.form.get("senha", "")
        usuario = Usuario.query.filter_by(nip=nip).first()
        agora = datetime.now()
        if usuario and usuario.bloqueado_ate and usuario.bloqueado_ate > agora:
            minutos = max(1, int((usuario.bloqueado_ate - agora).total_seconds() // 60) + 1)
            registrar_evento("Bloqueado", "Acesso", f"Tentativa de entrar com o NIP {nip} enquanto bloqueado",
                             usuario=(usuario.id, usuario.display_name))
            flash(f"Este usuário está bloqueado por excesso de senhas erradas. Tente de novo em {_txt_minutos(minutos)} "
                  "ou peça a um administrador para desbloquear.", "erro")
            return render_template("login.html")
        if usuario and usuario.check_senha(senha):
            usuario.falhas_login = 0
            usuario.bloqueado_ate = None
            db.session.commit()
            login_user(usuario)
            session["ultima_atividade"] = time.time()
            registrar_evento("Entrou", "Acesso", "Login no sistema", usuario=(usuario.id, usuario.display_name))
            return redirect(url_for("dashboard"))
        if usuario:
            LIMITE_SENHA_ERRADA, MINUTOS_BLOQUEIO = regras_bloqueio()
            usuario.falhas_login = (usuario.falhas_login or 0) + 1
            restam = LIMITE_SENHA_ERRADA - usuario.falhas_login
            if restam <= 0:
                usuario.bloqueado_ate = agora + timedelta(minutes=MINUTOS_BLOQUEIO)
                usuario.falhas_login = 0
                db.session.commit()
                registrar_evento("Bloqueado", "Acesso",
                                 f"Usuário bloqueado por {_txt_minutos(MINUTOS_BLOQUEIO)} após {LIMITE_SENHA_ERRADA} senhas erradas",
                                 usuario=(usuario.id, usuario.display_name))
                flash(f"Senha errada {LIMITE_SENHA_ERRADA} vezes seguidas. Por segurança, este usuário ficou bloqueado "
                      f"por {_txt_minutos(MINUTOS_BLOQUEIO)}.", "erro")
                return render_template("login.html")
            db.session.commit()
            registrar_evento("Senha errada", "Acesso", f"Senha errada para o NIP {nip} ({usuario.falhas_login}ª seguida)",
                             usuario=(usuario.id, usuario.display_name))
            if restam <= 2:
                flash(f"NIP ou senha inválidos. Mais {restam} tentativa(s) errada(s) e o usuário será bloqueado por "
                      f"{_txt_minutos(MINUTOS_BLOQUEIO)}.", "erro")
                return render_template("login.html")
        else:
            registrar_evento("Senha errada", "Acesso", f"Tentativa com NIP que não existe: {nip[:30]}", usuario=(None, "Desconhecido"))
        flash("NIP ou senha inválidos.", "erro")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    registrar_evento("Saiu", "Acesso", "Saiu do sistema")
    logout_user()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    filtro_setor = request.args.get("setor", "Todos")
    filtro_so = request.args.get("so", "Todos")
    dados = _dados_dashboard(filtro_setor, filtro_so)
    # Lista curta para o clique no gráfico (só leitura): quem é cada máquina
    q = db.session.query(Maquina.id, Maquina.nome_completo, Maquina.posto_graduacao, Maquina.ip,
                         Maquina.num_maquina, Maquina.departamento_setor, Maquina.sistema_operacional)
    if filtro_setor != "Todos":
        q = q.filter(Maquina.departamento_setor == filtro_setor)
    if filtro_so != "Todos":
        q = q.filter(Maquina.sistema_operacional == filtro_so)
    mini = [{"id": r[0], "n": r[1] or "", "p": r[2] or "", "ip": (r[3] or "").strip(), "mq": r[4] or "",
             "st": r[5] or "", "so": r[6] or ""} for r in q]
    mini.sort(key=lambda m: chave_ordenacao_ip(m["ip"]))
    hoje = datetime.now().date()
    revit_vencidas = sum(1 for m in Maquina.query.with_entities(Maquina.data_revitalizacao, Maquina.lva)
                         if revitalizacao_vencida(m, hoje))
    return render_template("dashboard.html", agora=datetime.now(), dashboard=dados, maquinas_mini=mini,
                           revit_vencidas=revit_vencidas)


@app.route("/relatorio")
@login_required
def relatorio_setor():
    """Mantido por compatibilidade — o Painel (/dashboard) já mostra o mesmo
    conteúdo pra quem é admin."""
    return redirect(url_for("dashboard", **request.args))


# ------------------------------------------------------------ MÁQUINAS ----

CAMPOS_MAQUINA = [
    "nome_completo", "nip", "posto_graduacao", "corpo_quadro", "especialidade",
    "ip", "num_maquina", "mac", "lacre", "processador_fabricante",
    "processador_modelo", "data_compra",
    "data_revitalizacao", "departamento_setor", "disponivel", "lva", "num_pat",
    "sistema_operacional", "memoria_tipo", "memoria_qtd", "armazenamento_tipo",
    "armazenamento_capacidade", "armazenamento_interface", "teclado", "mouse",
    "nivel_rcc",
]


def rotulos_campos_maquina():
    """Rótulos (editáveis via Editar Colunas) dos campos de Máquina que NÃO são
    geridos em Configurações — ex: NIP, IP, Num Patrimonial, datas."""
    return {
        chave: rotulo_campo("maquina", chave, rotulo_padrao)
        for chave, rotulo_padrao in CAMPOS_FIXOS_POR_TIPO["maquina"]
    }


def campos_ocultos_maquina():
    return {c.chave for c in ColunaOculta.query.filter_by(tipo="maquina").all()}


def contexto_form_maquina(maquina=None):
    return dict(
        postos=opcoes("posto_graduacao"), corpos=opcoes("corpo_quadro"),
        especialidades=opcoes("especialidade"),
        fabricantes=opcoes("processador_fabricante"), modelos_proc=opcoes("processador_modelo"),
        setores=opcoes("setor"), sistemas=opcoes("sistema_operacional"),
        memoria_tipos=opcoes("memoria_tipo"), memoria_qtds=opcoes("memoria_qtd"),
        armazenamento_tipos=opcoes("armazenamento_tipo"),
        armazenamento_capacidades=opcoes("armazenamento_capacidade"),
        armazenamento_interfaces=opcoes("armazenamento_interface"),
        disponiveis=opcoes("disponivel"), lvas=opcoes("lva"), sim_nao=opcoes("sim_nao"),
        lacres=opcoes("lacre"),
        maquina=maquina,
        ocultos=campos_ocultos_maquina(),
        rotulos_campos=rotulos_campos_maquina(),
        extras_maquina=campos_extra_lista("maquina"),
        extras_valores=carregar_extras(maquina) if maquina else {},
    )


def equipamentos_com_ip(ip, ignorar_tipo=None, ignorar_id=None):
    """Quem JÁ usa este IP no sistema inteiro — máquinas, impressoras e telefones
    (ignorando espaços antes/depois). Na edição, passe o tipo e o id do próprio
    equipamento pra ele não "conflitar com ele mesmo". IP em branco nunca conflita.
    Cada item tem: tipo, id, nome_completo, num_maquina, departamento_setor."""
    from types import SimpleNamespace
    ip = (ip or "").strip()
    if not ip:
        return []
    fontes = [
        ("maquina", "Máquina", Maquina,
         lambda o: o.nome_completo or "sem nome", lambda o: o.num_maquina or "", lambda o: o.departamento_setor or ""),
        ("impressora", "Impressora", Impressora,
         lambda o: o.modelo or "Impressora", lambda o: o.local_printer or "", lambda o: ""),
        ("telefone", "Telefone", Telefone,
         lambda o: f"Ramal {o.ramal}" if o.ramal else "Telefone", lambda o: o.local or "", lambda o: ""),
    ]
    achados = []
    for chave, rotulo, modelo, f_nome, f_det, f_setor in fontes:
        q = modelo.query.filter(db.func.trim(modelo.ip) == ip)
        if ignorar_tipo == chave and ignorar_id:
            q = q.filter(modelo.id != ignorar_id)
        for o in q.order_by(modelo.id).all():
            achados.append(SimpleNamespace(tipo=rotulo, chave_tipo=chave, id=o.id, nome_completo=f_nome(o),
                                           num_maquina=f_det(o), departamento_setor=f_setor(o)))
    return achados


def maquinas_com_ip(ip, ignorar_id=None):
    """Mantido pelo nome antigo: agora confere o IP em TODOS os equipamentos
    (máquinas, impressoras e telefones), ignorando a própria máquina na edição."""
    return equipamentos_com_ip(ip, "maquina", ignorar_id)


def mensagem_ip_duplicado(ip, conflitos):
    descricoes = ", ".join(
        f"{c.tipo} ID {c.id} – {c.nome_completo or 'sem nome'}"
        + (f" ({c.num_maquina})" if c.num_maquina else "")
        for c in conflitos
    )
    return f"ATENÇÃO: o IP {ip} já existe no sistema ({descricoes}). Nada foi salvo — use outro IP."


@app.route("/maquina/verificar-ip")
@login_required
def verificar_ip_maquina():
    """Usado nas telas de cadastro/edição (máquina, impressora, telefone) pra avisar
    NA HORA, enquanto o IP é digitado. ?tipo=maquina|impressora|telefone e ?ignorar=<id>."""
    ip = request.args.get("ip", "").strip()
    tipo = request.args.get("tipo", "maquina")
    if tipo not in ("maquina", "impressora", "telefone"):
        tipo = "maquina"
    ignorar = request.args.get("ignorar", type=int)
    conflitos = equipamentos_com_ip(ip, tipo, ignorar)
    return {
        "duplicado": bool(conflitos),
        "maquinas": [
            {"id": c.id, "tipo": c.tipo, "nome": c.nome_completo or "", "num_maquina": c.num_maquina or "",
             "setor": c.departamento_setor or ""}
            for c in conflitos
        ],
    }


def _preencher_maquina_do_form(m):
    for campo in CAMPOS_MAQUINA:
        setattr(m, campo, request.form.get(campo, "").strip())
    if m.mac:
        m.mac = m.mac.upper()


def _extras_do_form(extras_atuais):
    for campo in campos_extra_lista("maquina"):
        campo_form = f"extra_{campo.chave}"
        if campo_form in request.form:
            extras_atuais[campo.chave] = request.form.get(campo_form, "").strip()
    return json.dumps(extras_atuais, ensure_ascii=False)


@app.route("/maquina/cadastrar", methods=["GET", "POST"])
@login_required
def cadastrar_maquina():
    if request.method == "POST":
        ip = request.form.get("ip", "").strip()
        conflitos = maquinas_com_ip(ip)
        if conflitos:
            flash(mensagem_ip_duplicado(ip, conflitos), "erro")
            # Volta para o formulário COM tudo o que foi digitado (não perde o preenchimento).
            # Esta máquina "rascunho" não é adicionada ao banco.
            rascunho = Maquina()
            _preencher_maquina_do_form(rascunho)
            rascunho.extras = _extras_do_form({})
            return render_template("cadastro_maquina.html", ip_conflito=True,
                                   **contexto_form_maquina(rascunho))
        m = Maquina()
        _preencher_maquina_do_form(m)
        garantir_opcao("especialidade", m.especialidade)
        garantir_opcao("processador_modelo", m.processador_modelo)
        garantir_opcao("lacre", m.lacre)
        m.extras = _extras_do_form({})
        db.session.add(m)
        db.session.commit()
        flash("Máquina cadastrada com sucesso.", "ok")
        return redirect(url_for("listar_maquinas"))
    return render_template("cadastro_maquina.html", **contexto_form_maquina())


@app.route("/maquina/editar/<int:maquina_id>", methods=["GET", "POST"])
@login_required
def editar_maquina(maquina_id):
    m = Maquina.query.get_or_404(maquina_id)
    if request.method == "POST":
        ip = request.form.get("ip", "").strip()
        conflitos = maquinas_com_ip(ip, ignorar_id=m.id)
        if conflitos:
            flash(mensagem_ip_duplicado(ip, conflitos), "erro")
            # Mostra o formulário de novo com o que foi digitado, mas SEM gravar nada:
            # no_autoflush impede qualquer escrita e o rollback desfaz as alterações em memória.
            with db.session.no_autoflush:
                _preencher_maquina_do_form(m)
                m.extras = _extras_do_form(carregar_extras(m))
                html = render_template("cadastro_maquina.html", ip_conflito=True,
                                       **contexto_form_maquina(m))
            db.session.rollback()
            return html
        _preencher_maquina_do_form(m)
        garantir_opcao("especialidade", m.especialidade)
        garantir_opcao("processador_modelo", m.processador_modelo)
        garantir_opcao("lacre", m.lacre)
        m.extras = _extras_do_form(carregar_extras(m))
        db.session.commit()
        flash("Máquina atualizada.", "ok")
        if request.args.get("voltar") == "faixa":
            return redirect(url_for("faixa_ip"))
        return redirect(url_for("listar_maquinas"))
    rastro = None
    if eh_geral():
        regs = LogAuditoria.query.filter_by(tipo="Máquina", objeto_id=m.id).order_by(LogAuditoria.quando).all()
        criou = next((r for r in regs if r.acao == "Criou"), None)
        ultima = next((r for r in reversed(regs) if r.acao == "Alterou"), None)
        rastro = {"criou": criou, "ultima": ultima}
    return render_template("cadastro_maquina.html", rastro=rastro, **contexto_form_maquina(m))


@app.route("/maquina/excluir/<int:maquina_id>", methods=["POST"])
@login_required
def excluir_maquina(maquina_id):
    m = Maquina.query.get_or_404(maquina_id)
    descricao = f"{m.nome_completo} (IP: {m.ip or '-'}, NIP: {m.nip or '-'}, Setor: {m.departamento_setor or '-'})"
    registrar_exclusao("Máquina", descricao, dados=_snapshot_modelo(m))
    db.session.delete(m)
    db.session.commit()
    flash("Máquina excluída. Registrado no histórico de exclusões.", "ok")
    if request.form.get("voltar") == "faixa" and current_user.is_admin:
        return redirect(url_for("faixa_ip"))
    return redirect(url_for("listar_maquinas"))


def chave_ordenacao_ip(valor_ip):
    """Ordena IP de verdade (10.210.64.3 antes de 10.210.64.13, por exemplo) — sort
    normal de texto colocaria '10.210.64.124' antes de '10.210.64.3', o que fica errado
    pra quem organiza faixas de IP por departamento. IPs inválidos/vazios vão pro final."""
    partes = (valor_ip or "").strip().split(".")
    if len(partes) == 4 and all(p.isdigit() for p in partes):
        return (0, tuple(int(p) for p in partes))
    return (1, valor_ip or "")


@app.route("/maquina/listar")
@login_required
def listar_maquinas():
    query = Maquina.query

    # Filtros de categoria (seletor - listas configuráveis)
    filtros_categoria = {
        "setor": Maquina.departamento_setor,
        "so": Maquina.sistema_operacional,
        "disponivel": Maquina.disponivel,
        "lva": Maquina.lva,
        "posto": Maquina.posto_graduacao,
        "corpo": Maquina.corpo_quadro,
        "especialidade": Maquina.especialidade,
        "memoria_tipo": Maquina.memoria_tipo,
        "memoria_qtd": Maquina.memoria_qtd,
        "armazenamento_tipo": Maquina.armazenamento_tipo,
        "armazenamento_capacidade": Maquina.armazenamento_capacidade,
        "armazenamento_interface": Maquina.armazenamento_interface,
        "teclado": Maquina.teclado,
        "mouse": Maquina.mouse,
        "processador_fabricante": Maquina.processador_fabricante,
    }
    valores_filtro = {}
    for chave, coluna in filtros_categoria.items():
        valor = request.args.get(chave, "Todos")
        valores_filtro[chave] = valor
        if valor != "Todos":
            query = query.filter(coluna == valor)

    # Filtros de texto — viram listas suspensas com os valores que já existem no banco
    filtros_texto = {
        "f_id": Maquina.id,
        "f_nome": Maquina.nome_completo,
        "f_nip": Maquina.nip,
        "f_ip": Maquina.ip,
        "f_num_maquina": Maquina.num_maquina,
        "f_mac": Maquina.mac,
        "f_num_pat": Maquina.num_pat,
        "f_lacre": Maquina.lacre,
        "f_processador_modelo": Maquina.processador_modelo,
        "f_data_compra": Maquina.data_compra,
        "f_data_revitalizacao": Maquina.data_revitalizacao,
    }
    valores_texto = {}
    for chave, coluna in filtros_texto.items():
        valor = request.args.get(chave, "Todos")
        valores_texto[chave] = valor
        if valor != "Todos":
            if chave == "f_id" and valor.isdigit():
                query = query.filter(Maquina.id == int(valor))
            elif chave != "f_id":
                query = query.filter(coluna == valor)

    # Filtro do Histórico de Manutenção: Todos / Com registros / Sem registros
    f_historico = request.args.get("f_historico", "Todos")
    if f_historico == "Com registros":
        query = query.filter(Maquina.historicos.any())
    elif f_historico == "Sem registros":
        query = query.filter(~Maquina.historicos.any())

    # Filtro do Nível RCC — opções SEMPRE fixas (RCC-1/2/3 + "Não definido"), não
    # dependem do que já existe cadastrado, pra você conseguir achar justamente as
    # máquinas (ex: servidores) que ainda faltam classificar.
    f_rcc = request.args.get("rcc", "Todos")
    if f_rcc == "Não definido":
        query = query.filter(db.or_(Maquina.nivel_rcc.is_(None), Maquina.nivel_rcc == ""))
    elif f_rcc != "Todos":
        query = query.filter(Maquina.nivel_rcc == f_rcc)

    maquinas = query.options(db.selectinload(Maquina.historicos)).order_by(Maquina.id).all()
    maquinas.sort(key=lambda m: chave_ordenacao_ip(m.ip))
    revit = request.args.get("revit") == "vencida"
    if revit:   # veio do quadro "Revitalização vencida" do Painel
        hoje = datetime.now().date()
        maquinas = [m for m in maquinas if revitalizacao_vencida(m, hoje)]

    def valores_distintos(coluna, numerico=False):
        vals = [v[0] for v in db.session.query(coluna).distinct() if v[0] not in (None, "")]
        if coluna is Maquina.ip:
            return sorted(vals, key=chave_ordenacao_ip)
        return sorted(vals, key=lambda x: int(x)) if numerico else sorted(vals)

    opcoes_filtro = dict(
        setores=sorted({s[0] for s in db.session.query(Maquina.departamento_setor).distinct() if s[0]}),
        sistemas=sorted({s[0] for s in db.session.query(Maquina.sistema_operacional).distinct() if s[0]}),
        postos=opcoes("posto_graduacao"), corpos=opcoes("corpo_quadro"),
        especialidades=opcoes("especialidade"), memoria_tipos=opcoes("memoria_tipo"),
        memoria_qtds=opcoes("memoria_qtd"), armazenamento_tipos=opcoes("armazenamento_tipo"),
        armazenamento_capacidades=opcoes("armazenamento_capacidade"),
        armazenamento_interfaces=opcoes("armazenamento_interface"),
        fabricantes=opcoes("processador_fabricante"),
        lista_ids=valores_distintos(Maquina.id, numerico=True),
        lista_nomes=valores_distintos(Maquina.nome_completo),
        lista_nips=valores_distintos(Maquina.nip),
        lista_ips=valores_distintos(Maquina.ip),
        lista_num_maquinas=valores_distintos(Maquina.num_maquina),
        lista_macs=valores_distintos(Maquina.mac),
        lista_num_pats=valores_distintos(Maquina.num_pat),
        lista_lacres=valores_distintos(Maquina.lacre),
        lista_proc_modelos=valores_distintos(Maquina.processador_modelo),
        lista_datas_compra=valores_distintos(Maquina.data_compra),
        lista_datas_revitalizacao=valores_distintos(Maquina.data_revitalizacao),
    )


    # --------------------------------------------------------------------
    # Estrutura genérica de colunas: uma entrada por campo visível de Máquina,
    # já na ORDEM customizada pelo admin (Editar Colunas → mover ↑/↓), com as
    # opções de filtro de cada uma — usada pro cabeçalho "estilo Excel" (seta
    # de filtro em cada coluna) e pra reordenar sem precisar mexer no template.
    mapa_param_coluna = {
        "nome_completo": "f_nome", "nip": "f_nip", "posto_graduacao": "posto", "corpo_quadro": "corpo",
        "especialidade": "especialidade", "ip": "f_ip", "num_maquina": "f_num_maquina", "mac": "f_mac",
        "disponivel": "disponivel", "lva": "lva", "departamento_setor": "setor", "num_pat": "f_num_pat",
        "sistema_operacional": "so", "memoria_tipo": "memoria_tipo", "memoria_qtd": "memoria_qtd",
        "armazenamento_tipo": "armazenamento_tipo", "armazenamento_capacidade": "armazenamento_capacidade",
        "armazenamento_interface": "armazenamento_interface", "teclado": "teclado", "mouse": "mouse",
        "lacre": "f_lacre", "processador_fabricante": "processador_fabricante",
        "processador_modelo": "f_processador_modelo", "data_compra": "f_data_compra",
        "data_revitalizacao": "f_data_revitalizacao", "nivel_rcc": "rcc",
    }
    opcoes_por_coluna = {
        "nome_completo": opcoes_filtro["lista_nomes"], "nip": opcoes_filtro["lista_nips"],
        "posto_graduacao": opcoes_filtro["postos"], "corpo_quadro": opcoes_filtro["corpos"],
        "especialidade": opcoes_filtro["especialidades"], "ip": opcoes_filtro["lista_ips"],
        "num_maquina": opcoes_filtro["lista_num_maquinas"], "mac": opcoes_filtro["lista_macs"],
        "disponivel": ["Sim", "Não"], "lva": ["Sim", "Não"], "departamento_setor": opcoes_filtro["setores"],
        "num_pat": opcoes_filtro["lista_num_pats"], "sistema_operacional": opcoes_filtro["sistemas"],
        "memoria_tipo": opcoes_filtro["memoria_tipos"], "memoria_qtd": opcoes_filtro["memoria_qtds"],
        "armazenamento_tipo": opcoes_filtro["armazenamento_tipos"],
        "armazenamento_capacidade": opcoes_filtro["armazenamento_capacidades"],
        "armazenamento_interface": opcoes_filtro["armazenamento_interfaces"],
        "teclado": ["Sim", "Não"], "mouse": ["Sim", "Não"], "lacre": opcoes_filtro["lista_lacres"],
        "processador_fabricante": opcoes_filtro["fabricantes"],
        "processador_modelo": opcoes_filtro["lista_proc_modelos"],
        "data_compra": opcoes_filtro["lista_datas_compra"],
        "data_revitalizacao": opcoes_filtro["lista_datas_revitalizacao"],
        "nivel_rcc": NIVEIS_RCC + ["Não definido"],
    }
    valores_filtro["rcc"] = f_rcc
    valores_por_param = {**valores_filtro, **valores_texto}
    colunas_ordenadas = []
    for item in estrutura_colunas("maquina"):
        if item["origem"] == "fixo":
            chave = item["campo_fixo"]
            param = mapa_param_coluna.get(chave)
            item["param"] = param
            item["opcoes"] = opcoes_por_coluna.get(chave, [])
            item["valor_filtro"] = valores_por_param.get(param, "Todos") if param else "Todos"
        else:
            item["param"] = None
            item["opcoes"] = []
            item["valor_filtro"] = "Todos"
        colunas_ordenadas.append(item)

    return render_template(
        "listar_maquinas.html",
        maquinas=maquinas, cores=cores_setor(), f_historico=f_historico,
        ocultos=campos_ocultos_maquina(), rotulos_campos=rotulos_campos_maquina(),
        extras_maquina=campos_extra_lista("maquina"), carregar_extras=carregar_extras,
        colunas_ordenadas=colunas_ordenadas, revit=revit,
        **opcoes_filtro, **valores_filtro, **valores_texto,
    )


# ----------------------------------------------------------------------------
# Status "ligado/desligado" por PING
# ----------------------------------------------------------------------------
# Isto e apenas um PING (ICMP echo) para os IPs que o proprio sistema ja tem
# cadastrados — o mesmo "ping" que qualquer um faz pelo prompt. Nao instala
# agente, nao mexe em nada na maquina do usuario; e so uma pergunta "voce esta
# ai?" na rede. Nao e varredura/sniffer: so fala com os IPs ja conhecidos.
def _ip_valido(ip):
    try:
        ipaddress.ip_address((ip or "").strip())
        return True
    except ValueError:
        return False


def _ping_disponivel():
    """True se existe o utilitario 'ping' no servidor. Sem ele, nao da pra
    verificar status — a tela avisa em vez de pintar tudo de vermelho."""
    return shutil.which("ping") is not None


def _comando_ping(ip):
    """1 pacote, espera curta. Windows usa -n/-w(ms); Linux/Unix usa -c/-W(s)."""
    if platform.system().lower().startswith("win"):
        return ["ping", "-n", "1", "-w", "1000", ip]
    return ["ping", "-c", "1", "-W", "1", ip]


def _ping(ip):
    """True se o IP respondeu ao ping. Nunca levanta excecao."""
    if not _ip_valido(ip):
        return False
    try:
        r = subprocess.run(_comando_ping(ip.strip()),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=3)
        return r.returncode == 0
    except Exception:
        return False


# ------------------------------------------------------------------
# PING COMPARTILHADO: o servidor pinga TODOS os equipamentos cadastrados com IP
# (máquinas, servidores, impressoras e ramais) UMA vez por rodada e guarda o
# resultado. Quem abre a tela Status da Rede só LÊ esse resultado — 1 colega ou
# 10 com a tela aberta dá no mesmo pra rede. Ninguém olhando = ninguém pingando.
# Só IPs cadastrados: nada de scan de rede.
import threading as _threading  # noqa: E402

PING_INTERVALO_SEG = 60        # nova rodada a cada 1 minuto enquanto alguém estiver com a tela aberta
PING_OCIOSO_SEG = 150          # sem ninguém olhando por 2,5 min, o servidor para de pingar
_PING = {"resultado": {}, "quando": None, "rodando": False, "interesse": 0.0, "vigia": False}
_PING_TRAVA = _threading.Condition()


def _ips_para_pingar():
    ips = set()
    for modelo in (Maquina, Impressora, Telefone):
        for (ip,) in db.session.query(modelo.ip).filter(modelo.ip.isnot(None)):
            ip = (ip or "").strip()
            if ip and _ip_valido(ip):
                ips.add(ip)
    return sorted(ips, key=chave_ordenacao_ip)


def _rodada_ping():
    """Faz UMA rodada (se já houver uma em andamento, espera ela terminar e usa o resultado)."""
    with _PING_TRAVA:
        if _PING["rodando"]:
            _PING_TRAVA.wait(timeout=60)
            return
        _PING["rodando"] = True
    try:
        with app.app_context():
            alvos = _ips_para_pingar()
        resultado = {}
        if alvos:
            with ThreadPoolExecutor(max_workers=64) as ex:
                futuros = {ex.submit(_ping, ip): ip for ip in alvos}
                for fut in as_completed(futuros):
                    try:
                        resultado[futuros[fut]] = "on" if fut.result() else "off"
                    except Exception:
                        resultado[futuros[fut]] = "off"
        with _PING_TRAVA:
            _PING["resultado"] = resultado
            _PING["quando"] = time.time()
    finally:
        with _PING_TRAVA:
            _PING["rodando"] = False
            _PING_TRAVA.notify_all()


def _vigia_ping():
    while True:
        try:
            agora = time.time()
            alguem_olhando = agora - _PING["interesse"] < PING_OCIOSO_SEG
            velho = _PING["quando"] is None or agora - _PING["quando"] >= PING_INTERVALO_SEG
            if alguem_olhando and velho and not _PING["rodando"]:
                _rodada_ping()
        except Exception as e:
            print(f">> AVISO: falha na rodada de ping: {e}")
        time.sleep(2)


def _garantir_vigia():
    with _PING_TRAVA:
        if _PING["vigia"]:
            return
        _PING["vigia"] = True
    _threading.Thread(target=_vigia_ping, name="sisparque-ping", daemon=True).start()


@app.route("/maquina/status-ping")
@login_required
def status_ping_maquinas():
    """Devolve o resultado guardado do ping compartilhado: {"status": {ip: "on"|"off"},
    "atualizado": "HH:MM:SS", "idade": segundos}. ?agora=1 força uma rodada nova
    (se a última tiver mais de 10 s)."""
    if not _ping_disponivel():
        return jsonify({"_erro": "O utilitário 'ping' não está disponível no servidor. "
                                 "Instale o pacote iputils (ex.: dnf install iputils) para usar esta função."})
    _PING["interesse"] = time.time()
    _garantir_vigia()
    forcar = request.args.get("agora") == "1"
    idade = None if _PING["quando"] is None else time.time() - _PING["quando"]
    if idade is None or (forcar and idade > 10):
        _rodada_ping()                     # primeira vez (ou "Atualizar agora"): espera a rodada
    elif _PING["rodando"] and forcar:
        with _PING_TRAVA:
            _PING_TRAVA.wait(timeout=60)
    quando = _PING["quando"]
    return jsonify({
        "status": _PING["resultado"],
        "atualizado": datetime.fromtimestamp(quando).strftime("%H:%M:%S") if quando else None,
        "idade": int(time.time() - quando) if quando else None,
        "intervalo": PING_INTERVALO_SEG,
    })


@app.route("/rede")
@login_required
def painel_rede():
    """Painel de Status da Rede: visao global dos IPs ativos/inativos, agrupados
    por setor. Diferente do Dashboard (que conta inventario por setor/SO) — aqui
    o foco e quem esta LIGADO agora. Os IPs sao pingados pelo navegador, via o
    mesmo endpoint status-ping."""
    maquinas = Maquina.query.order_by(Maquina.departamento_setor, Maquina.ip).all()
    maquinas.sort(key=lambda m: chave_ordenacao_ip(m.ip))

    setores = {}
    total_com_ip = 0
    for m in maquinas:
        if m.ip and _ip_valido(m.ip):
            total_com_ip += 1
            setores.setdefault(m.departamento_setor or "Sem setor", []).append(m)
    setores_ord = sorted(setores.items(), key=lambda kv: (kv[0] or "").lower())

    # Impressoras e ramais também aparecem (mesmo ping compartilhado)
    from types import SimpleNamespace
    extras_grupos = []
    imps = [SimpleNamespace(id=f"imp-{i.id}", ip=i.ip.strip(), nome_completo=i.local_printer or i.modelo or "Impressora",
                            num_maquina=i.modelo or "")
            for i in Impressora.query.all() if i.ip and _ip_valido(i.ip)]
    tels = [SimpleNamespace(id=f"tel-{t.id}", ip=t.ip.strip(), nome_completo=(f"Ramal {t.ramal}" if t.ramal else "Telefone"),
                            num_maquina=t.local or "")
            for t in Telefone.query.all() if t.ip and _ip_valido(t.ip)]
    if imps:
        extras_grupos.append(("Impressoras", sorted(imps, key=lambda x: chave_ordenacao_ip(x.ip))))
    if tels:
        extras_grupos.append(("Telefonia", sorted(tels, key=lambda x: chave_ordenacao_ip(x.ip))))
    setores_ord = setores_ord + extras_grupos
    total_com_ip += len(imps) + len(tels)

    return render_template("painel_rede.html",
                           setores=setores_ord,
                           total_com_ip=total_com_ip,
                           total_sem_ip=len(maquinas) - total_com_ip,
                           cores=cores_setor(), texto_contraste=texto_contraste)


@app.route("/rede/faixa", methods=["GET", "POST"])
@login_required
@admin_required
def faixa_ip():
    """Faixa de IP (só administrador): a rede inteira da OM (ex: 10.210.64.0/20 = do
    10.210.64.0 ao 10.210.79.255), bloco por bloco, com os setores, IPs em uso e livres.
    Usa só o que está cadastrado no sistema — sem ping, sem scan de rede."""
    cfg = ConfiguracaoSistema.query.first()
    if not cfg:
        cfg = ConfiguracaoSistema()
        db.session.add(cfg)
        db.session.commit()

    if request.method == "POST":
        cidr = request.form.get("rede_cidr", "").strip()
        gateway = request.form.get("rede_gateway", "").strip()
        try:
            rede_nova = ipaddress.ip_network(cidr, strict=False) if cidr else None
            if rede_nova is not None and (rede_nova.version != 4 or not 16 <= rede_nova.prefixlen <= 30):
                raise ValueError("Use uma rede de /16 até /30. Exemplo: 10.210.64.0/20")
            if gateway:
                if ipaddress.ip_address(gateway) not in (rede_nova or ipaddress.ip_network("0.0.0.0/0")):
                    raise ValueError(f"O gateway {gateway} não fica dentro da rede {rede_nova}.")
            cfg.rede_cidr = str(rede_nova) if rede_nova else ""
            cfg.rede_gateway = gateway
            db.session.commit()
            flash(f"Rede salva: {rede_nova}." if rede_nova else "Rede removida.", "ok")
        except ValueError as e:
            texto = str(e)
            if "does not appear" in texto or "has host bits" in texto or "not a valid" in texto:
                texto = "Rede ou gateway inválido. Exemplo: rede 10.210.64.0/20 e gateway 10.210.64.1"
            flash(texto, "erro")
        return redirect(url_for("faixa_ip"))

    rede = None
    if cfg.rede_cidr:
        try:
            rede = ipaddress.ip_network(cfg.rede_cidr, strict=False)
        except ValueError:
            rede = None
    gateway = (cfg.rede_gateway or "").strip()

    usados = []
    maquinas = Maquina.query.order_by(Maquina.id).all()
    for m in maquinas:
        if m.ip and _ip_valido(m.ip) and ":" not in m.ip:
            usados.append({
                "ip": m.ip.strip(), "tipo": "Máquina", "nome": m.nome_completo or "",
                "detalhe": m.num_maquina or "", "setor": m.departamento_setor or "",
                "url": url_for("editar_maquina", maquina_id=m.id, voltar="faixa"),
                "excluir": url_for("excluir_maquina", maquina_id=m.id), "id": m.id,
            })
    for imp in Impressora.query.all():
        if imp.ip and _ip_valido(imp.ip) and ":" not in imp.ip:
            usados.append({"ip": imp.ip.strip(), "tipo": "Impressora", "nome": imp.modelo or "Impressora",
                           "detalhe": imp.local_printer or "", "setor": "", "url": url_for("impressoras_page")})
    for t in Telefone.query.all():
        if t.ip and _ip_valido(t.ip) and ":" not in t.ip:
            usados.append({"ip": t.ip.strip(), "tipo": "Telefone", "nome": f"Ramal {t.ramal}" if t.ramal else "Telefone",
                           "detalhe": t.local or "", "setor": "", "url": url_for("telefonia_page")})

    cores = cores_setor()
    por_base = {}
    for u in usados:
        base = u["ip"].rsplit(".", 1)[0]
        f = por_base.setdefault(base, {"qtd": 0, "setores": {}, "ips": set()})
        f["qtd"] += 1
        f["ips"].add(u["ip"])
        nome_setor = u["setor"] or (u["tipo"] + "s" if u["tipo"] != "Máquina" else "Sem setor")
        f["setores"][nome_setor] = f["setores"].get(nome_setor, 0) + 1

    def montar_bloco(base):
        f = por_base.get(base, {"qtd": 0, "setores": {}, "ips": set()})
        if rede is not None and rede.prefixlen > 24:
            inicio, fim = rede.network_address, rede.broadcast_address
        else:
            inicio, fim = ipaddress.ip_address(base + ".0"), ipaddress.ip_address(base + ".255")
        # quantos endereços dá pra usar neste bloco (tira rede, broadcast e gateway)
        reservados = set()
        if rede is not None and ipaddress.ip_address(base + ".1") in rede:
            reservados |= {str(rede.network_address), str(rede.broadcast_address)}
        else:
            reservados |= {base + ".0", base + ".255"}
        if gateway:
            reservados.add(gateway)
        total = int(fim) - int(inicio) + 1
        reserv_aqui = sum(1 for r in reservados if int(inicio) <= int(ipaddress.ip_address(r)) <= int(fim) and r not in f["ips"])
        uteis = total - reserv_aqui
        em_uso = len(f["ips"])
        setores_ord = sorted(f["setores"].items(), key=lambda kv: (-kv[1], kv[0]))
        return {
            "base": base, "inicio": str(inicio), "fim": str(fim), "qtd": em_uso,
            "livres": max(0, uteis - em_uso), "uteis": uteis,
            "uso": round(em_uso * 100 / uteis) if uteis else 0,
            "setores": [{"nome": n, "qtd": q, "cor": cores.get(n, "#7A7A7A")} for n, q in setores_ord],
        }

    if rede is not None:
        if rede.prefixlen <= 24:
            bases = [str(sub.network_address).rsplit(".", 1)[0] for sub in rede.subnets(new_prefix=24)]
        else:
            bases = [str(rede.network_address).rsplit(".", 1)[0]]
        blocos = [montar_bloco(b) for b in bases]
        fora = [montar_bloco(b) for b in sorted((b for b in por_base if b not in bases),
                                               key=lambda b: chave_ordenacao_ip(b + ".0"))]
        resumo = {
            "cidr": str(rede), "primeiro": str(rede.network_address), "ultimo": str(rede.broadcast_address),
            "mascara": str(rede.netmask), "gateway": gateway,
            "uteis": sum(b["uteis"] for b in blocos), "em_uso": sum(b["qtd"] for b in blocos),
        }
        resumo["livres"] = resumo["uteis"] - resumo["em_uso"]
        resumo["uso"] = round(resumo["em_uso"] * 100 / resumo["uteis"]) if resumo["uteis"] else 0
        sugestao = ""
    else:
        blocos = [montar_bloco(b) for b in sorted(por_base, key=lambda b: chave_ordenacao_ip(b + ".0"))]
        fora, resumo = [], None
        # Sugere a menor rede que cobre os blocos mais usados (ex: 10.210.64.0/20)
        sugestao = ""
        if por_base:
            prefixo16 = max({".".join(b.split(".")[:2]) for b in por_base},
                            key=lambda p: sum(v["qtd"] for b, v in por_base.items() if b.startswith(p + ".")))
            qtd_por_terceiro = {int(b.split(".")[2]): v["qtd"] for b, v in por_base.items() if b.startswith(prefixo16 + ".")}
            terceiros = sorted(qtd_por_terceiro)
            # ignora blocos soltos nas pontas (ex: 1 IP perdido no .101) enquanto sobrar 95% dos IPs
            total = sum(qtd_por_terceiro.values())
            while len(terceiros) > 1:
                ponta = terceiros[0] if qtd_por_terceiro[terceiros[0]] <= qtd_por_terceiro[terceiros[-1]] else terceiros[-1]
                if sum(qtd_por_terceiro[t] for t in terceiros if t != ponta) < total * 0.95:
                    break
                terceiros.remove(ponta)
            redes = list(ipaddress.summarize_address_range(
                ipaddress.ip_address(f"{prefixo16}.{terceiros[0]}.0"), ipaddress.ip_address(f"{prefixo16}.{terceiros[-1]}.255")))
            sup = redes[0]
            while not all(ipaddress.ip_network(f"{prefixo16}.{t}.0/24").subnet_of(sup) for t in terceiros) and sup.prefixlen > 16:
                sup = sup.supernet()
            sugestao = str(sup)

    lista_maquinas = [
        {"id": m.id, "nome": m.nome_completo or "", "num": m.num_maquina or "", "ip": (m.ip or "").strip(),
         "setor": m.departamento_setor or "", "url": url_for("editar_maquina", maquina_id=m.id)}
        for m in maquinas if (m.lva or "Não") != "Sim"
    ]
    # IPs repetidos (máquina x máquina, máquina x impressora etc.) — aparecem no topo pra corrigir
    grupos_ip = {}
    for u in usados:
        grupos_ip.setdefault(u["ip"], []).append(u)
    repetidos = sorted(((ip, us) for ip, us in grupos_ip.items() if len(us) > 1),
                       key=lambda par: chave_ordenacao_ip(par[0]))

    candidatos = [b for b in blocos if b["qtd"]] or blocos
    inicial = request.args.get("faixa") or (max(candidatos, key=lambda b: b["qtd"])["base"] if candidatos else "")
    return render_template("faixa_ip.html", usados=usados, blocos=blocos, fora=fora, resumo=resumo, repetidos=repetidos,
                           sugestao=sugestao, rede_gateway=gateway, cores=cores,
                           rede_inicio=int(rede.network_address) if rede else None,
                           rede_fim=int(rede.broadcast_address) if rede else None,
                           lista_maquinas=lista_maquinas, faixa_inicial=inicial)


# --------------------------------------------------------- AUDITORIA ----
CORES_ACAO_AUDITORIA = {
    "Criou": ("#EAF3DE", "#27500A"), "Alterou": ("#FAEEDA", "#633806"), "Excluiu": ("#FCEBEB", "#791F1F"),
    "Trocou senha": ("#EEEDFE", "#3C3489"), "Senha errada": ("#FCEBEB", "#791F1F"), "Bloqueado": ("#B00020", "#FFFFFF"),
    "Entrou": ("#E6F1FB", "#0C447C"), "Saiu": ("#F1EFE8", "#444441"), "Sessão encerrada": ("#F1EFE8", "#444441"),
    "Importou banco": ("#FAEEDA", "#633806"), "Excluiu da auditoria": ("#2C2C2A", "#FFFFFF"),
}


def _consulta_auditoria():
    q = LogAuditoria.query
    f = {k: (request.args.get(k) or "").strip() for k in ("usuario", "acao", "tipo", "de", "ate", "busca")}
    if f["usuario"]:
        q = q.filter(LogAuditoria.usuario_nome == f["usuario"])
    if f["acao"]:
        q = q.filter(LogAuditoria.acao == f["acao"])
    if f["tipo"]:
        q = q.filter(LogAuditoria.tipo == f["tipo"])
    try:
        if f["de"]:
            q = q.filter(LogAuditoria.quando >= datetime.strptime(f["de"], "%Y-%m-%d"))
        if f["ate"]:
            q = q.filter(LogAuditoria.quando < datetime.strptime(f["ate"], "%Y-%m-%d") + timedelta(days=1))
    except ValueError:
        pass
    if f["busca"]:
        termo = f"%{f['busca']}%"
        q = q.filter(db.or_(LogAuditoria.descricao.ilike(termo), LogAuditoria.detalhes.ilike(termo),
                            LogAuditoria.ip_origem.ilike(termo), LogAuditoria.usuario_nome.ilike(termo)))
    return q.order_by(LogAuditoria.quando.desc(), LogAuditoria.id.desc()), f


def _detalhes_legiveis(reg):
    if not reg.detalhes:
        return []
    try:
        dados = json.loads(reg.detalhes)
    except (ValueError, TypeError):
        return [reg.detalhes]
    if isinstance(dados, list):
        return [f"{d.get('campo')}: {d.get('antes') or '(vazio)'} → {d.get('depois') or '(vazio)'}" for d in dados]
    return [str(dados)]


@app.route("/admin/auditoria")
@login_required
@geral_required
def admin_auditoria():
    q, filtros = _consulta_auditoria()
    formato = request.args.get("formato")
    if formato in _MIME_PLANILHA:
        dados = [["Data/hora", "Usuário", "Ação", "Tipo", "ID", "Descrição", "Detalhes", "IP de origem"]]
        for r in q.limit(50000).all():
            dados.append([r.quando.strftime("%d/%m/%Y %H:%M:%S"), r.usuario_nome or "-", r.acao, r.tipo or "-",
                          r.objeto_id or "-", r.descricao or "-", " | ".join(_detalhes_legiveis(r)) or "-", r.ip_origem or "-"])
        p = planilha_de_tabela("Auditoria do SISPARQUE", dados)
        conteudo = p.xlsx() if formato == "xlsx" else p.ods()
        return send_file(_BytesIO(conteudo), as_attachment=True,
                         download_name=f"sisparque_auditoria_{datetime.now().strftime('%Y%m%d_%H%M')}.{formato}",
                         mimetype=_MIME_PLANILHA[formato])
    pagina = max(1, request.args.get("pagina", 1, type=int))
    por_pagina = 100
    total = q.count()
    registros = q.offset((pagina - 1) * por_pagina).limit(por_pagina).all()
    for r in registros:
        r.linhas_detalhe = _detalhes_legiveis(r)
    opcoes_aud = dict(
        usuarios=[u for (u,) in db.session.query(LogAuditoria.usuario_nome).distinct().order_by(LogAuditoria.usuario_nome) if u],
        acoes=[a for (a,) in db.session.query(LogAuditoria.acao).distinct().order_by(LogAuditoria.acao) if a],
        tipos=[t for (t,) in db.session.query(LogAuditoria.tipo).distinct().order_by(LogAuditoria.tipo) if t],
    )
    args_sem_pagina = {k: v for k, v in filtros.items() if v}
    return render_template("auditoria.html", registros=registros, total=total, pagina=pagina,
                           paginas=max(1, (total + por_pagina - 1) // por_pagina), filtros=filtros,
                           args_sem_pagina=args_sem_pagina, cores=CORES_ACAO_AUDITORIA, **opcoes_aud)


@app.route("/admin/auditoria/excluir", methods=["POST"])
@login_required
@geral_required
def admin_auditoria_excluir():
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    if not ids:
        flash("Marque pelo menos um registro para excluir.", "erro")
        return redirect(request.referrer or url_for("admin_auditoria"))
    sel = LogAuditoria.query.filter(LogAuditoria.id.in_(ids))
    # Se TUDO o que foi marcado já são anotações de exclusão, apaga sem criar outra
    # (senão a lista nunca esvazia: cada exclusão gerava uma anotação nova).
    so_anotacoes = sel.filter(LogAuditoria.acao != "Excluiu da auditoria").count() == 0
    n = sel.delete(synchronize_session=False)
    db.session.commit()
    if so_anotacoes:
        flash(f"{n} registro(s) excluído(s).", "ok")
    else:
        registrar_evento("Excluiu da auditoria", "Auditoria",
                         f"{n} registro(s) excluído(s) da auditoria pelo Administrador geral (IDs {min(ids)} a {max(ids)})")
        flash(f"{n} registro(s) excluído(s). A exclusão ficou anotada na própria auditoria.", "ok")
    return redirect(request.referrer or url_for("admin_auditoria"))


@app.route("/maquina/pdf")
@login_required
def maquina_pdf():
    setor = request.args.get("setor", "Todos")
    so = request.args.get("so", "Todos")
    disponivel = request.args.get("disponivel", "Todos")

    query = Maquina.query
    if setor != "Todos":
        query = query.filter(Maquina.departamento_setor == setor)
    if so != "Todos":
        query = query.filter(Maquina.sistema_operacional == so)
    if disponivel != "Todos":
        query = query.filter(Maquina.disponivel == disponivel)
    # ?ids=1,2,3 -> exporta exatamente o que está na tela (busca rápida + botão Filtrar)
    ids_txt = request.args.get("ids")
    titulo = "Inventário Completo de Máquinas"
    if ids_txt is not None:
        ids = [int(x) for x in ids_txt.split(",") if x.strip().isdigit()]
        query = query.filter(Maquina.id.in_(ids or [0]))
        titulo = "Inventário de Máquinas (filtrado)"
    maquinas = sorted(query.order_by(Maquina.id).all(), key=lambda m: chave_ordenacao_ip(m.ip))

    # ?cols=a,b,c -> só as colunas escolhidas na janela do Exportar (na ordem da tela), com o nome completo
    cols = [c for c in (request.args.get("cols") or "").split(",") if c]
    if cols:
        rot = {c: rotulo_campo("maquina", c, p) for c, p in CAMPOS_FIXOS_POR_TIPO["maquina"]}
        rot["id"] = "ID"
        rot.setdefault("historico", "Histórico")
        dados = dados_maquinas(maquinas, rot, cols)
    else:
        dados = dados_maquinas(maquinas, rotulos_renomeados_maquina())
    if cols and ids_txt is None:
        titulo = "Inventário de Máquinas"
    from pdf_reports import _gerar_pdf_tabela
    return _exportar_tabela(titulo, dados,
                            "sisparque_maquinas", lambda: _gerar_pdf_tabela(titulo, dados))


@app.route("/maquina/<int:maquina_id>/etiqueta")
@login_required
def etiqueta_maquina(maquina_id):
    """Gera a etiqueta (PDF, pronta pra impressora de etiquetas) com a identificação
    CTECCFN-XXXX + Nível RCC + QR Code de conferência. Não gera se o Nível RCC ainda
    não foi escolhido — o sistema nunca decide isso sozinho."""
    m = Maquina.query.get_or_404(maquina_id)
    if not m.nivel_rcc:
        flash("Defina o Nível RCC desta máquina antes de gerar a etiqueta.", "erro")
        return redirect(url_for("editar_maquina", maquina_id=maquina_id))
    buffer = gerar_etiqueta_maquina(m)
    nome_arquivo = f"etiqueta_{m.num_maquina or ('maquina-' + str(m.id))}.pdf"
    return send_file(
        buffer, as_attachment=False, download_name=nome_arquivo,
        mimetype="application/pdf",
    )


def _dados_dashboard(filtro_setor, filtro_so):
    """Calcula KPIs, tabelas e gráficos do dashboard analítico (Setor x SO),
    reaproveitado tanto na página standalone /relatorio quanto embutido em
    Listar Máquinas."""

    def aplicar_filtros(q):
        if filtro_setor != "Todos":
            q = q.filter(Maquina.departamento_setor == filtro_setor)
        if filtro_so != "Todos":
            q = q.filter(Maquina.sistema_operacional == filtro_so)
        return q

    q_linhas = aplicar_filtros(
        db.session.query(Maquina.departamento_setor, Maquina.sistema_operacional, db.func.count(Maquina.id))
    )
    linhas = q_linhas.group_by(Maquina.departamento_setor, Maquina.sistema_operacional) \
        .order_by(Maquina.departamento_setor).all()

    q_setor = aplicar_filtros(db.session.query(Maquina.departamento_setor, db.func.count(Maquina.id)))
    totais_setor = q_setor.group_by(Maquina.departamento_setor) \
        .order_by(db.func.count(Maquina.id).desc()).all()

    q_so = aplicar_filtros(db.session.query(Maquina.sistema_operacional, db.func.count(Maquina.id)))
    totais_so = q_so.group_by(Maquina.sistema_operacional) \
        .order_by(db.func.count(Maquina.id).desc()).all()

    total_geral = sum(t[1] for t in totais_so)

    setores_opcoes = [s[0] for s in db.session.query(Maquina.departamento_setor).distinct() if s[0]]
    sistemas_opcoes = [s[0] for s in db.session.query(Maquina.sistema_operacional).distinct() if s[0]]

    total_maquinas_filtro = aplicar_filtros(db.session.query(Maquina.id)).count()
    total_switches = Switch.query.count()
    total_impressoras = Impressora.query.count()
    total_telefones = Telefone.query.count()

    mapa_cores_setor = cores_setor()
    dados_setor_grafico = [
        (setor or "Sem setor", qtd, mapa_cores_setor.get(setor, "#004080"))
        for setor, qtd in totais_setor if setor
    ]
    grafico_setor, legenda_setor, _ = montar_grafico_pizza(dados_setor_grafico)

    dados_so_grafico = [
        (so or "Não informado", qtd, PALETA_GRAFICO[i % len(PALETA_GRAFICO)])
        for i, (so, qtd) in enumerate(totais_so) if so
    ]
    grafico_so, legenda_so, _ = montar_grafico_pizza(dados_so_grafico)

    return dict(
        linhas=linhas, totais_setor=totais_setor, totais_so=totais_so,
        total_geral=total_geral, cores=cores_setor(),
        setores=sorted(setores_opcoes), sistemas=sorted(sistemas_opcoes),
        filtro_setor=filtro_setor, filtro_so=filtro_so,
        total_maquinas=total_maquinas_filtro, total_switches=total_switches,
        total_impressoras=total_impressoras, total_telefones=total_telefones,
        grafico_setor=grafico_setor, legenda_setor=legenda_setor,
        grafico_so=grafico_so, legenda_so=legenda_so,
    )


@app.route("/relatorio/pdf")
@login_required
def relatorio_pdf():
    filtro_setor = request.args.get("setor", "Todos")
    filtro_so = request.args.get("so", "Todos")

    def aplicar_filtros(q):
        if filtro_setor != "Todos":
            q = q.filter(Maquina.departamento_setor == filtro_setor)
        if filtro_so != "Todos":
            q = q.filter(Maquina.sistema_operacional == filtro_so)
        return q

    q_linhas = aplicar_filtros(
        db.session.query(Maquina.departamento_setor, Maquina.sistema_operacional, db.func.count(Maquina.id))
    )
    linhas = q_linhas.group_by(Maquina.departamento_setor, Maquina.sistema_operacional) \
        .order_by(Maquina.departamento_setor).all()

    q_setor = aplicar_filtros(db.session.query(Maquina.departamento_setor, db.func.count(Maquina.id)))
    totais_setor = q_setor.group_by(Maquina.departamento_setor) \
        .order_by(db.func.count(Maquina.id).desc()).all()

    q_so = aplicar_filtros(db.session.query(Maquina.sistema_operacional, db.func.count(Maquina.id)))
    totais_so = q_so.group_by(Maquina.sistema_operacional) \
        .order_by(db.func.count(Maquina.id).desc()).all()

    buffer = gerar_pdf_relatorio_setor(linhas, totais_so, totais_setor)
    return send_file(
        buffer, as_attachment=True, download_name="sisparque_relatorio_setor.pdf",
        mimetype="application/pdf",
    )


@app.route("/relatorio/pdf-grafico")
@login_required
def relatorio_pdf_grafico():
    filtro_setor = request.args.get("setor", "Todos")
    filtro_so = request.args.get("so", "Todos")

    def aplicar_filtros(q):
        if filtro_setor != "Todos":
            q = q.filter(Maquina.departamento_setor == filtro_setor)
        if filtro_so != "Todos":
            q = q.filter(Maquina.sistema_operacional == filtro_so)
        return q

    mapa_cores_setor = cores_setor()
    q_setor = aplicar_filtros(db.session.query(Maquina.departamento_setor, db.func.count(Maquina.id)))
    totais_setor = q_setor.group_by(Maquina.departamento_setor) \
        .order_by(db.func.count(Maquina.id).desc()).all()
    dados_setor = [
        (setor or "Sem setor", qtd, mapa_cores_setor.get(setor, "#004080"))
        for setor, qtd in totais_setor if setor
    ]

    q_so = aplicar_filtros(db.session.query(Maquina.sistema_operacional, db.func.count(Maquina.id)))
    totais_so = q_so.group_by(Maquina.sistema_operacional) \
        .order_by(db.func.count(Maquina.id).desc()).all()
    dados_so = [
        (so or "Não informado", qtd, PALETA_GRAFICO[i % len(PALETA_GRAFICO)])
        for i, (so, qtd) in enumerate(totais_so) if so
    ]

    buffer = gerar_pdf_grafico_setor(dados_setor, dados_so)
    return send_file(
        buffer, as_attachment=True, download_name="sisparque_dashboard_grafico.pdf",
        mimetype="application/pdf",
    )


@app.route("/maquina/<int:maquina_id>/historico", methods=["GET", "POST"])
@login_required
def historico_maquina(maquina_id):
    m = Maquina.query.get_or_404(maquina_id)
    if request.method == "POST":
        id_edit = request.form.get("id_edit", "").strip()
        data = request.form.get("data", "").strip() or datetime.now().strftime("%Y-%m-%d")
        descricao = request.form.get("descricao", "").strip()
        if descricao:
            if id_edit:
                h = HistoricoManutencao.query.get_or_404(int(id_edit))
                h.data = data
                h.descricao = descricao
                flash("Registro de manutenção atualizado.", "ok")
            else:
                h = HistoricoManutencao(
                    maquina_id=m.id, data=data, descricao=descricao,
                    usuario_nome=current_user.display_name,
                )
                db.session.add(h)
                flash("Registro de manutenção adicionado.", "ok")
            db.session.commit()
        else:
            flash("Descreva o que foi feito antes de salvar.", "erro")
        return redirect(url_for("historico_maquina", maquina_id=m.id))

    historicos = HistoricoManutencao.query.filter_by(maquina_id=m.id) \
        .order_by(HistoricoManutencao.data.desc(), HistoricoManutencao.id.desc()).all()
    return render_template("historico_maquina.html", maquina=m, historicos=historicos)


@app.route("/maquina/<int:maquina_id>/historico/excluir/<int:hist_id>", methods=["POST"])
@login_required
def excluir_historico(maquina_id, hist_id):
    h = HistoricoManutencao.query.get_or_404(hist_id)
    db.session.delete(h)
    db.session.commit()
    flash("Registro removido.", "ok")
    return redirect(url_for("historico_maquina", maquina_id=maquina_id))


@app.route("/maquina/<int:maquina_id>/historico/legado/salvar", methods=["POST"])
@login_required
def salvar_historico_legado(maquina_id):
    m = Maquina.query.get_or_404(maquina_id)
    m.historico_manutencao = request.form.get("texto_legado", "").strip()
    db.session.commit()
    flash("Registro migrado atualizado.", "ok")
    return redirect(url_for("historico_maquina", maquina_id=maquina_id))


@app.route("/maquina/<int:maquina_id>/historico/legado/excluir", methods=["POST"])
@login_required
def excluir_historico_legado(maquina_id):
    m = Maquina.query.get_or_404(maquina_id)
    m.historico_manutencao = ""
    db.session.commit()
    flash("Registro migrado removido.", "ok")
    return redirect(url_for("historico_maquina", maquina_id=maquina_id))


# ------------------------------------------------------------- SWITCH -----

def _salvar_campos_dinamicos(instancia, tipo):
    """Preenche os campos 'de fábrica' visíveis + os campos extras (JSON) a partir do form."""
    for chave, _ in CAMPOS_FIXOS_POR_TIPO.get(tipo, []):
        if chave in request.form:
            setattr(instancia, chave, request.form.get(chave, "").strip())
    extras_atuais = carregar_extras(instancia)
    for campo in campos_extra_lista(tipo):
        campo_form = f"extra_{campo.chave}"
        if campo_form in request.form:
            extras_atuais[campo.chave] = request.form.get(campo_form, "").strip()
    instancia.extras = json.dumps(extras_atuais, ensure_ascii=False)


def _valor_coluna_modulo(item, col, carregar_extras):
    if col["origem"] == "fixo":
        return getattr(item, col["campo_fixo"], None)
    vex = carregar_extras(item)
    return vex.get(col["campo_extra"].chave)


def aplicar_filtros_modulo(itens, colunas, carregar_extras):
    """Preenche cada coluna (fixa OU personalizada) com as opções de filtro que já
    existem nos dados de verdade — sem precisar de nenhuma lista pré-cadastrada — e
    devolve os itens já filtrados conforme os parâmetros da URL (?f_<coluna>=valor).
    Genérico: funciona pra Switch, Impressoras, Telefonia e qualquer tela nova de
    linhas e colunas que vier a existir, sem precisar escrever nada específico."""
    for col in colunas:
        param = "f_" + col["chave"].replace(":", "__")
        col["param"] = param
        valores = {
            str(_valor_coluna_modulo(it, col, carregar_extras))
            for it in itens if _valor_coluna_modulo(it, col, carregar_extras)
        }
        # Coluna de IP: ordem de IP de verdade (.1, .6, .11...), igual à Listar Máquinas
        col["opcoes"] = sorted(valores, key=chave_ordenacao_ip) if col.get("chave") == "ip" else sorted(valores)
        col["valor_filtro"] = request.args.get(param, "Todos")

    filtrados = []
    for it in itens:
        ok = True
        for col in colunas:
            if col["valor_filtro"] != "Todos":
                valor_atual = str(_valor_coluna_modulo(it, col, carregar_extras) or "")
                if valor_atual != col["valor_filtro"]:
                    ok = False
                    break
        if ok:
            filtrados.append(it)
    return filtrados


# ------------------------------------------------- MENU / MÓDULOS EXTRAS ----

@app.route("/admin/menu")
@login_required
@admin_required
def admin_menu():
    itens = [i for i in estrutura_menu() if not i.get("so_geral") or eh_geral()]
    return render_template("admin_menu.html", itens=itens, icones=ICONES_MENU)


@app.route("/admin/menu/criar", methods=["POST"])
@login_required
@admin_required
def admin_menu_criar():
    nome = request.form.get("nome", "").strip()
    icone = request.form.get("icone", "lista")
    if not nome:
        flash("Dê um nome pro novo item de menu.", "erro")
        return redirect(url_for("admin_menu"))
    if icone not in ICONES_MENU:
        icone = "lista"

    slug = slugify(nome)
    base_slug = slug or "modulo"
    n = 1
    while ModuloPersonalizado.query.filter_by(slug=slug).first() or slug in ("switch", "impressoras", "telefonia", "maquina"):
        n += 1
        slug = f"{base_slug}-{n}"

    maior_ordem = db.session.query(db.func.max(ModuloPersonalizado.ordem)).scalar() or 0
    db.session.add(ModuloPersonalizado(slug=slug, nome=nome, icone=icone, ordem=maior_ordem + 1))
    db.session.commit()
    flash(f"Item '{nome}' criado no menu. Já pode cadastrar colunas e registros nele.", "ok")
    return redirect(url_for("admin_menu"))


@app.route("/admin/menu/personalizado/<int:modulo_id>/renomear", methods=["POST"])
@login_required
@admin_required
def admin_menu_renomear(modulo_id):
    m = ModuloPersonalizado.query.get_or_404(modulo_id)
    nome = request.form.get("nome", "").strip()
    icone = request.form.get("icone", m.icone)
    if nome:
        m.nome = nome
    if icone in ICONES_MENU:
        m.icone = icone
    db.session.commit()
    flash("Item de menu atualizado.", "ok")
    return redirect(url_for("admin_menu"))


@app.route("/admin/menu/personalizado/<int:modulo_id>/excluir", methods=["POST"])
@login_required
@admin_required
def admin_menu_excluir(modulo_id):
    m = ModuloPersonalizado.query.get_or_404(modulo_id)
    RegistroModulo.query.filter_by(modulo_id=m.id).delete()
    ColunaOculta.query.filter_by(tipo=m.slug).delete()
    OrdemColuna.query.filter_by(tipo=m.slug).delete()
    CampoExtra.query.filter_by(tipo=m.slug).delete()
    db.session.delete(m)
    db.session.commit()
    flash(f"Item '{m.nome}' removido do menu (e todos os registros dele).", "ok")
    return redirect(url_for("admin_menu"))


@app.route("/admin/menu/personalizado/<int:modulo_id>/mover/<direcao>", methods=["POST"])
@login_required
@admin_required
def admin_menu_mover(modulo_id, direcao):
    modulos = ModuloPersonalizado.query.order_by(ModuloPersonalizado.ordem).all()
    posicao = next((i for i, m in enumerate(modulos) if m.id == modulo_id), None)
    if posicao is None:
        abort(404)
    alvo = posicao - 1 if direcao == "cima" else posicao + 1
    if 0 <= alvo < len(modulos):
        modulos[posicao].ordem, modulos[alvo].ordem = modulos[alvo].ordem, modulos[posicao].ordem
        db.session.commit()
    return redirect(url_for("admin_menu"))


@app.route("/admin/menu/ordem/<direcao>", methods=["POST"])
@login_required
@admin_required
def admin_menu_ordem(direcao):
    """Sobe/desce QUALQUER item do menu (fixo ou personalizado)."""
    chave = request.form.get("chave", "")
    todos = estrutura_menu()
    item = next((i for i in todos if _chave_ordem_menu(i) == chave), None)
    if not item or direcao not in ("cima", "baixo"):
        abort(404)
    todos = [i for i in todos if not i.get("so_geral") or eh_geral()]
    chaves = [_chave_ordem_menu(i) for i in todos]
    pos = chaves.index(chave)
    alvo = pos - 1 if direcao == "cima" else pos + 1
    if 0 <= alvo < len(chaves):
        chaves[pos], chaves[alvo] = chaves[alvo], chaves[pos]
        # grava a posição de todos, pra ordem ficar estável
        existentes = {c.chave: c for c in ItemMenuConfig.query.all()}
        for i, ch in enumerate(chaves):
            c = existentes.get(ch)
            if not c:
                c = ItemMenuConfig(chave=ch)
                db.session.add(c)
            c.posicao = 1000 + i
        db.session.commit()
    return redirect(url_for("admin_menu"))


@app.route("/admin/menu/ordem-salvar", methods=["POST"])
@login_required
@admin_required
def admin_menu_ordem_salvar():
    """Recebe a ordem completa do menu (arrastar e soltar em Gerenciar Menu).
    Corpo JSON: {"ordem": ["cadastrar", "listar", "mod:contatos", ...]}."""
    dados = request.get_json(silent=True) or {}
    nova = [str(c) for c in dados.get("ordem", [])]
    validas = {_chave_ordem_menu(i) for i in estrutura_menu() if not i.get("so_geral") or eh_geral()}
    if not nova or set(nova) != validas or len(nova) != len(validas):
        return {"ok": False, "erro": "Lista do menu inválida. Recarregue a página."}, 400
    existentes = {c.chave: c for c in ItemMenuConfig.query.all()}
    for i, ch in enumerate(nova):
        c = existentes.get(ch)
        if not c:
            c = ItemMenuConfig(chave=ch)
            db.session.add(c)
        c.posicao = 1000 + i
    db.session.commit()
    return {"ok": True}


@app.route("/admin/menu/fixo/<chave>", methods=["POST"])
@login_required
@admin_required
def admin_menu_item_fixo(chave):
    if chave not in CHAVES_MENU_FIXAS or (chave == "auditoria" and not eh_geral()):
        abort(404)
    c = ItemMenuConfig.query.filter_by(chave=chave).first()
    if not c:
        c = ItemMenuConfig(chave=chave)
        db.session.add(c)
    acao = request.form.get("acao")
    if acao == "renomear":
        nome = request.form.get("nome", "").strip()
        c.nome = nome or None
    elif acao == "alternar" and chave != "ger_menu":
        c.visivel = not (c.visivel if c.visivel is not None else True)
    elif acao == "icone":
        icone = request.form.get("icone", "")
        c.icone = icone if icone in ICONES_MENU else None
    db.session.commit()
    flash("Item de menu atualizado.", "ok")
    return redirect(url_for("admin_menu"))


@app.route("/modulo/<slug>", methods=["GET", "POST"])
@login_required
def modulo_generico(slug):
    m = ModuloPersonalizado.query.filter_by(slug=slug).first_or_404()

    if request.method == "POST" and "btn_gravar" in request.form:
        id_edit = request.form.get("id_edit", "").strip()
        dados = {}
        for chave_campo, valor in request.form.items():
            if chave_campo.startswith("extra_"):
                dados[chave_campo[len("extra_"):]] = valor.strip()
        if id_edit:
            r = RegistroModulo.query.get_or_404(int(id_edit))
            r.extras = json.dumps(dados)
            flash("Registro atualizado.", "ok")
        else:
            db.session.add(RegistroModulo(modulo_id=m.id, extras=json.dumps(dados)))
            flash("Registro cadastrado.", "ok")
        db.session.commit()
        return redirect(url_for("modulo_generico", slug=slug))

    itens = RegistroModulo.query.filter_by(modulo_id=m.id).order_by(RegistroModulo.id).all()
    colunas = estrutura_colunas(slug)
    itens = aplicar_filtros_modulo(itens, colunas, carregar_extras)
    return render_template(
        "modulo_generico.html", modulo=m, itens=itens, colunas=colunas,
        extras=campos_extra_lista(slug), carregar_extras=carregar_extras,
    )


@app.route("/modulo/<slug>/excluir/<int:item_id>", methods=["POST"])
@login_required
def modulo_generico_excluir(slug, item_id):
    r = RegistroModulo.query.get_or_404(item_id)
    db.session.delete(r)
    db.session.commit()
    flash("Registro excluído.", "ok")
    return redirect(url_for("modulo_generico", slug=slug))


@app.route("/modulo/<slug>/pdf")
@login_required
def modulo_generico_pdf(slug):
    m = ModuloPersonalizado.query.filter_by(slug=slug).first_or_404()
    itens = RegistroModulo.query.filter_by(modulo_id=m.id).order_by(RegistroModulo.id).all()
    extras = campos_extra_lista(slug)
    return _exportar_tabela(
        f"Inventário — {m.nome}", dados_modulo([], extras, itens, carregar_extras), f"sisparque_{slug}",
        lambda: gerar_pdf_modulo(f"Inventário — {m.nome}", [], extras, itens, carregar_extras))


@app.route("/switch", methods=["GET", "POST"])
@login_required
def switch_page():
    if request.method == "POST" and "btn_gravar" in request.form:
        id_edit = request.form.get("id_edit", "").strip()
        if id_edit:
            s = Switch.query.get_or_404(int(id_edit))
            _salvar_campos_dinamicos(s, "switch")
            flash("Switch atualizado.", "ok")
        else:
            s = Switch()
            _salvar_campos_dinamicos(s, "switch")
            db.session.add(s)
            flash("Switch cadastrado.", "ok")
        db.session.commit()
        return redirect(url_for("switch_page"))

    if request.method == "POST" and "btn_gravar_contato" in request.form:
        id_edit = request.form.get("id_contato_edit", "").strip()
        dados = dict(
            empresa=request.form.get("empresa", "").strip(),
            telefone=request.form.get("telefone", "").strip(),
            email=request.form.get("email", "").strip(),
            obs=request.form.get("obs", "").strip(),
        )
        if id_edit:
            c = ContatoSwitch.query.get_or_404(int(id_edit))
            for k, v in dados.items():
                setattr(c, k, v)
        else:
            db.session.add(ContatoSwitch(**dados))
        db.session.commit()
        flash("Contato salvo.", "ok")
        return redirect(url_for("switch_page"))

    itens = Switch.query.order_by(Switch.id).all()
    colunas = estrutura_colunas("switch")
    itens = aplicar_filtros_modulo(itens, colunas, carregar_extras)
    contatos = ContatoSwitch.query.order_by(ContatoSwitch.empresa).all()
    return render_template(
        "switch.html", itens=itens, contatos=contatos, setores=opcoes("setor"),
        campos=campos_visiveis("switch"), extras=campos_extra_lista("switch"),
        colunas=colunas,
        carregar_extras=carregar_extras,
    )


@app.route("/switch/contato/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_contato_switch(item_id):
    c = ContatoSwitch.query.get_or_404(item_id)
    db.session.delete(c)
    db.session.commit()
    flash("Contato excluído.", "ok")
    return redirect(url_for("switch_page"))


@app.route("/switch/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_switch(item_id):
    s = Switch.query.get_or_404(item_id)
    registrar_exclusao("Switch", f"Chave: {s.chave or '-'} / {s.rack_departamento or '-'}", dados=_snapshot_modelo(s))
    db.session.delete(s)
    db.session.commit()
    flash("Switch excluído.", "ok")
    return redirect(url_for("switch_page"))


@app.route("/switch/pdf")
@login_required
def switch_pdf():
    itens = Switch.query.order_by(Switch.id).all()
    contatos = [
        {"nome": c.empresa, "telefone": c.telefone, "email": c.email, "obs": c.obs}
        for c in ContatoSwitch.query.order_by(ContatoSwitch.empresa).all()
    ]
    campos, extras = campos_visiveis("switch"), campos_extra_lista("switch")
    return _exportar_tabela(
        "Inventário de Switches", dados_modulo(campos, extras, itens, carregar_extras), "sisparque_switches",
        lambda: gerar_pdf_modulo("Inventário de Switches", campos, extras, itens, carregar_extras, contatos=contatos),
        contatos=contatos)


@app.route("/switch/<int:item_id>/etiqueta")
@login_required
def etiqueta_switch(item_id):
    """Gera a etiqueta (PDF) do switch. Não gera se o Nível RCC ainda não foi
    escolhido — o sistema nunca decide isso sozinho."""
    s = Switch.query.get_or_404(item_id)
    if not s.nivel_rcc:
        flash("Defina o Nível RCC deste switch antes de gerar a etiqueta.", "erro")
        return redirect(url_for("switch_page"))
    buffer = gerar_etiqueta_switch(s)
    nome_arquivo = f"etiqueta_switch_{s.chave or ('switch-' + str(s.id))}.pdf"
    return send_file(
        buffer, as_attachment=False, download_name=nome_arquivo,
        mimetype="application/pdf",
    )


# --------------------------------------------------------- IMPRESSORAS ----

@app.route("/impressoras", methods=["GET", "POST"])
@login_required
def impressoras_page():
    if request.method == "POST" and "btn_gravar" in request.form:
        id_edit = request.form.get("id_edit", "").strip()
        ip_novo = request.form.get("ip", "").strip()
        conflitos = equipamentos_com_ip(ip_novo, "impressora", int(id_edit) if id_edit.isdigit() else None)
        if conflitos:
            flash(mensagem_ip_duplicado(ip_novo, conflitos), "erro")
            return redirect(url_for("impressoras_page"))
        if id_edit:
            i = Impressora.query.get_or_404(int(id_edit))
            _salvar_campos_dinamicos(i, "impressora")
            flash("Impressora atualizada.", "ok")
        else:
            i = Impressora()
            _salvar_campos_dinamicos(i, "impressora")
            db.session.add(i)
            flash("Impressora cadastrada.", "ok")
        db.session.commit()
        return redirect(url_for("impressoras_page"))

    if request.method == "POST" and "btn_gravar_contato" in request.form:
        id_edit = request.form.get("id_contato_edit", "").strip()
        dados = dict(
            empresa=request.form.get("empresa", "").strip(),
            telefone=request.form.get("telefone", "").strip(),
            email=request.form.get("email", "").strip(),
            obs=request.form.get("obs", "").strip(),
        )
        if id_edit:
            c = ContatoTI.query.get_or_404(int(id_edit))
            for k, v in dados.items():
                setattr(c, k, v)
        else:
            db.session.add(ContatoTI(**dados))
        db.session.commit()
        flash("Contato salvo.", "ok")
        return redirect(url_for("impressoras_page"))

    itens = sorted(Impressora.query.order_by(Impressora.id).all(), key=lambda x: chave_ordenacao_ip(x.ip))  # IP em ordem crescente
    colunas = estrutura_colunas("impressora")
    itens = aplicar_filtros_modulo(itens, colunas, carregar_extras)
    contatos = ContatoTI.query.order_by(ContatoTI.empresa).all()
    return render_template(
        "impressoras.html", itens=itens, contatos=contatos,
        setores=opcoes("setor"), modelos=opcoes("modelo_impressora"), toners=opcoes("toner_impressora"),
        campos=campos_visiveis("impressora"), extras=campos_extra_lista("impressora"),
        colunas=colunas,
        carregar_extras=carregar_extras,
    )


@app.route("/impressoras/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_impressora(item_id):
    i = Impressora.query.get_or_404(item_id)
    registrar_exclusao("Impressora", f"{i.local_printer or '-'} / {i.modelo or '-'} / {i.ip or '-'}", dados=_snapshot_modelo(i))
    db.session.delete(i)
    db.session.commit()
    flash("Impressora excluída.", "ok")
    return redirect(url_for("impressoras_page"))


@app.route("/impressoras/contato/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_contato_ti(item_id):
    c = ContatoTI.query.get_or_404(item_id)
    db.session.delete(c)
    db.session.commit()
    flash("Contato excluído.", "ok")
    return redirect(url_for("impressoras_page"))


@app.route("/impressoras/pdf")
@login_required
def impressoras_pdf():
    itens = sorted(Impressora.query.order_by(Impressora.id).all(), key=lambda x: chave_ordenacao_ip(x.ip))  # IP em ordem crescente
    contatos = [
        {"nome": c.empresa, "telefone": c.telefone, "email": c.email, "obs": c.obs}
        for c in ContatoTI.query.order_by(ContatoTI.empresa).all()
    ]
    campos, extras = campos_visiveis("impressora"), campos_extra_lista("impressora")
    return _exportar_tabela(
        "Inventário de Impressoras", dados_modulo(campos, extras, itens, carregar_extras), "sisparque_impressoras",
        lambda: gerar_pdf_modulo("Inventário de Impressoras", campos, extras, itens, carregar_extras, contatos=contatos),
        contatos=contatos)


# ----------------------------------------------------------- TELEFONIA ----

@app.route("/telefonia", methods=["GET", "POST"])
@login_required
def telefonia_page():
    if request.method == "POST" and "btn_gravar" in request.form:
        id_edit = request.form.get("id_edit", "").strip()
        ip_novo = request.form.get("ip", "").strip()
        conflitos = equipamentos_com_ip(ip_novo, "telefone", int(id_edit) if id_edit.isdigit() else None)
        if conflitos:
            flash(mensagem_ip_duplicado(ip_novo, conflitos), "erro")
            return redirect(url_for("telefonia_page"))
        if id_edit:
            t = Telefone.query.get_or_404(int(id_edit))
            _salvar_campos_dinamicos(t, "telefone")
            flash("Aparelho atualizado.", "ok")
        else:
            t = Telefone()
            _salvar_campos_dinamicos(t, "telefone")
            db.session.add(t)
            flash("Aparelho cadastrado.", "ok")
        db.session.commit()
        return redirect(url_for("telefonia_page"))

    if request.method == "POST" and "btn_gravar_contato" in request.form:
        id_edit = request.form.get("id_contato_edit", "").strip()
        dados = dict(
            servico_empresa=request.form.get("servico_empresa", "").strip(),
            numero=request.form.get("numero", "").strip(),
            contato_tecnico=request.form.get("contato_tecnico", "").strip(),
            email_suporte=request.form.get("email_suporte", "").strip(),
            observacoes=request.form.get("observacoes", "").strip(),
        )
        if id_edit:
            c = ContatoTelefonia.query.get_or_404(int(id_edit))
            for k, v in dados.items():
                setattr(c, k, v)
        else:
            db.session.add(ContatoTelefonia(**dados))
        db.session.commit()
        flash("Contato salvo.", "ok")
        return redirect(url_for("telefonia_page"))

    itens = sorted(Telefone.query.order_by(Telefone.id).all(), key=lambda x: chave_ordenacao_ip(x.ip))  # IP em ordem crescente
    colunas = estrutura_colunas("telefone")
    itens = aplicar_filtros_modulo(itens, colunas, carregar_extras)
    contatos = ContatoTelefonia.query.order_by(ContatoTelefonia.id.desc()).all()
    return render_template(
        "telefonia.html", itens=itens, contatos=contatos,
        campos=campos_visiveis("telefone"), extras=campos_extra_lista("telefone"),
        colunas=colunas, modelos_telefone=opcoes("modelo_telefone"),
        carregar_extras=carregar_extras,
    )


@app.route("/telefonia/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_telefone(item_id):
    t = Telefone.query.get_or_404(item_id)
    registrar_exclusao("Telefone", f"Ramal: {t.ramal or '-'} / {t.modelo or '-'}", dados=_snapshot_modelo(t))
    db.session.delete(t)
    db.session.commit()
    flash("Aparelho excluído.", "ok")
    return redirect(url_for("telefonia_page"))


@app.route("/telefonia/contato/excluir/<int:item_id>", methods=["POST"])
@login_required
def excluir_contato_telefonia(item_id):
    c = ContatoTelefonia.query.get_or_404(item_id)
    db.session.delete(c)
    db.session.commit()
    flash("Contato excluído.", "ok")
    return redirect(url_for("telefonia_page"))


@app.route("/telefonia/pdf")
@login_required
def telefonia_pdf():
    itens = sorted(Telefone.query.order_by(Telefone.id).all(), key=lambda x: chave_ordenacao_ip(x.ip))  # IP em ordem crescente
    contatos = [
        {"nome": c.servico_empresa, "telefone": c.numero, "email": c.email_suporte, "obs": c.observacoes}
        for c in ContatoTelefonia.query.order_by(ContatoTelefonia.servico_empresa).all()
    ]
    campos, extras = campos_visiveis("telefone"), campos_extra_lista("telefone")
    return _exportar_tabela(
        "Inventário de Telefonia", dados_modulo(campos, extras, itens, carregar_extras), "sisparque_telefonia",
        lambda: gerar_pdf_modulo("Inventário de Telefonia", campos, extras, itens, carregar_extras, contatos=contatos),
        contatos=contatos)


# ---------------------------------------------- EDITAR COLUNAS (dinâmicas) ---

@app.route("/admin/campos/<tipo>", methods=["GET", "POST"])
@login_required
@editar_colunas_required
def admin_campos(tipo):
    eh_modulo_personalizado = ModuloPersonalizado.query.filter_by(slug=tipo).first() is not None
    if tipo not in CAMPOS_FIXOS_POR_TIPO and not eh_modulo_personalizado:
        abort(404)
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        if nome:
            chave = slugify(nome)
            if not CampoExtra.query.filter_by(tipo=tipo, chave=chave).first():
                maior_ordem = db.session.query(db.func.max(CampoExtra.ordem)).filter_by(tipo=tipo).scalar() or 0
                db.session.add(CampoExtra(tipo=tipo, nome=nome, chave=chave, ordem=maior_ordem + 1))
                db.session.commit()
                flash("Nova coluna criada.", "ok")
            else:
                flash("Já existe uma coluna com esse nome.", "erro")
        return redirect(url_for("admin_campos", tipo=tipo))

    obrigatorios = CAMPOS_OBRIGATORIOS_POR_TIPO.get(tipo, set())
    sem_renomear = MAQUINA_CAMPOS_VIA_CONFIGURACOES if tipo == "maquina" else set()
    # Nem todo campo_fixo tem o mesmo nome do 'tipo' usado em Configurações
    # (ex: campo é 'departamento_setor', mas a lista de opções é 'setor').
    mapa_campo_para_tipo_opcao = {"departamento_setor": "setor"}
    colunas = estrutura_colunas(tipo, incluir_ocultos=True)
    for item in colunas:
        if item["origem"] == "fixo":
            item["sem_renomear"] = item["campo_fixo"] in sem_renomear
            item["obrigatorio"] = item["campo_fixo"] in obrigatorios
            item["tipo_opcao"] = mapa_campo_para_tipo_opcao.get(item["campo_fixo"], item["campo_fixo"])
    nomes_pagina = {"switch": "Switch", "impressora": "Impressoras", "telefone": "Telefonia", "maquina": "Máquinas",
                    "recebimento": "Recebimentos (itens)"}
    if eh_modulo_personalizado:
        nomes_pagina[tipo] = ModuloPersonalizado.query.filter_by(slug=tipo).first().nome
    return render_template(
        "admin_campos.html", tipo=tipo, titulo=nomes_pagina.get(tipo, tipo),
        colunas=colunas,
        voltar_url=url_for("recebimentos.lista") if tipo == "recebimento" else url_for("dashboard"),
    )


@app.route("/admin/campos/<tipo>/renomear/<chave>", methods=["POST"])
@login_required
@editar_colunas_required
def admin_renomear_campo(tipo, chave):
    if tipo == "maquina" and chave in MAQUINA_CAMPOS_VIA_CONFIGURACOES:
        flash("Esse campo é renomeado em Configurações, não aqui.", "erro")
        return redirect(url_for("admin_campos", tipo=tipo))
    novo_rotulo = request.form.get("rotulo", "").strip()
    if novo_rotulo:
        chave_rotulo = f"campo_{tipo}_{chave}"
        r = RotuloCategoria.query.filter_by(tipo=chave_rotulo).first()
        if not r:
            r = RotuloCategoria(tipo=chave_rotulo)
            db.session.add(r)
        r.rotulo = novo_rotulo
        db.session.commit()
        flash("Coluna renomeada.", "ok")
    return redirect(url_for("admin_campos", tipo=tipo))


@app.route("/admin/campos/<tipo>/ocultar/<chave>", methods=["POST"])
@login_required
@editar_colunas_required
def admin_alternar_coluna(tipo, chave):
    if chave in CAMPOS_OBRIGATORIOS_POR_TIPO.get(tipo, set()):
        flash("Esse campo é obrigatório e não pode ser ocultado (mas pode ser movido de posição).", "erro")
        return redirect(url_for("admin_campos", tipo=tipo))
    existente = ColunaOculta.query.filter_by(tipo=tipo, chave=chave).first()
    if existente:
        db.session.delete(existente)
        flash("Coluna voltou a aparecer.", "ok")
    else:
        db.session.add(ColunaOculta(tipo=tipo, chave=chave))
        flash("Coluna ocultada (os dados continuam salvos, só não aparecem mais).", "ok")
    db.session.commit()
    return redirect(url_for("admin_campos", tipo=tipo))


@app.route("/admin/campos/<tipo>/restaurar", methods=["POST"])
@login_required
@editar_colunas_required
def admin_restaurar_colunas(tipo):
    """Rede de segurança: volta a mostrar todas as colunas 'de fábrica' de um tipo e
    zera qualquer ordem customizada, caso algo tenha ficado oculto sem querer."""
    if tipo not in CAMPOS_FIXOS_POR_TIPO and not ModuloPersonalizado.query.filter_by(slug=tipo).first():
        abort(404)
    ColunaOculta.query.filter_by(tipo=tipo).delete()
    OrdemColuna.query.filter_by(tipo=tipo).delete()
    db.session.commit()
    flash("Colunas restauradas para o padrão (todas visíveis, ordem original).", "ok")
    return redirect(url_for("admin_campos", tipo=tipo))


@app.route("/admin/campos/<tipo>/mover/<path:chave>/<direcao>", methods=["POST"])
@login_required
@editar_colunas_required
def admin_mover_coluna(tipo, chave, direcao):
    """Move uma coluna (de fábrica OU personalizada) uma posição pra cima ou pra baixo
    na ordem de exibição — as duas compartilham a mesma sequência agora."""
    if direcao not in ("cima", "baixo"):
        abort(404)
    if tipo not in CAMPOS_FIXOS_POR_TIPO and not ModuloPersonalizado.query.filter_by(slug=tipo).first():
        abort(404)

    colunas = estrutura_colunas(tipo, incluir_ocultos=True)
    ordem_padrao = {item["chave"]: i for i, item in enumerate(colunas)}
    registros = {o.chave: o for o in OrdemColuna.query.filter_by(tipo=tipo).all()}

    for item in colunas:
        if item["chave"] not in registros:
            novo = OrdemColuna(tipo=tipo, chave=item["chave"], ordem=ordem_padrao[item["chave"]])
            db.session.add(novo)
            registros[item["chave"]] = novo
    db.session.flush()

    ordenados = sorted(registros.values(), key=lambda r: r.ordem)
    posicao = next((i for i, r in enumerate(ordenados) if r.chave == chave), None)
    if posicao is None:
        abort(404)

    alvo = posicao - 1 if direcao == "cima" else posicao + 1
    if 0 <= alvo < len(ordenados):
        ordenados[posicao].ordem, ordenados[alvo].ordem = ordenados[alvo].ordem, ordenados[posicao].ordem

    db.session.commit()
    return redirect(url_for("admin_campos", tipo=tipo))


@app.route("/admin/campos/<tipo>/reordenar", methods=["POST"])
@login_required
@editar_colunas_required
def admin_reordenar_colunas(tipo):
    """Recebe a ordem completa das colunas (arrastar e soltar em Editar Colunas)
    e grava de uma vez. Corpo JSON: {"ordem": ["chave1", "chave2", ...]}."""
    if tipo not in CAMPOS_FIXOS_POR_TIPO and not ModuloPersonalizado.query.filter_by(slug=tipo).first():
        abort(404)
    dados = request.get_json(silent=True) or {}
    nova_ordem = [str(c) for c in dados.get("ordem", [])]
    validas = {item["chave"] for item in estrutura_colunas(tipo, incluir_ocultos=True)}
    if not nova_ordem or set(nova_ordem) != validas:
        return {"ok": False, "erro": "Lista de colunas inválida. Recarregue a página."}, 400
    registros = {o.chave: o for o in OrdemColuna.query.filter_by(tipo=tipo).all()}
    for posicao, chave in enumerate(nova_ordem):
        reg = registros.get(chave)
        if not reg:
            reg = OrdemColuna(tipo=tipo, chave=chave)
            db.session.add(reg)
        reg.ordem = posicao
    db.session.commit()
    return {"ok": True}


@app.route("/admin/campos/<tipo>/excluir_extra/<int:campo_id>", methods=["POST"])
@login_required
@editar_colunas_required
def admin_excluir_campo_extra(tipo, campo_id):
    campo = CampoExtra.query.get_or_404(campo_id)
    tipo_bak, nome_bak, chave_bak, ordem_bak = campo.tipo, campo.nome, campo.chave, campo.ordem
    db.session.delete(campo)
    db.session.commit()
    link_desfazer = url_for("admin_desfazer_campo_extra", tipo=tipo_bak, nome=nome_bak, chave=chave_bak, ordem=ordem_bak)
    flash(Markup(f'Coluna removida. <a href="{link_desfazer}" style="text-decoration:underline;">Desfazer</a>'), "ok")
    return redirect(url_for("admin_campos", tipo=tipo))


@app.route("/admin/campos/desfazer_extra", methods=["GET"])
@login_required
@editar_colunas_required
def admin_desfazer_campo_extra():
    tipo = request.args.get("tipo", "")
    nome = request.args.get("nome", "")
    chave = request.args.get("chave", "")
    ordem = int(request.args.get("ordem", 0))
    if not (tipo and nome and chave):
        abort(400)
    if not CampoExtra.query.filter_by(tipo=tipo, chave=chave).first():
        db.session.add(CampoExtra(tipo=tipo, nome=nome, chave=chave, ordem=ordem))
        db.session.commit()
        flash("Coluna restaurada — os dados que já estavam preenchidos nela voltam a aparecer.", "ok")
    else:
        flash("Já existe uma coluna com essa chave — não deu pra desfazer.", "erro")
    return redirect(url_for("admin_campos", tipo=tipo))


# ------------------------------------------------------- ADMINISTRAÇÃO ----

@app.route("/admin/usuarios")
@login_required
@admin_required
def admin_usuarios():
    usuarios = Usuario.query.order_by(Usuario.nome_completo).all()
    return render_template("admin_usuarios.html", usuarios=usuarios, existe_geral=existe_geral(),
                           pode_gerir_admins=pode_gerir_admins(), agora=datetime.now())


@app.route("/admin/usuarios/assumir-geral", methods=["POST"])
@login_required
@admin_required
def admin_assumir_geral():
    """Só funciona enquanto NINGUÉM é Administrador geral (logo depois de atualizar)."""
    if existe_geral():
        flash("Já existe um Administrador geral.", "erro")
        return redirect(url_for("admin_usuarios"))
    current_user.is_geral = True
    current_user.is_admin = True
    db.session.commit()
    flash("Pronto: você agora é o Administrador geral do sistema.", "ok")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/usuarios/desbloquear/<int:usuario_id>", methods=["POST"])
@login_required
@admin_required
def admin_desbloquear_usuario(usuario_id):
    u = Usuario.query.get_or_404(usuario_id)
    if u.is_geral and not eh_geral():
        flash("Só o próprio Administrador geral pode alterar o cadastro dele.", "erro")
        return redirect(url_for("admin_usuarios"))
    u.falhas_login = 0
    u.bloqueado_ate = None
    db.session.commit()
    flash(f"Usuário {u.display_name} desbloqueado.", "ok")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/usuarios/cadastrar", methods=["GET", "POST"])
@login_required
@admin_required
def admin_cadastrar_usuario():
    if request.method == "POST":
        nip = request.form.get("nip", "").strip()
        if Usuario.query.filter_by(nip=nip).first():
            flash("Já existe um usuário com esse NIP.", "erro")
            return redirect(url_for("admin_cadastrar_usuario"))
        quer_admin = bool(request.form.get("is_admin"))
        if quer_admin and not pode_gerir_admins():
            flash("Só o Administrador geral pode criar usuários administradores. O usuário foi criado como comum.", "erro")
            quer_admin = False
        u = Usuario(
            nip=nip,
            nome_completo=request.form.get("nome_completo", "").strip(),
            posto_graduacao=request.form.get("posto_graduacao", "").strip(),
            is_admin=quer_admin,
            pode_mudar_tema=bool(request.form.get("pode_mudar_tema")),
            nome_guerra=request.form.get("nome_guerra", "").strip().upper() or None,
        )
        u.set_senha(request.form.get("senha", "").strip() or "mudar123")
        db.session.add(u)
        db.session.commit()
        flash("Usuário cadastrado.", "ok")
        return redirect(url_for("admin_usuarios"))
    return render_template("admin_cadastro_usuario.html", usuario=None, postos=opcoes("posto_graduacao"),
                           pode_gerir_admins=pode_gerir_admins())


@app.route("/admin/usuarios/editar/<int:usuario_id>", methods=["GET", "POST"])
@login_required
@admin_required
def admin_editar_usuario(usuario_id):
    u = Usuario.query.get_or_404(usuario_id)
    if u.is_geral and not eh_geral():
        flash("Só o próprio Administrador geral pode alterar o cadastro dele.", "erro")
        return redirect(url_for("admin_usuarios"))
    if request.method == "POST":
        u.nome_completo = request.form.get("nome_completo", "").strip()
        u.posto_graduacao = request.form.get("posto_graduacao", "").strip()
        u.nome_guerra = request.form.get("nome_guerra", "").strip().upper() or None
        if u.is_geral:
            u.is_admin = True  # o Administrador geral é sempre administrador
        elif pode_gerir_admins():
            u.is_admin = bool(request.form.get("is_admin"))
        elif bool(request.form.get("is_admin")) != bool(u.is_admin):
            flash("Só o Administrador geral pode tornar alguém administrador ou tirar o administrador. Esse campo não foi alterado.", "erro")
        u.pode_mudar_tema = bool(request.form.get("pode_mudar_tema"))
        nova_senha = request.form.get("senha", "").strip()
        if nova_senha:
            u.set_senha(nova_senha)
        db.session.commit()
        flash("Usuário atualizado.", "ok")
        return redirect(url_for("admin_usuarios"))
    return render_template("admin_cadastro_usuario.html", usuario=u, postos=opcoes("posto_graduacao"),
                           pode_gerir_admins=pode_gerir_admins())


@app.route("/admin/usuarios/excluir/<int:usuario_id>", methods=["POST"])
@login_required
@admin_required
def admin_excluir_usuario(usuario_id):
    if usuario_id == current_user.id:
        flash("Você não pode excluir o próprio usuário logado.", "erro")
        return redirect(url_for("admin_usuarios"))
    u = Usuario.query.get_or_404(usuario_id)
    if u.is_geral:
        flash("O Administrador geral não pode ser excluído.", "erro")
        return redirect(url_for("admin_usuarios"))
    if u.is_admin and not pode_gerir_admins():
        flash("Só o Administrador geral pode excluir um administrador.", "erro")
        return redirect(url_for("admin_usuarios"))
    db.session.delete(u)
    db.session.commit()
    flash("Usuário excluído.", "ok")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/opcoes/<tipo>", methods=["GET", "POST"])
@login_required
@admin_required
def admin_opcoes(tipo):
    if tipo not in TIPOS_OPCAO:
        abort(404)
    if request.method == "POST":
        valor = request.form.get("valor", "").strip()
        cor = request.form.get("cor", "#004080").strip() or "#004080"
        if valor and not OpcaoConfig.query.filter_by(tipo=tipo, valor=valor).first():
            db.session.add(OpcaoConfig(tipo=tipo, valor=valor, cor=cor))
            db.session.commit()
            flash("Item adicionado.", "ok")
        else:
            flash("Esse item já existe ou é inválido.", "erro")
        return redirect(url_for("admin_opcoes", tipo=tipo))
    itens = OpcaoConfig.query.filter_by(tipo=tipo).order_by(OpcaoConfig.valor).all()
    rotulos = rotulos_categorias()
    grupos = [
        ("Máquinas", ["setor", "sistema_operacional", "posto_graduacao", "corpo_quadro", "especialidade",
                      "processador_fabricante", "processador_modelo", "memoria_tipo", "memoria_qtd",
                      "armazenamento_tipo", "armazenamento_capacidade", "armazenamento_interface",
                      "lacre", "disponivel", "lva", "sim_nao"]),
        ("Switch", ["setor"]),
        ("Impressoras", ["modelo_impressora", "toner_impressora"]),
        ("Telefonia", ["modelo_telefone"]),
        ("Recebimentos", ["rec_origem", "rec_material", "rec_marca", "rec_destino_externo"]),
    ]
    return render_template(
        "admin_opcoes.html", tipo=tipo, titulo=rotulos[tipo], itens=itens,
        tipos=TIPOS_OPCAO, rotulos=rotulos, grupos=grupos,
    )


@app.route("/admin/opcoes/<tipo>/renomear", methods=["POST"])
@login_required
@admin_required
def admin_renomear_categoria(tipo):
    if tipo not in TIPOS_OPCAO:
        abort(404)
    novo_rotulo = request.form.get("rotulo", "").strip()
    if novo_rotulo:
        r = RotuloCategoria.query.filter_by(tipo=tipo).first()
        if not r:
            r = RotuloCategoria(tipo=tipo)
            db.session.add(r)
        r.rotulo = novo_rotulo
        db.session.commit()
        flash("Nome do botão atualizado.", "ok")
    return redirect(url_for("admin_opcoes", tipo=tipo))


@app.route("/admin/opcoes/<tipo>/cor/<int:opcao_id>", methods=["POST"])
@login_required
@admin_required
def admin_alterar_cor_opcao(tipo, opcao_id):
    o = OpcaoConfig.query.get_or_404(opcao_id)
    cor = request.form.get("cor", "").strip()
    if cor:
        o.cor = cor
        db.session.commit()
        flash("Cor atualizada.", "ok")
    return redirect(url_for("admin_opcoes", tipo=tipo))


@app.route("/admin/opcoes/<tipo>/excluir/<int:opcao_id>", methods=["POST"])
@login_required
@admin_required
def admin_excluir_opcao(tipo, opcao_id):
    o = OpcaoConfig.query.get_or_404(opcao_id)
    tipo_bak, valor_bak, cor_bak = o.tipo, o.valor, o.cor
    db.session.delete(o)
    db.session.commit()
    link_desfazer = url_for("admin_desfazer_opcao", tipo=tipo_bak, valor=valor_bak, cor=cor_bak or "")
    flash(Markup(f'Item removido. <a href="{link_desfazer}" style="text-decoration:underline;">Desfazer</a>'), "ok")
    return redirect(url_for("admin_opcoes", tipo=tipo))


@app.route("/admin/opcoes/desfazer", methods=["GET"])
@login_required
@admin_required
def admin_desfazer_opcao():
    tipo = request.args.get("tipo", "")
    valor = request.args.get("valor", "")
    cor = request.args.get("cor", "") or None
    if not (tipo and valor):
        abort(400)
    if not OpcaoConfig.query.filter_by(tipo=tipo, valor=valor).first():
        db.session.add(OpcaoConfig(tipo=tipo, valor=valor, cor=cor))
        db.session.commit()
        flash("Item restaurado.", "ok")
    else:
        flash("Esse item já existe na lista — não deu pra desfazer.", "erro")
    return redirect(url_for("admin_opcoes", tipo=tipo))


@app.route("/admin/sistema", methods=["GET", "POST"])
@login_required
@admin_required
def admin_configuracao_sistema():
    cfg = ConfiguracaoSistema.query.first()
    if not cfg:
        cfg = ConfiguracaoSistema()
        db.session.add(cfg)
        db.session.commit()
    if request.method == "POST":
        cfg.nome_sistema = request.form.get("nome_sistema", "").strip() or "SISPARQUE"
        cfg.versao = VERSAO_SISTEMA
        cfg.desenvolvedor = request.form.get("desenvolvedor", "").strip()
        cfg.ano = request.form.get("ano", "").strip()
        cfg.mensagem_rodape = request.form.get("mensagem_rodape", "").strip()
        cfg.finalidade = request.form.get("finalidade", "").strip()
        cfg.popup_login_ativo = request.form.get("popup_login_ativo") == "1"
        db.session.commit()
        flash("Pop-up atualizado.", "ok")
    # a tela do pop-up agora fica dentro de "Tela de Login"
    return redirect(url_for("admin_textos_login", _anchor="popup"))


@app.route("/configuracao/aparencia")
@login_required
@tema_required
def config_aparencia():
    cfg = ConfiguracaoSistema.query.first()
    return render_template("aparencia.html", cfg=cfg)


@app.route("/admin/configuracao/modo-visual/<modo>", methods=["POST"])
@login_required
@tema_required
def admin_modo_visual(modo):
    if modo not in ("padrao", "marinho"):
        abort(404)
    cfg = ConfiguracaoSistema.query.first() or ConfiguracaoSistema()
    cfg.modo_visual = modo
    if not cfg.id:
        db.session.add(cfg)
    db.session.commit()
    flash("Aparência do sistema alterada para " + ("Azul Marinho." if modo == "marinho" else "Verde Musgo (padrão)."), "ok")
    return redirect(request.referrer or url_for("config_aparencia"))


def aparar_bordas_transparentes(caminho):
    """Corta a "sobra" transparente em volta da imagem (PNG/WEBP com fundo
    transparente). Muitos brasões vêm com uma margem vazia enorme, e aí aparecem
    pequenos e com um buraco embaixo na tela de login. Não mexe em JPG/SVG nem em
    imagem que já está justa. Nunca dá erro: se não conseguir, deixa como está."""
    try:
        from PIL import Image
        if not caminho.lower().endswith((".png", ".webp")) or not os.path.exists(caminho):
            return False
        with Image.open(caminho) as im:
            if im.mode not in ("RGBA", "LA", "P"):
                return False
            rgba = im.convert("RGBA")
        caixa = rgba.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
        if not caixa or caixa == (0, 0) + rgba.size:
            return False
        rgba.crop(caixa).save(caminho)
        return True
    except Exception:
        return False


def _aparar_brasoes_existentes():
    for nome in os.listdir(os.path.join(BASE_DIR, "static", "login_custom")) if os.path.isdir(os.path.join(BASE_DIR, "static", "login_custom")) else []:
        if nome.startswith("brasao."):
            aparar_bordas_transparentes(os.path.join(BASE_DIR, "static", "login_custom", nome))
    aparar_bordas_transparentes(os.path.join(BASE_DIR, "static", "heraldica.png"))


_aparar_brasoes_existentes()

_CORES_LOGIN = ("verde_musgo", "marinho")


@app.route("/admin/configuracao/tela-login/cor", methods=["POST"])
@login_required
@admin_required
def admin_tela_login_cor():
    """Troca a cor da tela de login: Verde Musgo (padrão) ou Azul Marinho."""
    cor = request.form.get("cor", "verde_musgo")
    if cor not in _CORES_LOGIN:
        abort(404)
    cfg = ConfiguracaoSistema.query.first() or ConfiguracaoSistema()
    cfg.login_cor = cor
    if not cfg.id:
        db.session.add(cfg)
    db.session.commit()
    flash("Cor da tela de login atualizada.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="cor"))


_PASTA_LOGIN_IMAGENS = os.path.join(BASE_DIR, "static", "login_custom")
_SLOTS_LOGIN_IMAGENS = {
    "brasao": "login_brasao_ext",
    "fundo": "login_fundo_ext",
    "esquerda": "login_esquerda_ext",
    "direita": "login_direita_ext",
}
_EXTENSOES_IMAGEM_PERMITIDAS = {"png", "jpg", "jpeg", "webp", "svg"}


@app.route("/admin/configuracao/tela-login")
@login_required
@admin_required
def admin_tela_login():
    """Mantido só por compatibilidade com links antigos — a tela de verdade
    agora é só uma, dentro de Configurações (evita duas cópias do mesmo
    formulário saindo de sincronia como aconteceu com o card do Brasão)."""
    return redirect(url_for("admin_textos_login", _anchor="imagens"))


@app.route("/admin/configuracao/tela-login/enviar/<slot>", methods=["POST"])
@login_required
@admin_required
def admin_tela_login_enviar(slot):
    if slot not in _SLOTS_LOGIN_IMAGENS:
        abort(404)
    arquivo = request.files.get("imagem")
    if not arquivo or not arquivo.filename:
        flash("Selecione uma imagem.", "erro")
        return redirect(url_for("admin_textos_login", _anchor="imagens"))

    ext = os.path.splitext(arquivo.filename)[1].lower().lstrip(".")
    if ext not in _EXTENSOES_IMAGEM_PERMITIDAS:
        flash("Formato não suportado. Use PNG, JPG, WEBP ou SVG.", "erro")
        return redirect(url_for("admin_textos_login", _anchor="imagens"))

    try:
        os.makedirs(_PASTA_LOGIN_IMAGENS, exist_ok=True)
        caminho_novo = os.path.join(_PASTA_LOGIN_IMAGENS, f"{slot}.{ext}")
        # Salva a imagem nova ANTES de mexer em qualquer arquivo antigo — se a
        # extensão for a mesma de antes, isso já sobrescreve sem precisar apagar
        # nada (evita travar no Windows, que às vezes não deixa apagar e recriar
        # o mesmo arquivo na sequência se algo ainda estiver "segurando" ele).
        arquivo.save(caminho_novo)
        if slot in ("brasao", "esquerda", "direita"):
            aparar_bordas_transparentes(caminho_novo)
        for ext_antiga in _EXTENSOES_IMAGEM_PERMITIDAS:
            if ext_antiga == ext:
                continue
            caminho_antigo = os.path.join(_PASTA_LOGIN_IMAGENS, f"{slot}.{ext_antiga}")
            if os.path.exists(caminho_antigo):
                try:
                    os.remove(caminho_antigo)
                except OSError:
                    pass  # não trava o upload novo por causa de um arquivo antigo preso
    except PermissionError:
        flash(
            "Sem permissão pra salvar arquivo nessa pasta do servidor. Rode no terminal "
            "do servidor: sudo chown -R sisparque:sisparque /opt/sisparque "
            "(e depois reinicie o serviço).",
            "erro",
        )
        return redirect(url_for("admin_textos_login", _anchor="imagens"))
    except Exception as e:
        flash(f"Não consegui salvar a imagem: {e}", "erro")
        return redirect(url_for("admin_textos_login", _anchor="imagens"))

    cfg = ConfiguracaoSistema.query.first() or ConfiguracaoSistema()
    setattr(cfg, _SLOTS_LOGIN_IMAGENS[slot], ext)
    setattr(cfg, f"login_{slot}_ativo", True)
    if not cfg.id:
        db.session.add(cfg)
    db.session.commit()
    flash("Imagem atualizada.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="imagens"))


@app.route("/admin/configuracao/tela-login/alternar/<slot>", methods=["POST"])
@login_required
@admin_required
def admin_tela_login_alternar(slot):
    """Liga/desliga um slot sem apagar o arquivo — pode reativar depois com 1 clique."""
    if slot not in _SLOTS_LOGIN_IMAGENS:
        abort(404)
    cfg = ConfiguracaoSistema.query.first()
    if cfg:
        campo_ativo = f"login_{slot}_ativo"
        setattr(cfg, campo_ativo, not getattr(cfg, campo_ativo))
        db.session.commit()
        flash("Imagem escondida." if not getattr(cfg, campo_ativo) else "Imagem reativada.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="imagens"))


@app.route("/admin/configuracao/tela-login/opacidade/<slot>", methods=["POST"])
@login_required
@admin_required
def admin_tela_login_opacidade(slot):
    if slot not in _SLOTS_LOGIN_IMAGENS:
        abort(404)
    try:
        valor = max(0, min(100, int(request.form.get("opacidade", 20))))
    except ValueError:
        valor = 20
    cfg = ConfiguracaoSistema.query.first()
    if cfg:
        setattr(cfg, f"login_{slot}_opacidade", valor)
        if slot == "fundo":
            modo = request.form.get("modo", "cover")
            if modo not in ("cover", "contain", "stretch", "tile", "center", "span"):
                modo = "cover"
            cfg.login_fundo_modo = modo
            cfg.login_fundo_pb = bool(request.form.get("pb"))
            cfg.login_fundo_painel = bool(request.form.get("painel"))
        db.session.commit()
        flash("Configurações da imagem atualizadas.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="imagens"))


@app.route("/admin/configuracao/tela-login/remover/<slot>", methods=["POST"])
@login_required
@admin_required
def admin_tela_login_remover(slot):
    """Apaga o arquivo de vez (diferente de só ocultar) — pra quem quer trocar de imagem
    do zero, sem deixar arquivo antigo perdido na pasta."""
    if slot not in _SLOTS_LOGIN_IMAGENS:
        abort(404)
    cfg = ConfiguracaoSistema.query.first()
    if cfg:
        ext = getattr(cfg, _SLOTS_LOGIN_IMAGENS[slot])
        if ext:
            caminho = os.path.join(_PASTA_LOGIN_IMAGENS, f"{slot}.{ext}")
            if os.path.exists(caminho):
                try:
                    os.remove(caminho)
                except OSError:
                    pass  # se o arquivo estiver preso, ainda assim desvincula do banco abaixo
        setattr(cfg, _SLOTS_LOGIN_IMAGENS[slot], None)
        db.session.commit()
        flash("Imagem removida.", "ok")
    return redirect(url_for("admin_textos_login", _anchor="imagens"))


@app.route("/admin/banco-de-dados")
@login_required
@admin_required
def admin_banco_dados():
    caminho_db = os.path.join(BASE_DIR, "sisparque.db")
    tamanho_kb = round(os.path.getsize(caminho_db) / 1024, 1) if os.path.exists(caminho_db) else 0
    return render_template("admin_banco_dados.html", tamanho_kb=tamanho_kb,
                           ips_duplicados=ips_duplicados_maquinas())


def ips_duplicados_maquinas():
    """Lista os IPs que aparecem em mais de uma máquina — para corrigir à mão o que
    entrou ANTES desta trava existir. Retorna [(ip, [maquinas...]), ...]."""
    grupos = {}
    for m in Maquina.query.order_by(Maquina.id).all():
        ip = (m.ip or "").strip()
        if ip:
            grupos.setdefault(ip, []).append(m)
    duplicados = [(ip, ms) for ip, ms in grupos.items() if len(ms) > 1]
    duplicados.sort(key=lambda par: chave_ordenacao_ip(par[0]))
    return duplicados


@app.route("/admin/banco-de-dados/exportar-tudo")
@login_required
@admin_required
def admin_exportar_tudo():
    """Plano B: TODOS os dados do sistema numa planilha só (uma aba para cada
    assunto), em Excel (.xlsx) ou LibreOffice Calc (.ods), já pronta para imprimir."""
    formato = request.args.get("formato", "xlsx")
    if formato not in _MIME_PLANILHA:
        abort(404)
    cfg = ConfiguracaoSistema.query.first()
    definir_tema_planilha(cfg.modo_visual if cfg else "padrao")
    abas = []

    maquinas = sorted(Maquina.query.order_by(Maquina.id).all(), key=lambda m: chave_ordenacao_ip(m.ip))
    abas.append(planilha_de_tabela("Máquinas", dados_maquinas(maquinas, rotulos_renomeados_maquina())))

    hist = [["ID Máquina", "Nome", "Num Máquina", "Setor", "Data", "Descrição", "Registrado por"]]
    for m in maquinas:
        if (m.historico_manutencao or "").strip():
            hist.append([m.id, m.nome_completo, m.num_maquina or "-", m.departamento_setor or "-",
                         "-", "(histórico antigo) " + m.historico_manutencao.strip(), "-"])
        for h in sorted(m.historicos, key=lambda x: (x.data or "", x.id)):
            data_br = "-"
            if h.data:
                try:
                    data_br = datetime.strptime(h.data, "%Y-%m-%d").strftime("%d/%m/%Y")
                except ValueError:
                    data_br = h.data
            hist.append([m.id, m.nome_completo, m.num_maquina or "-", m.departamento_setor or "-",
                         data_br, h.descricao, h.usuario_nome or "-"])
    abas.append(planilha_de_tabela("Histórico de Manutenção", hist))

    for titulo, modelo, tipo, contatos in [
        ("Switches", Switch, "switch",
         [{"nome": c.empresa, "telefone": c.telefone, "email": c.email, "obs": c.obs} for c in ContatoSwitch.query.all()]),
        ("Impressoras", Impressora, "impressora",
         [{"nome": c.empresa, "telefone": c.telefone, "email": c.email, "obs": c.obs} for c in ContatoTI.query.all()]),
        ("Telefonia", Telefone, "telefone",
         [{"nome": c.servico_empresa, "telefone": c.numero, "email": c.email_suporte, "obs": c.observacoes}
          for c in ContatoTelefonia.query.all()]),
    ]:
        itens = modelo.query.order_by(modelo.id).all()
        if hasattr(modelo, "ip"):
            itens.sort(key=lambda x: chave_ordenacao_ip(x.ip))  # mesmo padrão das telas: IP crescente
        dados = dados_modulo(campos_visiveis(tipo), campos_extra_lista(tipo), itens, carregar_extras)
        abas.append(planilha_de_tabela(titulo, dados, dados_contatos(contatos) if contatos else None))

    for mod in ModuloPersonalizado.query.order_by(ModuloPersonalizado.ordem).all():
        itens = RegistroModulo.query.filter_by(modulo_id=mod.id).order_by(RegistroModulo.id).all()
        abas.append(planilha_de_tabela(mod.nome, dados_modulo([], campos_extra_lista(mod.slug), itens, carregar_extras)))

    try:
        from recebimentos import db as rec_db, entregue_por_item
        ent = entregue_por_item()
        rec = [["Lote", "Chegada", "Origem", "Documento", "Material", "Tipo / Marca", "Modelo",
                "Qtd", "Nº de série", "Situação", "Destino", "Entregue", "Saldo"]]
        for r in rec_db().execute("""SELECT l.titulo, l.data_chegada, l.origem, l.documento, i.*
                                       FROM rec_item i JOIN rec_lote l ON l.id = i.lote_id
                                      ORDER BY l.data_chegada, l.id, i.id"""):
            e = ent.get(r["id"], 0)
            rec.append([r["titulo"], r["data_chegada"] or "-", r["origem"] or "-", r["documento"] or "-",
                        r["material"], r["tipo"] or "-", r["modelo"] or "-", r["qtd"] or 0, r["serie"] or "-",
                        r["situacao"] or "-", r["destino"] or "-", e, (r["qtd"] or 0) - e])
        abas.append(planilha_de_tabela("Recebimentos", rec))
    except Exception:
        pass  # sem o módulo de recebimentos: exporta o resto normalmente

    usuarios = [["NIP ou CPF", "Nome", "Posto / Graduação", "Administrador"]] + [
        [u.nip, u.nome_completo, u.posto_graduacao or "-", "Sim" if u.is_admin else "Não"]
        for u in Usuario.query.order_by(Usuario.nome_completo).all()]
    abas.append(planilha_de_tabela("Usuários", usuarios))

    conteudo = pasta_xlsx(abas) if formato == "xlsx" else pasta_ods(abas)
    nome = "sisparque_tudo_%s.%s" % (datetime.now().strftime("%Y-%m-%d"), formato)
    return send_file(_BytesIO(conteudo), as_attachment=True, download_name=nome,
                     mimetype=_MIME_PLANILHA[formato])


@app.route("/admin/banco-de-dados/backup")
@login_required
@admin_required
def admin_backup_download():
    caminho_db = os.path.join(BASE_DIR, "sisparque.db")
    nome = f"sisparque_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    return send_file(caminho_db, as_attachment=True, download_name=nome, mimetype="application/octet-stream")


# Extensões que o importador realmente sabe ler. Formatos de outros bancos
# (Access, ODB, SQL Server) exigiriam bibliotecas/drivers que não existem
# neste ambiente — por isso não aparecem aqui (ver aviso na tela).
_EXTENSOES_IMPORT_SQL = {".sql"}
_EXTENSOES_IMPORT_SQLITE = {".db", ".db3", ".sqlite", ".sqlite3"}


@app.route("/admin/banco-de-dados/importar", methods=["POST"])
@login_required
@admin_required
def admin_importar_banco():
    from flask import g
    g.sem_auditoria = True   # importação em massa: registra só o resumo, não milhares de linhas
    arquivo = request.files.get("arquivo_importacao")
    if arquivo and arquivo.filename:
        registrar_evento("Importou banco", "Banco de Dados", f"Importação do arquivo {arquivo.filename[:150]}")
    if not arquivo or not arquivo.filename:
        flash("Selecione um arquivo para importar.", "erro")
        return redirect(url_for("admin_banco_dados"))

    nome = arquivo.filename
    ext = os.path.splitext(nome)[1].lower()
    caminho_db = os.path.join(BASE_DIR, "sisparque.db")

    if ext in _EXTENSOES_IMPORT_SQL:
        # Dump .sql do sistema antigo (phpMyAdmin/MariaDB) — usa o migrador existente.
        pasta_tmp = os.path.join(BASE_DIR, "dados_originais")
        os.makedirs(pasta_tmp, exist_ok=True)
        caminho_tmp = os.path.join(pasta_tmp, "importacao_manual.sql")
        arquivo.save(caminho_tmp)
        try:
            # Backup de segurança antes de mexer em qualquer coisa (igual ao .db).
            if os.path.exists(caminho_db):
                db.session.commit()
                seguranca = os.path.join(
                    BASE_DIR, f"sisparque_antes_importacao_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                )
                shutil.copy2(caminho_db, seguranca)
            from migrar_dados import migrar
            # Sempre substitui e segue a mesma regra do sistema antigo (setor VAGO não entra),
            # para o total bater exatamente com o que o SISPARQUE antigo mostrava.
            resumo = migrar(app, caminho_tmp, substituir=True, ignorar_setor_vago=True) or {}
            flash(
                f"Importação do .sql concluída: "
                f"{resumo.get('maquinas', 0)} máquinas, {resumo.get('switches', 0)} switches, "
                f"{resumo.get('impressoras', 0)} impressoras, {resumo.get('telefones', 0)} ramais. "
                "Um backup do banco anterior foi salvo na pasta do sistema.",
                "ok",
            )
        except Exception as e:
            db.session.rollback()
            flash(f"Falha ao importar o .sql: {e}", "erro")
        return redirect(url_for("admin_banco_dados"))

    if ext in _EXTENSOES_IMPORT_SQLITE:
        # Banco SQLite completo (ex.: backup gerado por este próprio botão).
        # Faz backup de segurança do banco atual antes de substituir.
        try:
            db.session.remove()
            db.engine.dispose()
            if os.path.exists(caminho_db):
                seguranca = os.path.join(
                    BASE_DIR, f"sisparque_antes_importacao_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                )
                shutil.copy2(caminho_db, seguranca)
            # Grava num arquivo novo e troca de uma vez (os.replace): assim não depende
            # de permissão de escrita no sisparque.db antigo, só na pasta do sistema.
            caminho_novo = caminho_db + ".novo"
            arquivo.save(caminho_novo)
            os.replace(caminho_novo, caminho_db)
            flash("Banco de dados SQLite importado com sucesso. Um backup do banco anterior foi salvo na pasta do sistema.", "ok")
        except Exception as e:
            flash(f"Falha ao importar o banco: {e}", "erro")
        return redirect(url_for("admin_banco_dados"))

    flash(
        f"Extensão '{ext}' não é suportada para importação direta neste sistema. "
        "Aceitos: .sql (backup do phpMyAdmin) ou .db / .db3 / .sqlite / .sqlite3 "
        "(banco SQLite completo). Para outros formatos, exporte antes para .sql ou .sqlite.",
        "erro",
    )
    return redirect(url_for("admin_banco_dados"))


@app.route("/admin/banco-de-dados/remover-duplicados", methods=["POST"])
@login_required
@admin_required
def admin_remover_duplicados():
    """Corrige duplicatas já geradas por importações antigas de .sql (Switch/Impressora/
    Telefonia não tinham checagem de duplicata antes desta correção)."""
    removidos = {"switch": 0, "impressora": 0, "telefone": 0}

    vistos = set()
    for s in Switch.query.order_by(Switch.id).all():
        # chave + rack: vários racks diferentes podem usar a mesma chave
        chave = ((s.chave or "").strip(), (s.rack_departamento or "").strip(), (s.lacres or "").strip())
        if not any(chave):
            continue
        if chave in vistos:
            db.session.delete(s)
            removidos["switch"] += 1
        else:
            vistos.add(chave)

    vistos = set()
    for i in Impressora.query.order_by(Impressora.id).all():
        ip = (i.ip or "").strip()
        if not ip:
            continue
        if ip in vistos:
            db.session.delete(i)
            removidos["impressora"] += 1
        else:
            vistos.add(ip)

    vistos = set()
    for t in Telefone.query.order_by(Telefone.id).all():
        ramal = ((t.ramal or "").strip(), (t.ip or "").strip(), (t.local or "").strip())
        if not ramal[0]:
            continue
        if ramal in vistos:
            db.session.delete(t)
            removidos["telefone"] += 1
        else:
            vistos.add(ramal)

    db.session.commit()
    total = sum(removidos.values())
    if total:
        flash(
            f"Duplicatas removidas: {removidos['switch']} switch(es), "
            f"{removidos['impressora']} impressora(s), {removidos['telefone']} telefone(s).",
            "ok",
        )
    else:
        flash("Nenhuma duplicata encontrada.", "ok")
    return redirect(url_for("admin_banco_dados"))


@app.route("/admin/log-exclusoes")
@login_required
@admin_required
def admin_log_exclusoes():
    logs = LogExclusao.query.order_by(LogExclusao.data_hora.desc()).all()
    return render_template("admin_log_exclusoes.html", logs=logs)


_MODELO_POR_TIPO_LOG = {
    "Máquina": Maquina, "Switch": Switch, "Impressora": Impressora, "Telefone": Telefone,
}


@app.route("/admin/log-exclusoes/restaurar/<int:log_id>", methods=["POST"])
@login_required
@admin_required
def admin_restaurar_exclusao(log_id):
    log = LogExclusao.query.get_or_404(log_id)
    if log.restaurado:
        flash("Este item já foi restaurado antes.", "erro")
        return redirect(url_for("admin_log_exclusoes"))
    if not log.dados_json:
        flash("Não é possível restaurar: esta exclusão é de antes do recurso de restauração existir.", "erro")
        return redirect(url_for("admin_log_exclusoes"))
    Modelo = _MODELO_POR_TIPO_LOG.get(log.tipo_objeto)
    if not Modelo:
        flash("Tipo de registro não suportado para restauração.", "erro")
        return redirect(url_for("admin_log_exclusoes"))
    dados = json.loads(log.dados_json)
    if Modelo is Maquina:
        conflitos = maquinas_com_ip(dados.get("ip"))
        if conflitos:
            flash(mensagem_ip_duplicado((dados.get("ip") or "").strip(), conflitos)
                  .replace("Nada foi salvo — use outro IP.",
                           "A máquina não foi restaurada. Libere esse IP primeiro."), "erro")
            return redirect(url_for("admin_log_exclusoes"))
    novo = Modelo(**dados)
    db.session.add(novo)
    log.restaurado = True
    db.session.commit()
    flash("Registro restaurado com sucesso.", "ok")
    return redirect(url_for("admin_log_exclusoes"))


@app.route("/admin/log-exclusoes/apagar/<int:log_id>", methods=["POST"])
@login_required
@admin_required
def admin_apagar_log_exclusao(log_id):
    """Apaga a LINHA do histórico de auditoria (não afeta o item em si — se ele
    já foi restaurado, continua restaurado; se não foi, continua excluído do
    inventário). Só tira essa entrada da lista de auditoria, sem volta."""
    log = LogExclusao.query.get_or_404(log_id)
    db.session.delete(log)
    db.session.commit()
    flash("Registro do histórico apagado permanentemente.", "ok")
    return redirect(url_for("admin_log_exclusoes"))


def _auto_importar_dados_iniciais():
    """
    Se o banco estiver vazio (primeira execução), importa automaticamente o
    backup do sistema antigo (dados_originais/sisparque_backup.sql), incluindo
    máquinas, switches, impressoras, telefonia e usuários já cadastrados —
    sem precisar rodar migrar_dados.py na mão.

    Roda no nível do módulo (não dentro de "if __name__ == '__main__'") para
    funcionar tanto com "python app.py" quanto com Waitress/Gunicorn, que
    apenas importam este arquivo sem executar esse bloco.
    """
    with app.app_context():
        if Maquina.query.count() > 0:
            return  # já tem dados, não faz nada (evita duplicar em cada reinício)
        caminho_sql = os.path.join(BASE_DIR, "dados_originais", "sisparque_backup.sql")
        if not os.path.exists(caminho_sql):
            return  # não veio backup junto com o pacote, segue sem importar
        try:
            from migrar_dados import migrar
            print(">> Banco vazio detectado — importando dados do sistema antigo automaticamente...")
            migrar(app, caminho_sql)
        except Exception as e:
            print(f">> Aviso: não foi possível importar os dados automaticamente ({e}).")
            print(">> Você ainda pode importar manualmente com: python migrar_dados.py dados_originais/sisparque_backup.sql")


# Executa sempre que o módulo é carregado (python app.py, serve_waitress.py, gunicorn, etc.)
seed_admin(app)


def _definir_geral_inicial():
    """Depois de atualizar: se ainda não há Administrador geral e existe UM só
    administrador, ele vira o Administrador geral. Com mais de um, o primeiro que
    clicar em 'Assumir' (tela Usuários) fica com o posto."""
    with app.app_context():
        try:
            if Usuario.query.filter_by(is_geral=True).first():
                return
            admins = Usuario.query.filter_by(is_admin=True).all()
            if len(admins) == 1:
                admins[0].is_geral = True
                db.session.commit()
        except Exception:
            db.session.rollback()


_definir_geral_inicial()
# Importação automática DESLIGADA: ela enchia um banco vazio com um .sql antigo
# guardado em dados_originais/, sem avisar (por isso apareciam números "estranhos").
# Agora um banco vazio fica vazio; para trazer dados use Banco de Dados → Importar.
# _auto_importar_dados_iniciais()



# ------------------------------------------------- LIMPEZA AUTOMÁTICA DA AUDITORIA ----
# A auditoria guarda SEMPRE os últimos 12 meses. Uma vez por dia o sistema apaga só o
# que passou disso (sem arquivo morto). Mexe só no auditoria.db. Cada limpeza deixa
# uma linha na própria auditoria dizendo quanto foi apagado.
AUDITORIA_GUARDAR_DIAS = 365
_LIMPEZA = {"dia": None, "vigia": False}


def limpar_auditoria_antiga():
    from datetime import timedelta
    with app.app_context():
        limite = datetime.now() - timedelta(days=AUDITORIA_GUARDAR_DIAS)
        n = LogAuditoria.query.filter(LogAuditoria.quando < limite).delete(synchronize_session=False)
        if n:
            db.session.add(LogAuditoria(
                quando=datetime.now(), usuario_nome="Sistema", acao="Limpeza automática", tipo="Auditoria",
                descricao=f"Limpeza automática: {n} registro(s) com mais de 12 meses (anteriores a {limite:%d/%m/%Y})"))
        db.session.commit()
        return n


def _vigia_limpeza():
    while True:
        try:
            hoje = datetime.now().date()
            if _LIMPEZA["dia"] != hoje:
                limpar_auditoria_antiga()
                _LIMPEZA["dia"] = hoje
        except Exception as e:
            print(f">> AVISO: falha na limpeza da auditoria: {e}")
        time.sleep(3600)


@app.before_request
def _iniciar_limpeza_auditoria():
    if not _LIMPEZA["vigia"]:
        _LIMPEZA["vigia"] = True
        _threading.Thread(target=_vigia_limpeza, name="sisparque-limpeza", daemon=True).start()


# ---------------------------------------------------- REVITALIZAÇÃO VENCIDA ----
def _data_revit(texto):
    texto = (texto or "").strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%Y", "%Y"):
        try:
            return datetime.strptime(texto, fmt).date()
        except ValueError:
            continue
    return None


def revitalizacao_vencida(m, hoje=None):
    """Data de revitalização já passou (máquinas em LVA não contam: já estão saindo)."""
    if (m.lva or "").strip().lower() == "sim":
        return False
    d = _data_revit(m.data_revitalizacao)
    return bool(d and d <= (hoje or datetime.now().date()))


# ------------------------------------------------------------------ ABAS ----
# Abas no topo das telas (hoje: Rede). Como no Drupal: abas do sistema (renomeia, não
# exclui) + abas criadas pelo admin, do tipo LINK (abre um endereço) ou NOTA (página
# de anotações). Excluir manda pra lixeira; só o Administrador geral restaura.
# Tudo fica na Auditoria (quem, quando, de qual computador).
ABAS_SISTEMA = {
    "rede": [("status", "Status (ligados e desligados)", "painel_rede"),
             ("faixa", "Faixa de IP", "faixa_ip")],
}
NOMES_PAGINA_ABAS = {"rede": "Rede"}


def _garantir_abas(pagina):
    existentes = {a.chave_sistema for a in AbaPagina.query.filter_by(pagina=pagina).filter(AbaPagina.chave_sistema.isnot(None))}
    novas = False
    for i, (chave, rotulo, _ep) in enumerate(ABAS_SISTEMA.get(pagina, [])):
        if chave not in existentes:
            db.session.add(AbaPagina(pagina=pagina, chave_sistema=chave, rotulo=rotulo, tipo="sistema", ordem=i))
            novas = True
    if novas:
        g.sem_auditoria = True
        db.session.commit()
        g.sem_auditoria = False


def pode_editar_abas():
    if not (current_user.is_authenticated and current_user.is_admin):
        return False
    if eh_geral() or not existe_geral():
        return True
    cfg = ConfiguracaoSistema.query.first()
    return bool(cfg and cfg.abas_admins_podem)


def abas_da_pagina(pagina):
    """Lista pronta pro template: rótulo, link, se abre em nova aba e a chave (pra marcar a ativa)."""
    _garantir_abas(pagina)
    endpoints = {c: ep for c, _r, ep in ABAS_SISTEMA.get(pagina, [])}
    saida = []
    for a in AbaPagina.query.filter_by(pagina=pagina, excluida=False).order_by(AbaPagina.ordem, AbaPagina.id):
        if a.tipo == "sistema":
            if a.chave_sistema not in endpoints:
                continue
            href, nova, chave = url_for(endpoints[a.chave_sistema]), False, a.chave_sistema
        elif a.tipo == "link":
            href, nova, chave = (a.url or "#"), True, f"aba-{a.id}"
        else:
            href, nova, chave = url_for("aba_nota", aba_id=a.id), False, f"aba-{a.id}"
        saida.append({"rotulo": a.rotulo, "href": href, "nova": nova, "chave": chave})
    return saida


app.jinja_env.globals["abas_da_pagina"] = abas_da_pagina
app.jinja_env.globals["pode_editar_abas"] = pode_editar_abas


def _url_segura(url):
    url = (url or "").strip()
    if not url:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "http://" + url
    return url if re.match(r"^https?://", url, re.I) else ""


@app.route("/abas/<pagina>", methods=["GET", "POST"])
@login_required
@admin_required
def gerenciar_abas(pagina):
    if pagina not in ABAS_SISTEMA:
        abort(404)
    if not pode_editar_abas():
        flash("Só o Administrador geral mexe nas abas (ele pode liberar para os administradores).", "erro")
        return redirect(url_for("painel_rede"))
    _garantir_abas(pagina)
    nome_pag = NOMES_PAGINA_ABAS.get(pagina, pagina)
    if request.method == "POST":
        acao = request.form.get("acao")
        aba = db.session.get(AbaPagina, int(request.form.get("id") or 0)) if request.form.get("id") else None
        if aba is not None and aba.pagina != pagina:
            abort(404)
        quem = current_user.display_name
        if acao == "renomear" and aba:
            novo = (request.form.get("rotulo") or "").strip()[:60]
            if novo and novo != aba.rotulo:
                antigo, aba.rotulo = aba.rotulo, novo
                if aba.tipo == "link":
                    aba.url = _url_segura(request.form.get("url")) or aba.url
                db.session.commit()
                registrar_evento("Renomeou aba", "Abas", f"{nome_pag}: \"{antigo}\" → \"{novo}\"", objeto_id=aba.id)
                flash("Aba renomeada.", "ok")
            elif aba.tipo == "link" and request.form.get("url") is not None:
                u = _url_segura(request.form.get("url"))
                if u and u != aba.url:
                    aba.url = u; db.session.commit()
                    registrar_evento("Alterou link da aba", "Abas", f"{nome_pag}: \"{aba.rotulo}\" → {u}", objeto_id=aba.id)
                    flash("Link atualizado.", "ok")
        elif acao == "criar":
            tipo = request.form.get("tipo")
            rotulo = (request.form.get("rotulo") or "").strip()[:60]
            url = _url_segura(request.form.get("url")) if tipo == "link" else None
            if tipo not in ("link", "nota") or not rotulo:
                flash("Informe o nome da aba e o tipo.", "erro")
            elif tipo == "link" and not url:
                flash("Informe um endereço válido (http:// ou https://).", "erro")
            else:
                ordem = (db.session.query(db.func.max(AbaPagina.ordem)).filter_by(pagina=pagina).scalar() or 0) + 1
                nova = AbaPagina(pagina=pagina, rotulo=rotulo, tipo=tipo, url=url, ordem=ordem, criado_por=quem)
                db.session.add(nova); db.session.commit()
                registrar_evento("Criou aba", "Abas", f"{nome_pag}: \"{rotulo}\" ({'link: ' + url if url else 'anotações'})", objeto_id=nova.id)
                flash(f"Aba \"{rotulo}\" criada.", "ok")
        elif acao in ("subir", "descer") and aba:
            lista = AbaPagina.query.filter_by(pagina=pagina, excluida=False).order_by(AbaPagina.ordem, AbaPagina.id).all()
            i = lista.index(aba); j = i - 1 if acao == "subir" else i + 1
            if 0 <= j < len(lista):
                lista[i], lista[j] = lista[j], lista[i]
                for n, a in enumerate(lista):
                    a.ordem = n
                db.session.commit()
        elif acao == "excluir" and aba:
            if aba.tipo == "sistema":
                flash("As abas do sistema não podem ser excluídas (pode renomear).", "erro")
            else:
                aba.excluida, aba.excluida_em, aba.excluida_por = True, datetime.now(), quem
                db.session.commit()
                registrar_evento("Excluiu aba", "Abas", f"{nome_pag}: \"{aba.rotulo}\" (foi pra lixeira)", objeto_id=aba.id)
                flash(f"Aba \"{aba.rotulo}\" foi para a lixeira.", "ok")
        elif acao == "restaurar" and aba:
            if not eh_geral():
                flash("Só o Administrador geral restaura abas da lixeira.", "erro")
            else:
                aba.excluida, aba.excluida_em, aba.excluida_por = False, None, None
                db.session.commit()
                registrar_evento("Restaurou aba", "Abas", f"{nome_pag}: \"{aba.rotulo}\"", objeto_id=aba.id)
                flash(f"Aba \"{aba.rotulo}\" restaurada.", "ok")
        elif acao == "permissao" and eh_geral():
            cfg = ConfiguracaoSistema.query.first()
            cfg.abas_admins_podem = request.form.get("valor") == "1"
            db.session.commit()
            registrar_evento("Permissão de abas", "Segurança",
                             "Administradores " + ("PODEM" if cfg.abas_admins_podem else "NÃO podem") + " criar/renomear/excluir abas")
            flash("Permissão atualizada.", "ok")
        return redirect(url_for("gerenciar_abas", pagina=pagina))

    abas = AbaPagina.query.filter_by(pagina=pagina, excluida=False).order_by(AbaPagina.ordem, AbaPagina.id).all()
    lixeira = AbaPagina.query.filter_by(pagina=pagina, excluida=True).order_by(AbaPagina.excluida_em.desc()).all()
    cfg = ConfiguracaoSistema.query.first()
    return render_template("gerenciar_abas.html", pagina=pagina, nome_pag=nome_pag, abas=abas, lixeira=lixeira,
                           admins_podem=bool(cfg and cfg.abas_admins_podem))


@app.route("/abas/nota/<int:aba_id>", methods=["GET", "POST"])
@login_required
@admin_required
def aba_nota(aba_id):
    aba = db.session.get(AbaPagina, aba_id)
    if not aba or aba.tipo != "nota" or aba.excluida:
        abort(404)
    if request.method == "POST":
        if not pode_editar_abas():
            flash("Sem permissão para editar esta página.", "erro")
        else:
            aba.conteudo = request.form.get("conteudo", "")
            db.session.commit()
            registrar_evento("Editou anotações", "Abas", f"{NOMES_PAGINA_ABAS.get(aba.pagina, aba.pagina)}: \"{aba.rotulo}\"", objeto_id=aba.id)
            flash("Anotações salvas.", "ok")
        return redirect(url_for("aba_nota", aba_id=aba.id))
    return render_template("aba_nota.html", aba=aba, editar=request.args.get("editar") == "1" and pode_editar_abas())


if __name__ == "__main__":
    # Em produção use serve_waitress.py (Windows) ou gunicorn (Linux) — ver
    # README_SERVICO_PERMANENTE.md e README_DEPLOY.md. Isto aqui é só para teste local.
    app.run(host="0.0.0.0", port=5000, debug=True)
