import os
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


_PREPOSICOES = {"DA", "DE", "DO", "DAS", "DOS", "E"}


def nome_guerra_automatico(nome_completo, posto=""):
    """Monta um nome de guerra a partir do nome completo, tirando posto/graduação
    e números que às vezes vêm digitados junto (ex.: "1°SG-FN-CN 1.Siqueira").
    Elton Laureia Ribeiro → E.L.RIBEIRO ; 1.L.RIBEIRO → L.RIBEIRO ; 1.Siqueira → SIQUEIRA"""
    import re
    posto = (posto or "").strip().upper()
    partes = []
    for p in (nome_completo or "").strip().split():
        u = p.upper()
        if u == posto or "°" in u or "º" in u or "ª" in u:
            continue
        u = re.sub(r"^\d+[.\-]*", "", u).strip(".-")
        if u and not u.isdigit():
            partes.append(u)
    if not partes:
        return ""
    if len(partes) == 1:
        return partes[0]          # já vem como nome de guerra (ex.: L.RIBEIRO)
    nomes = [p for p in partes[:-1] if p not in _PREPOSICOES]
    return ".".join([p[0] for p in nomes] + [partes[-1]])


class Usuario(db.Model, UserMixin):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nip = db.Column(db.String(20), unique=True, nullable=False)
    nome_completo = db.Column(db.String(150), nullable=False)
    posto_graduacao = db.Column(db.String(30), nullable=False)
    senha_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    # Campo mantido por compatibilidade com bancos antigos, mas não é mais usado
    # pra liberar nada — Editar Colunas / cores voltou a ser exclusivo do admin.
    pode_editar_colunas = db.Column(db.Boolean, default=False)
    # Permissão concedida individualmente pelo admin a um usuário PADRÃO: deixa
    # ele trocar a aparência do sistema (Padrão/Escuro/Claro) sem virar admin.
    pode_mudar_tema = db.Column(db.Boolean, default=False)
    # Nome de guerra (como a pessoa aparece no sistema). Ex.: L.RIBEIRO, SIQUEIRA.
    # Vazio = o sistema monta sozinho a partir do nome completo.
    nome_guerra = db.Column(db.String(60))
    # Administrador geral (dono do sistema): só existe UM. Só ele vê a Auditoria,
    # torna/tira administradores e mexe no próprio cadastro de Administrador geral.
    is_geral = db.Column(db.Boolean, default=False)
    # Bloqueio por senha errada: depois de 5 erros seguidos, o NIP fica travado por 15 minutos.
    falhas_login = db.Column(db.Integer, default=0)
    bloqueado_ate = db.Column(db.DateTime)

    def set_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def check_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)

    def get_id(self):
        return str(self.id)

    @property
    def guerra(self):
        """Nome de guerra: o cadastrado; se vazio, montado do nome completo
        (ignora posto/graduação e números digitados junto do nome)."""
        if (self.nome_guerra or "").strip():
            return self.nome_guerra.strip().upper()
        return nome_guerra_automatico(self.nome_completo, self.posto_graduacao)

    @property
    def display_name(self):
        # Ex: 1°SG-FN-CN L.RIBEIRO
        posto = (self.posto_graduacao or "").strip()
        return f"{posto} {self.guerra}".strip()

    @property
    def iniciais(self):
        """Duas letras do círculo do menu. Ex.: L.RIBEIRO → LR, SIQUEIRA → SI."""
        import re
        letras = [p for p in re.split(r"[\s.]+", self.guerra) if p and p[0].isalpha()]
        if len(letras) >= 2:
            return (letras[0][0] + letras[-1][0]).upper()
        if letras:
            return letras[0][:2].upper()
        return "?"


# Valores usados apenas para popular o banco na primeira execução.
# Depois disso, quem manda são os registros da tabela OpcaoConfig,
# editáveis pela tela de Configurações. Estas listas foram tiradas
# direto dos <option> do cadastro.php original.
POSTOS_GRADUACOES_PADRAO = [
    "VAGO", "AE", "VA", "CA", "CMG", "CF", "CC", "CT", "1°TN", "2°TN", "GM",
    "SO", "1°SG", "2°SG", "3°SG", "CB", "SD-FN", "MN", "RC", "GRUMETE",
]
CORPOS_QUADROS_PADRAO = [
    "VAGO", "CPA", "QPA", "QPAS", "QTPA", "QEAP", "QAP", "QATP", "QTP", "CAP",
    "FN", "QMU", "QEFN", "QCPFN", "CA", "RM2", "RM1", "RM3", "SC", "QC-CA",
    "QC-FN", "IM", "EN", "Md", "CD", "S", "T", "CN", "AA", "AFN",
]
FABRICANTES_PROCESSADOR_PADRAO = ["Intel", "AMD"]
SETORES_PADRAO = [
    "DEPARTAMENTO DE ADM", "BOMBA E BICO", "CPEO", "ASSESSORIA DE QUALIDADE",
    "DIVISÃO DE PESSOAL", "DPCP", "DEPARTAMENTO INDUSTRIAL",
    "DIVISÃO DE APOIO INDUSTRIAL", "DIVISÃO DE ARMAMENTO", "INTELIGÊNCIA",
    "SEG ORG", "ASSESSORIA DE TI", "ITI", "PEP", "QUANTUM_ALOJAMENTO",
    "QUANTUM_SALA_DE_ESTADO", "QUANTUM_OSE", "IMPRESSORA 3D", "VAGO",
    "PROFESP", "COMANDANTE", "AUDITORIO", "IMEDIATO", "SECOM",
    "CENTRO DE MENSAGEM", "DIVISÃO DE MOTOMECANIZACAO", "INTENDÊNCIA",
    "SAÚDE", "ENGENHARIA CIVIL", "ÓTICA E ELETRÔNICA", "ELÉTRICA",
    "DIVISAO DE TRANSPORTES",
]
SISTEMAS_OPERACIONAIS_PADRAO = [
    "Windows-10", "Windows-11", "Ubuntu-22-MB", "Ubuntu-24-MB", "Ubuntu-25-MB",
    "Ubuntu-26-MB", "Ubuntu-27-MB", "Ubuntu-28-MB", "Ubuntu-29-MB",
    "Ubuntu-30-MB", "Oracle", "VMware", "XCP-NG", "VAGO",
]

TIPOS_OPCAO = {
    "posto_graduacao": "Posto / Graduação",
    "corpo_quadro": "Corpo / Quadro",
    "especialidade": "Especialidade",
    "processador_fabricante": "Processador (Fabricante)",
    "processador_modelo": "Processador (Modelo)",
    "lacre": "Lacre",
    "setor": "Departamento / Setor",
    "sistema_operacional": "Sistema Operacional",
    "memoria_tipo": "Memória Tipo",
    "memoria_qtd": "Memória Qtd",
    "armazenamento_tipo": "Armaz. Tipo",
    "armazenamento_capacidade": "Armaz. Capacidade",
    "armazenamento_interface": "Armaz. Interface",
    "disponivel": "Disponível",
    "lva": "LVA (sem conserto)",
    "sim_nao": "Teclado / Mouse (Sim ou Não)",
    "modelo_impressora": "Modelo de Impressora",
    "toner_impressora": "Toner de Impressora",
    "modelo_telefone": "Modelo de Telefone",
    "rec_origem": "Origem do Material",
    "rec_material": "Material Recebido",
    "rec_marca": "Marca do Material",
    "rec_destino_externo": "Destino Externo (OM)",
}

# Valores padrão pra popular cada lista na primeira execução
VALORES_PADRAO_POR_TIPO = {
    "especialidade": ["CN", "ET", "MO", "IF", "CT", "N/C"],
    "processador_modelo": [],
    "lacre": [],
    "memoria_tipo": ["DDR3", "DDR4", "DDR5"],
    "memoria_qtd": ["4GB", "8GB", "12GB", "16GB", "32GB"],
    "armazenamento_tipo": ["HD", "SSD"],
    "armazenamento_capacidade": [
        "120GB", "240GB", "256GB", "480GB", "500GB", "512GB", "1TB", "1.5TB",
        "2TB", "4TB", "6TB", "8TB", "10TB", "12TB", "14TB", "16TB", "18TB",
    ],
    "armazenamento_interface": ["SATA", "NVME"],
    "disponivel": ["Sim", "Não"],
    "lva": ["Sim", "Não"],
    "sim_nao": ["Sim", "Não"],
    "modelo_impressora": ["M3040idn", "M3550idn"],
    "toner_impressora": ["3102", "3122"],
    "modelo_telefone": [],
    "rec_origem": ["Receita Federal", "Doação", "Licitação", "Transferência de OM", "Devolução"],
    "rec_material": ["Desktop", "Notebook", "Monitor", "Servidor", "Impressora", "Switch",
                     "Teclado", "Mouse", "Nobreak", "Estabilizador", "HD / SSD", "Memória RAM", "Cabo"],
    "rec_marca": ["Dell", "HP", "Lenovo", "Positivo", "AOC", "Samsung", "LG", "Daten"],
    "rec_destino_externo": [],
}

# Mantidos por compatibilidade com código antigo (agora refletem os valores padrão)
MEMORIA_TIPOS = VALORES_PADRAO_POR_TIPO["memoria_tipo"]
MEMORIA_QTDS = VALORES_PADRAO_POR_TIPO["memoria_qtd"]
ARMAZENAMENTO_TIPOS = VALORES_PADRAO_POR_TIPO["armazenamento_tipo"]
ARMAZENAMENTO_CAPACIDADES = VALORES_PADRAO_POR_TIPO["armazenamento_capacidade"]
ARMAZENAMENTO_INTERFACES = VALORES_PADRAO_POR_TIPO["armazenamento_interface"]
SIM_NAO = ["Sim", "Não"]

# Níveis de Classificação de Segurança das etiquetas (RCC-1 = servidores/switches/áreas
# sensíveis; RCC-2 e RCC-3 = estações de trabalho de usuário final, por nível).
NIVEIS_RCC = ["RCC-1", "RCC-2", "RCC-3"]


class RotuloCategoria(db.Model):
    """Nome (rótulo) editável de cada botão/categoria da tela de Configurações."""
    __tablename__ = "rotulos_categoria"
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(30), unique=True, nullable=False)
    rotulo = db.Column(db.String(100), nullable=False)


class OpcaoConfig(db.Model):
    """Itens editáveis usados nos selects de cadastro (setor, posto, etc)."""
    __tablename__ = "opcoes_config"
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(30), nullable=False)  # ver TIPOS_OPCAO
    valor = db.Column(db.String(100), nullable=False)
    cor = db.Column(db.String(7), default="#004080")  # usada nas etiquetas de Setor
    __table_args__ = (db.UniqueConstraint("tipo", "valor", name="uq_tipo_valor"),)


class Maquina(db.Model):
    __tablename__ = "maquinas"
    id = db.Column(db.Integer, primary_key=True)
    nome_completo = db.Column(db.String(150), nullable=False)
    nip = db.Column(db.String(20))
    posto_graduacao = db.Column(db.String(30))
    corpo_quadro = db.Column(db.String(20))
    especialidade = db.Column(db.String(60))
    ip = db.Column(db.String(15))
    num_maquina = db.Column(db.String(60))
    mac = db.Column(db.String(20))
    lacre = db.Column(db.String(60))
    processador_fabricante = db.Column(db.String(20))
    processador_modelo = db.Column(db.String(60))
    data_compra = db.Column(db.String(10))
    historico_manutencao = db.Column(db.Text)
    data_revitalizacao = db.Column(db.String(10))
    departamento_setor = db.Column(db.String(80))
    disponivel = db.Column(db.String(3), default="Sim")  # Sim / Não
    lva = db.Column(db.String(3), default="Não")  # Sim / Não — máquina em LVA (sem conserto, inservível)
    num_pat = db.Column(db.String(30))
    sistema_operacional = db.Column(db.String(30))
    # Campos de hardware (existem no sistema PHP original)
    memoria_tipo = db.Column(db.String(10))
    memoria_qtd = db.Column(db.String(10))
    armazenamento_tipo = db.Column(db.String(10))
    armazenamento_capacidade = db.Column(db.String(10))
    armazenamento_interface = db.Column(db.String(10))
    teclado = db.Column(db.String(3), default="Sim")
    mouse = db.Column(db.String(3), default="Sim")
    # Nível de classificação de segurança usado na etiqueta impressa (ver NIVEIS_RCC).
    # Sem valor padrão de propósito — fica em branco até você escolher manualmente.
    nivel_rcc = db.Column(db.String(10))
    extras = db.Column(db.Text)  # JSON com valores das colunas personalizadas criadas pelo admin
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    historicos = db.relationship(
        "HistoricoManutencao", backref="maquina", cascade="all, delete-orphan",
        order_by="desc(HistoricoManutencao.data)",
    )


class HistoricoManutencao(db.Model):
    """Registros datados de manutenção de uma máquina (substitui o campo de texto único)."""
    __tablename__ = "historico_manutencao"
    id = db.Column(db.Integer, primary_key=True)
    maquina_id = db.Column(db.Integer, db.ForeignKey("maquinas.id"), nullable=False)
    data = db.Column(db.String(10))  # aaaa-mm-dd
    descricao = db.Column(db.Text, nullable=False)
    usuario_nome = db.Column(db.String(150))
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)


class LogExclusao(db.Model):
    """Registro de auditoria: quem excluiu o quê e quando (ex: exclusão de máquinas)."""
    __tablename__ = "log_exclusoes"
    id = db.Column(db.Integer, primary_key=True)
    tipo_objeto = db.Column(db.String(30), nullable=False)  # maquina, switch, impressora, telefone...
    descricao = db.Column(db.String(255), nullable=False)  # o que era (nome/IP/etc.)
    usuario_nome = db.Column(db.String(150))
    data_hora = db.Column(db.DateTime, default=datetime.utcnow)
    dados_json = db.Column(db.Text)  # snapshot dos campos do registro, pra permitir restaurar
    restaurado = db.Column(db.Boolean, default=False)


# ----------------------------------------- COLUNAS DINÂMICAS (Switch/Impressora/Telefone) ---

# Campos "de fábrica" de cada tipo — chave interna, rótulo padrão, na ordem de exibição.
# O admin pode renomear e ocultar qualquer um desses pela tela de "Editar Colunas",
# além de criar campos totalmente novos (guardados em CampoExtra/ValorExtra).
CAMPOS_FIXOS_POR_TIPO = {
    "switch": [
        ("chave", "Chave"), ("rack_departamento", "Rack / Departamento"), ("lacres", "Lacres"),
        ("nivel_rcc", "Nível RCC"),
    ],
    "impressora": [
        ("local_printer", "Local"), ("ip", "IP"), ("modelo", "Modelo"),
        ("serie", "Nº Série"), ("toner", "Toner"), ("mac", "MAC"),
    ],
    "telefone": [("modelo", "Modelo"), ("ramal", "Ramal"), ("ip", "IP"), ("local", "Localização")],
    # Itens do módulo Recebimentos (pasta recebimentos/). "material" não pode ser ocultado.
    "recebimento": [
        ("material", "Material"), ("tipo", "Tipo / Marca"), ("modelo", "Modelo"), ("qtd", "Qtd"),
        ("serie", "Nº de série"), ("situacao", "Situação"), ("destino", "Destino"),
        ("observacao", "Observação"),
    ],
    # Máquina não usa esse mecanismo pra TODOS os campos: os 16 abaixo marcados em
    # MAQUINA_CAMPOS_VIA_CONFIGURACOES já têm nome editável em Configurações (RotuloCategoria
    # por tipo, ex: 'posto_graduacao') — aqui eles só ganham a opção de OCULTAR, pra não
    # existirem dois lugares diferentes pra renomear a mesma coisa. "nome_completo" entra na
    # lista (primeira posição por padrão) só pra poder ser MOVIDO — nunca pode ser ocultado
    # (ver MAQUINA_CAMPOS_OBRIGATORIOS).
    "maquina": [
        ("nome_completo", "Nome Completo"),
        ("nip", "NIP"), ("posto_graduacao", "Posto / Graduação"), ("corpo_quadro", "Corpo / Quadro"),
        ("especialidade", "Especialidade"), ("ip", "IP"), ("num_maquina", "Num da Máquina"),
        ("mac", "MAC"), ("disponivel", "Disponível"), ("lva", "LVA"), ("departamento_setor", "Departamento / Setor"),
        ("num_pat", "Num Patrimonial"), ("sistema_operacional", "Sistema Operacional"),
        ("memoria_tipo", "Memória Tipo"), ("memoria_qtd", "Memória Qtd"),
        ("armazenamento_tipo", "Armazenamento Tipo"), ("armazenamento_capacidade", "Armazenamento Capacidade"),
        ("armazenamento_interface", "Armazenamento Interface"), ("teclado", "Teclado"), ("mouse", "Mouse"),
        ("lacre", "Lacre"), ("processador_fabricante", "Processador (Fabricante)"),
        ("processador_modelo", "Processador (Modelo)"), ("data_compra", "Data Compra"),
        ("data_revitalizacao", "Data Revitalização"), ("nivel_rcc", "Nível RCC"),
        ("historico", "Histórico de Manutenção"),
        ("acoes", "Ações"),
    ],
}

# Campos que nunca podem ser ocultados (mesmo assim podem ser MOVIDOS de posição).
MAQUINA_CAMPOS_OBRIGATORIOS = {"nome_completo", "historico", "acoes"}

# Campos de Máquina cujo NOME é editado em Configurações (rotulos_categorias), não em Editar
# Colunas. Em Editar Colunas eles só aparecem com a opção de ocultar/mostrar.
MAQUINA_CAMPOS_VIA_CONFIGURACOES = {
    "posto_graduacao", "corpo_quadro", "especialidade", "disponivel", "departamento_setor",
    "sistema_operacional", "memoria_tipo", "memoria_qtd", "armazenamento_tipo",
    "armazenamento_capacidade", "armazenamento_interface", "lacre",
    "processador_fabricante", "processador_modelo",
}


class ColunaOculta(db.Model):
    """Marca um campo 'de fábrica' (chave) de um tipo (switch/impressora/telefone) como oculto."""
    __tablename__ = "colunas_ocultas"
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20), nullable=False)
    chave = db.Column(db.String(50), nullable=False)
    __table_args__ = (db.UniqueConstraint("tipo", "chave", name="uq_tipo_chave_oculta"),)


class OrdemColuna(db.Model):
    """Posição customizada (definida pelo admin) de uma coluna 'de fábrica' na tela de
    listagem. Se não houver registro para uma (tipo, chave), usa a ordem padrão declarada
    em CAMPOS_FIXOS_POR_TIPO."""
    __tablename__ = "ordem_colunas"
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20), nullable=False)
    chave = db.Column(db.String(50), nullable=False)
    ordem = db.Column(db.Integer, default=0)
    __table_args__ = (db.UniqueConstraint("tipo", "chave", name="uq_tipo_chave_ordem"),)


class CampoExtra(db.Model):
    """Uma coluna nova, criada pelo usuário, para Switch/Impressora/Telefonia."""
    __tablename__ = "campos_extra"
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20), nullable=False)
    nome = db.Column(db.String(80), nullable=False)
    chave = db.Column(db.String(80), nullable=False)  # slug interno, gerado a partir do nome
    ordem = db.Column(db.Integer, default=0)
    __table_args__ = (db.UniqueConstraint("tipo", "chave", name="uq_tipo_chave_extra"),)


# ------------------------------------------------------------- SWITCH -----

class Switch(db.Model):
    __tablename__ = "switches"
    id = db.Column(db.Integer, primary_key=True)
    chave = db.Column(db.String(50))
    rack_departamento = db.Column(db.String(100))
    lacres = db.Column(db.String(150))
    # Sem valor padrão de propósito — fica em branco até você escolher manualmente.
    nivel_rcc = db.Column(db.String(10))
    extras = db.Column(db.Text)  # JSON com valores dos campos criados pelo usuário
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)


# ---------------------------------------------------------- IMPRESSORAS ---

class Impressora(db.Model):
    __tablename__ = "impressoras"
    id = db.Column(db.Integer, primary_key=True)
    local_printer = db.Column(db.String(100))
    ip = db.Column(db.String(100))
    modelo = db.Column(db.String(100))
    serie = db.Column(db.String(100))
    toner = db.Column(db.String(100))
    mac = db.Column(db.String(100))
    extras = db.Column(db.Text)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)


class ContatoTI(db.Model):
    """Contatos de assistência técnica ligados às impressoras."""
    __tablename__ = "contatos_ti"
    id = db.Column(db.Integer, primary_key=True)
    empresa = db.Column(db.String(100))
    telefone = db.Column(db.String(50))
    email = db.Column(db.String(100))
    obs = db.Column(db.String(255))


class ContatoSwitch(db.Model):
    """Contatos de assistência técnica / fornecedores ligados aos switches."""
    __tablename__ = "contatos_switch"
    id = db.Column(db.Integer, primary_key=True)
    empresa = db.Column(db.String(100))
    telefone = db.Column(db.String(50))
    email = db.Column(db.String(100))
    obs = db.Column(db.String(255))


MODELOS_IMPRESSORA_PADRAO = ["M3040idn", "M3550idn"]
TONERS_PADRAO = ["3102", "3122"]


# ------------------------------------------------------------ TELEFONIA ---

class Telefone(db.Model):
    __tablename__ = "telefones"
    id = db.Column(db.Integer, primary_key=True)
    modelo = db.Column(db.String(200))
    ramal = db.Column(db.String(200))
    ip = db.Column(db.String(200))
    local = db.Column(db.String(150))
    extras = db.Column(db.Text)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)


class ContatoTelefonia(db.Model):
    """Contatos de assistência técnica ligados à telefonia."""
    __tablename__ = "contatos_telefonia"
    id = db.Column(db.Integer, primary_key=True)
    servico_empresa = db.Column(db.String(100))
    numero = db.Column(db.String(50))
    contato_tecnico = db.Column(db.String(100))
    email_suporte = db.Column(db.String(100))
    observacoes = db.Column(db.Text)


# ------------------------------------------------------------- SOBRE ------

class ModuloPersonalizado(db.Model):
    """Um item de menu criado pelo admin (ex: 'Contatos') — vira uma tela completa
    de cadastro/listagem/filtro/PDF, igual Switch/Impressora/Telefonia, mas 100%
    orientada por colunas personalizadas (sem nenhum campo fixo pré-definido)."""
    __tablename__ = "modulos_personalizados"
    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    nome = db.Column(db.String(80), nullable=False)
    icone = db.Column(db.String(30), default="lista")
    ordem = db.Column(db.Integer, default=0)


class RegistroModulo(db.Model):
    """Uma linha de dados de um ModuloPersonalizado — mesmo padrão de 'extras' em
    JSON já usado por Switch/Impressora/Telefonia."""
    __tablename__ = "registros_modulo"
    id = db.Column(db.Integer, primary_key=True)
    modulo_id = db.Column(db.Integer, db.ForeignKey("modulos_personalizados.id"), nullable=False)
    extras = db.Column(db.Text)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)


class ItemMenuConfig(db.Model):
    """Config de visibilidade/nome/ordem dos itens FIXOS do menu (Switch, Impressoras,
    Telefonia) — não apaga o módulo nem os dados, só controla como aparece na sidebar."""
    __tablename__ = "itens_menu_config"
    id = db.Column(db.Integer, primary_key=True)
    chave = db.Column(db.String(50), unique=True, nullable=False)
    nome = db.Column(db.String(80))
    visivel = db.Column(db.Boolean, default=True)
    ordem = db.Column(db.Integer, default=0)
    # Posição no menu (↑/↓ em Gerenciar Menu). Vale para itens fixos e personalizados
    # (estes guardados com chave "mod:<slug>"). Vazio = posição padrão de fábrica.
    posicao = db.Column(db.Integer)
    # Ícone escolhido pelo admin em Gerenciar Menu (vazio = ícone padrão do item)
    icone = db.Column(db.String(40))


class ConfiguracaoSistema(db.Model):
    """Textos exibidos no popup 'Sobre o Sistema' (rodapé), editáveis pelo admin."""
    __tablename__ = "configuracao_sistema"
    id = db.Column(db.Integer, primary_key=True)
    nome_sistema = db.Column(db.String(50), default="SISPARQUE")
    versao = db.Column(db.String(20), default="1.0")
    desenvolvedor = db.Column(db.String(100), default="1°SG-FN-CN L.Ribeiro")
    ano = db.Column(db.String(10), default="2026")
    mensagem_rodape = db.Column(
        db.Text,
        default="Sistema desenvolvido pela Assessoria de TI, tem como objetivo gerenciar o inventário desta OM.",
    )
    finalidade = db.Column(
        db.Text,
        default="Tem por finalidade controlar o Inventário e os Serviços prestados pela Assessoria de TI.",
    )
    # Imagens da tela de login — cada slot guarda a extensão do arquivo salvo em
    # static/login_custom/<slot>.<ext> e se está ativo (visível) ou não. Admin controla
    # tudo isso pela tela (upload/remover), sem precisar mexer em arquivo nenhum.
    # Segurança: minutos sem mexer no sistema até voltar pra tela de login (0 = desligado)
    tempo_inatividade_min = db.Column(db.Integer, default=15)
    # Bloqueio por senha errada (só o Administrador geral altera): tentativas e minutos bloqueado
    bloqueio_tentativas = db.Column(db.Integer, default=5)
    bloqueio_minutos = db.Column(db.Integer, default=1)
    # Rede da OM pra tela Faixa de IP (ex: 10.210.64.0/20) e o gateway (ex: 10.210.64.1)
    rede_cidr = db.Column(db.String(50))
    rede_gateway = db.Column(db.String(50))
    # Abas das telas (ex.: Rede): por padrão só o Administrador geral cria/renomeia/exclui;
    # ele pode liberar para os outros administradores.
    abas_admins_podem = db.Column(db.Boolean, default=False)
    login_fundo_ext = db.Column(db.String(10))
    login_fundo_ativo = db.Column(db.Boolean, default=True)
    login_fundo_opacidade = db.Column(db.Integer, default=20)
    # 'cover' (preencher), 'contain' (ajustar), 'stretch' (esticar/ampliar),
    # 'tile' (lado a lado), 'center' (centralizar) ou 'span' (estender) —
    # igual as opções de plano de fundo do Windows.
    login_fundo_modo = db.Column(db.String(20), default="cover")
    login_fundo_pb = db.Column(db.Boolean, default=False)  # preto e branco (marca d'água)
    # Repete o fundo, bem clarinho, também dentro do painel colorido do login
    login_fundo_painel = db.Column(db.Boolean, default=False)
    login_esquerda_ext = db.Column(db.String(10))
    login_esquerda_ativo = db.Column(db.Boolean, default=True)
    login_esquerda_opacidade = db.Column(db.Integer, default=30)
    login_direita_ext = db.Column(db.String(10))
    login_direita_ativo = db.Column(db.Boolean, default=True)
    login_direita_opacidade = db.Column(db.Integer, default=30)
    login_imagens_inicializadas = db.Column(db.Boolean, default=False)
    # 'padrao' (verde institucional), 'escuro' ou 'claro' — só o admin controla,
    # afeta o sistema inteiro pra todo mundo.
    modo_visual = db.Column(db.String(10), default="padrao")
    # Brasão/escudo central da tela de login — se vazio, usa static/heraldica.png
    # (o padrão de fábrica). Opacidade não se aplica aqui (fica sempre sólido).
    login_brasao_ext = db.Column(db.String(10))
    login_brasao_ativo = db.Column(db.Boolean, default=True)
    # Cor da tela de login: 'verde_musgo' (padrão) ou 'marinho' (azul marinho com
    # detalhe dourado). Só o admin troca, em Aparência.
    login_cor = db.Column(db.String(20), default="verde_musgo")
    # Pop-up com as informações do sistema abrindo sozinho na tela de login
    popup_login_ativo = db.Column(db.Boolean, default=True)
    # Textos da tela de login editáveis pelo admin (JSON). Vazio = textos padrão.
    login_textos = db.Column(db.Text)


def _auto_migrar_colunas_faltantes(app):
    """Adiciona automaticamente, no arquivo de banco já em uso, qualquer coluna que o
    código já conhece (declarada nos modelos) mas que ainda não existe fisicamente no
    banco — isso acontece sempre que o sistema é atualizado por cima de um banco criado
    por uma versão anterior (ex: alguém baixou uma atualização com um campo novo, tipo
    'pode_editar_colunas', mas o sisparque.db em uso ainda não tem essa coluna).

    Sem isso, o sistema quebra logo na inicialização assim que qualquer tela tenta ler
    a coluna nova ("no such column" / conexão recusada). Tabelas inteiramente novas não
    precisam disso — o db.create_all(), chamado logo antes desta função, já cria elas
    sozinho, já com todas as colunas certas."""
    from sqlalchemy import inspect, text
    with app.app_context():
        insp = inspect(db.engine)
        tabelas_existentes = set(insp.get_table_names())
        with db.engine.connect() as conn:
            for tabela in db.metadata.sorted_tables:
                if tabela.name not in tabelas_existentes:
                    continue  # tabela nova: db.create_all() já resolveu isso
                colunas_existentes = {c["name"] for c in insp.get_columns(tabela.name)}
                for coluna in tabela.columns:
                    if coluna.name in colunas_existentes:
                        continue
                    try:
                        tipo_sql = coluna.type.compile(dialect=db.engine.dialect)
                        conn.execute(text(f'ALTER TABLE "{tabela.name}" ADD COLUMN "{coluna.name}" {tipo_sql}'))
                        conn.commit()
                        print(f">> Banco atualizado automaticamente: coluna '{coluna.name}' adicionada em '{tabela.name}'.")
                    except Exception as e:
                        print(f">> AVISO: não consegui adicionar a coluna '{coluna.name}' em '{tabela.name}' automaticamente: {e}")


def seed_admin(app):
    """Cria o usuário admin padrão e popula as listas de configuração na primeira execução."""
    with app.app_context():
        db.create_all()
        _auto_migrar_colunas_faltantes(app)
        if not Usuario.query.first():
            admin = Usuario(
                nip="00.0000.00",
                nome_completo="ADMINISTRADOR",
                posto_graduacao="SO",
                is_admin=True,
                is_geral=True,
            )
            admin.set_senha("admin123")
            db.session.add(admin)
            db.session.commit()
            print(">> Usuário admin criado: NIP 00.0000.00 / senha admin123 (ALTERE DEPOIS DO PRIMEIRO LOGIN)")

        padroes = {
            "posto_graduacao": POSTOS_GRADUACOES_PADRAO,
            "corpo_quadro": CORPOS_QUADROS_PADRAO,
            "processador_fabricante": FABRICANTES_PROCESSADOR_PADRAO,
            "setor": SETORES_PADRAO,
            "sistema_operacional": SISTEMAS_OPERACIONAIS_PADRAO,
        }
        padroes.update(VALORES_PADRAO_POR_TIPO)
        paleta_setor = [
            "#004080", "#c2185b", "#7b1fa2", "#0288d1", "#00796b",
            "#f57c00", "#5d4037", "#455a64", "#c62828", "#2e7d32",
            "#6a1b9a", "#0097a7", "#ef6c00", "#4527a0", "#00695c",
        ]
        for tipo, valores in padroes.items():
            # Só semeia os valores padrão se essa categoria específica ainda
            # não tem NENHUM item — assim, atualizar o sistema não sobrescreve
            # o que você já editou, mas categorias novas (Memória, Armazenamento,
            # Especialidade, etc.) aparecem populadas mesmo em um banco já usado.
            if OpcaoConfig.query.filter_by(tipo=tipo).first():
                continue
            for i, v in enumerate(valores):
                cor = paleta_setor[i % len(paleta_setor)] if tipo == "setor" else "#004080"
                db.session.add(OpcaoConfig(tipo=tipo, valor=v, cor=cor))
        db.session.commit()

        for tipo, rotulo_padrao in TIPOS_OPCAO.items():
            if not RotuloCategoria.query.filter_by(tipo=tipo).first():
                db.session.add(RotuloCategoria(tipo=tipo, rotulo=rotulo_padrao))
        db.session.commit()

        config = ConfiguracaoSistema.query.first()
        if not config:
            config = ConfiguracaoSistema()
            db.session.add(config)
            db.session.commit()
            print(">> Listas de configuração padrão criadas (editáveis em Configurações).")

        # Preenche as 3 imagens padrão da tela de login (já vêm no pacote) só na
        # primeira vez — se o admin depois remover alguma pela tela, não volta sozinha.
        if not config.login_imagens_inicializadas:
            pasta_login = os.path.join(os.path.dirname(__file__), "static", "login_custom")
            padroes = [("login_fundo_ext", "fundo.jpg", "jpg"),
                       ("login_esquerda_ext", "esquerda.png", "png"),
                       ("login_direita_ext", "direita.png", "png")]
            for campo, arquivo, ext in padroes:
                if os.path.exists(os.path.join(pasta_login, arquivo)):
                    setattr(config, campo, ext)
            config.login_imagens_inicializadas = True
            db.session.commit()

        # 'modelo_telefone' virou lista editável — aproveita os modelos que já
        # existem nos aparelhos cadastrados, pra ninguém perder o valor que já
        # tinha ao editar um registro antigo (só roda se a lista ainda tá vazia).
        if not OpcaoConfig.query.filter_by(tipo="modelo_telefone").first():
            modelos_existentes = {t.modelo.strip() for t in Telefone.query.all() if t.modelo and t.modelo.strip()}
            for m in sorted(modelos_existentes):
                db.session.add(OpcaoConfig(tipo="modelo_telefone", valor=m))
            if modelos_existentes:
                db.session.commit()


# ------------------------------------------------------------ AUDITORIA ---

class LogAuditoria(db.Model):
    """Trilha de auditoria: quem fez o quê, quando e de onde. Fica num arquivo
    SEPARADO (auditoria.db): importar ou restaurar o banco principal não apaga a
    trilha. Só o Administrador geral vê e só ele pode excluir registros — e a
    própria exclusão fica registrada."""
    __bind_key__ = "auditoria"
    __tablename__ = "auditoria"
    id = db.Column(db.Integer, primary_key=True)
    quando = db.Column(db.DateTime, nullable=False, index=True)
    usuario_id = db.Column(db.Integer, index=True)
    usuario_nome = db.Column(db.String(150))
    acao = db.Column(db.String(30), nullable=False, index=True)    # Criou, Alterou, Excluiu, Entrou, Saiu, Senha errada...
    tipo = db.Column(db.String(40), index=True)                    # Máquina, Impressora, Telefone, Usuário...
    objeto_id = db.Column(db.Integer)
    descricao = db.Column(db.String(300))
    detalhes = db.Column(db.Text)                                  # JSON: [{"campo","antes","depois"}] ou texto
    ip_origem = db.Column(db.String(45))


class AbaPagina(db.Model):
    """Abas no topo de uma tela (hoje: Rede). As do sistema (Status, Faixa de IP) podem
    ser renomeadas mas nunca excluídas. As criadas pelo admin são 'link' (abre um
    endereço) ou 'nota' (página de anotações). Excluir manda pra lixeira (excluida=True);
    só o Administrador geral restaura."""
    __tablename__ = "aba_pagina"
    id = db.Column(db.Integer, primary_key=True)
    pagina = db.Column(db.String(30), nullable=False, default="rede", index=True)
    chave_sistema = db.Column(db.String(30))          # 'status', 'faixa' ou None (aba criada)
    rotulo = db.Column(db.String(60), nullable=False)
    tipo = db.Column(db.String(10), nullable=False, default="sistema")   # sistema | link | nota
    url = db.Column(db.String(500))
    conteudo = db.Column(db.Text)
    ordem = db.Column(db.Integer, default=0)
    excluida = db.Column(db.Boolean, default=False)
    excluida_em = db.Column(db.DateTime)
    excluida_por = db.Column(db.String(120))
    criado_por = db.Column(db.String(120))
    criado_em = db.Column(db.DateTime, default=datetime.now)

