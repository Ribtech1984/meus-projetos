# SISPARQUE (versão Python) — Guia de Instalação no Oracle Linux 9.5

Esta versão roda com **Python + Flask + SQLite**, sem depender de XAMPP,
Apache do XAMPP, PHP ou MySQL/MariaDB. Isso já elimina a maior parte dos
conflitos comuns com antivírus de endpoint (como o Kaspersky), que costumam
implicar com o stack do XAMPP (httpd.exe do pacote, portas 80/3306,
processos não assinados, etc). Ainda assim, veja a seção **Kaspersky** no
final — nenhum fornecedor de AV garante 100% de "não vou interferir", então
o procedimento certo é whitelistar o processo/pasta, não torcer para não dar problema.

## 1. Pré-requisitos no servidor (Oracle Linux 9.5)

```bash
sudo dnf install -y python3.11 python3.11-pip git
python3.11 -m venv /opt/sisparque/venv
```

## 2. Copiar o projeto

Envie a pasta `sisparque_py/` inteira para `/opt/sisparque/app` no servidor
(via `scp`, `rsync` ou pen drive, como preferir).

```bash
sudo mkdir -p /opt/sisparque/app
sudo cp -r sisparque_py/* /opt/sisparque/app/
sudo chown -R sisparque:sisparque /opt/sisparque
```

## 3. Criar usuário de serviço e instalar dependências

```bash
sudo useradd -r -s /sbin/nologin sisparque
cd /opt/sisparque/app
sudo -u sisparque /opt/sisparque/venv/bin/pip install -r requirements.txt
```

## 4. Definir a chave secreta (produção)

```bash
export SISPARQUE_SECRET_KEY="gere-uma-string-aleatoria-longa-aqui"
```
Coloque essa variável no arquivo de serviço systemd (passo 5), não deixe o
valor padrão do `app.py` em produção.

## 5. Serviço systemd (roda com Gunicorn, sem Apache)

Crie `/etc/systemd/system/sisparque.service`:

```ini
[Unit]
Description=SISPARQUE - Sistema de Inventario (Python/Flask)
After=network.target

[Service]
User=sisparque
Group=sisparque
WorkingDirectory=/opt/sisparque/app
Environment="SISPARQUE_SECRET_KEY=gere-uma-string-aleatoria-longa-aqui"
ExecStart=/opt/sisparque/venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 app:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 5.1 Banco de dados e importação automática

Você **não precisa rodar nenhum comando manual** para criar o banco ou
importar os dados. Assim que o serviço subir pela primeira vez (seja via
`gunicorn`, `serve_waitress.py` ou até `python app.py`), o sistema detecta
sozinho que o banco está vazio e importa automaticamente tudo que está em
`dados_originais/sisparque_backup.sql` — máquinas, switches, impressoras,
telefonia e **usuários já cadastrados** (com senha convertida para hash
seguro, mesma senha de antes). O usuário admin padrão também é criado
automaticamente: **NIP 00.0000.00 / senha admin123** — troque assim que
entrar.

Isso só acontece **uma vez** (na primeira execução com banco vazio); nas
próximas vezes que o serviço reiniciar, ele detecta que já tem dados e não
duplica nada.

Se um dia você quiser reimportar manualmente com um `.sql` mais novo (por
exemplo, atualizando os dados), ainda pode rodar:
```bash
cd /opt/sisparque/app
sudo -u sisparque /opt/sisparque/venv/bin/python3 migrar_dados.py dados_originais/sisparque_backup.sql
```
O script é seguro para rodar mais de uma vez — ele pula máquinas cujo IP já
existe no banco novo e usuários cujo NIP já foi importado, então não duplica
nada se você rodar de novo por engano. As senhas dos usuários antigos (que
estavam em texto puro no MySQL) são convertidas para hash seguro nesse
processo — os usuários continuam entrando com a mesma senha de sempre.

Depois:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now sisparque
sudo systemctl status sisparque
```

## 6. Nginx como proxy reverso (recomendado, porta 80/443)

```bash
sudo dnf install -y nginx
```

`/etc/nginx/conf.d/sisparque.conf`:
```nginx
server {
    listen 80;
    server_name 10.210.64.33;  # ou o hostname interno

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```
```bash
sudo systemctl enable --now nginx
```

## 7. Firewall interno (firewalld)

```bash
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --reload
```

## 8. Backup do banco (automático)

Se você usou o `scripts/instalar_servico_linux.sh`, o backup automático **já
está configurado sozinho** — roda todo dia às 3h da manhã via `cron`, salva
em `/opt/sisparque/backups/`, e apaga sozinho backups com mais de 30 dias.

Pra rodar um backup manual a qualquer momento:
```bash
sudo bash /opt/sisparque/scripts/backup_sisparque.sh
```

Pra restaurar um backup (substitui o banco atual pelo escolhido):
```bash
sudo systemctl stop sisparque
sudo cp /opt/sisparque/backups/sisparque_AAAA-MM-DD_HH-MM-SS.db /opt/sisparque/sisparque.db
sudo systemctl start sisparque
```

Se preferir mandar os backups pra outro servidor (recomendado, pra não
depender só do disco da própria máquina), configure `rsync` apontando pra
`/opt/sisparque/backups/` num cron adicional.

---

## Sobre o Kaspersky

O problema que você tinha com o XAMPP normalmente vem de um destes pontos:
- o antivírus de endpoint monitorando/bloqueando `httpd.exe` e `mysqld.exe`
  do pacote XAMPP (executáveis não assinados / rodando de pasta "suspeita"
  tipo `C:\xampp`);
- verificação em tempo real reescrevendo/bloqueando arquivos de configuração
  do Apache/PHP a cada alteração;
- porta 80/3306 sendo tratada como suspeita por regras de rede do endpoint.

Como aqui não existe XAMPP, Apache do XAMPP nem MySQL — só o processo
`gunicorn` (Python) rodando como serviço systemd nativo do Linux — o Kaspersky
Endpoint Security for Linux tende a não implicar da mesma forma. Mesmo assim,
se sua organização usa KESL nesse servidor, o caminho correto é:

1. Whitelistar (exclusão de verificação) a pasta `/opt/sisparque/` no
   console de administração do Kaspersky (KSC), tanto para verificação
   em tempo real quanto para a verificação sob demanda.
2. Se o KESL tiver módulo de proteção de rede/firewall próprio no Linux,
   liberar a porta 8000 (Gunicorn) e 80/443 (Nginx) nas regras dele.
3. Evitar rodar a aplicação como root — o serviço já sobe como usuário
   `sisparque` sem privilégios, o que também reduz o motivo de qualquer
   módulo de proteção de privilégio bloquear o processo.

Isso é orientação geral de administração — a política específica de
exclusões do Kaspersky na rede da Marinha deve ser autorizada e aplicada
por quem administra o console KSC.
