"""
Servidor de PRODUÇÃO do SISPARQUE — usa Waitress em vez do servidor de
desenvolvimento do Flask.

Por que isso importa: quando você roda "python app.py", o Flask avisa
"This is a development server..." — aquilo não foi feito pra ficar rodando
o tempo todo, é só pra você testar enquanto programa. O Waitress é um
servidor de verdade, escrito 100% em Python puro (sem compilar nada, sem
C++), e funciona igual tanto no Windows quanto no Linux. Ele é o que vai
ficar de pé 24/7 por trás do SISPARQUE.

Uso local (teste):
    python serve_waitress.py

Em produção, este script roda por dentro de um Serviço do Windows (NSSM)
ou de um serviço systemd (Linux) — ver os arquivos:
    scripts/instalar_servico_windows.bat
    README_DEPLOY.md (seção systemd, para Oracle Linux/Ubuntu/Debian)
"""
import os
from waitress import serve
from app import app  # a importação já dispara seed_admin() e a auto-importação dos dados

if __name__ == "__main__":
    porta = int(os.environ.get("SISPARQUE_PORT", "5000"))

    # Grava o PID do processo num arquivo, pra dar pra "parar_sisparque" saber
    # qual processo derrubar depois (já que roda sem janela nenhuma). Isso é
    # só um acessório — se por qualquer motivo (arquivo preso com dono errado
    # de uma execução manual anterior, por exemplo) não der pra escrever, o
    # servidor sobe mesmo assim, só sem esse arquivo.
    caminho_pid = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sisparque.pid")
    try:
        with open(caminho_pid, "w") as f:
            f.write(str(os.getpid()))
    except OSError as e:
        print(f">> AVISO: não consegui criar {caminho_pid} ({e}) — seguindo sem ele "
              f"(isso só afeta o script 'parar_sisparque', não o funcionamento do sistema).")

    print(f">> SISPARQUE em modo produção (Waitress) — ouvindo em 0.0.0.0:{porta}")
    print(">> Este processo deve ficar rodando como serviço (veja README_SERVICO_PERMANENTE.md)")
    try:
        serve(app, host="0.0.0.0", port=porta, threads=16, connection_limit=200, channel_timeout=120)
    finally:
        try:
            if os.path.exists(caminho_pid):
                os.remove(caminho_pid)
        except OSError:
            pass
