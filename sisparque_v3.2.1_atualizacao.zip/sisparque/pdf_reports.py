from io import BytesIO
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas as _canvas
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics import renderPDF

AZUL_MARINHA = colors.HexColor("#3E4B2C")  # verde institucional (mesma cor do cabeçalho da tela)
AZUL_CLARO = colors.HexColor("#F1ECDA")    # bege claro (mesmo fundo das linhas pares da tela)

# Cores por Nível RCC — semáforo (vermelho/amarelo/verde), como pedido — usadas na
# etiqueta em PDF e espelhadas no CSS das telas (ver .badge-rcc-1/2/3 em style.css).
CORES_RCC = {
    "RCC-1": colors.HexColor("#C0392B"),  # vermelho
    "RCC-2": colors.HexColor("#F1C40F"),  # amarelo
    "RCC-3": colors.HexColor("#27AE60"),  # verde
}
# Cor do texto de cada badge quando PREENCHIDO (amarelo precisa de texto escuro pra contraste)
TEXTO_RCC = {
    "RCC-1": colors.white,
    "RCC-2": colors.HexColor("#3A2E00"),
    "RCC-3": colors.white,
}
COR_RCC_PADRAO = colors.HexColor("#555555")


def definir_tema_pdf(modo_visual):
    """Cabeçalho das tabelas na mesma cor do sistema: verde musgo (padrão) ou azul marinho."""
    global AZUL_MARINHA, AZUL_CLARO
    if modo_visual == "marinho":
        AZUL_MARINHA = colors.HexColor("#0f1f45")
        AZUL_CLARO = colors.HexColor("#ECEFF5")
    else:
        AZUL_MARINHA = colors.HexColor("#3E4B2C")
        AZUL_CLARO = colors.HexColor("#F1ECDA")

# Tamanho físico da etiqueta impressa — 8cm x 5cm (padrão comum de etiqueta de
# patrimônio/ativo). Ajuste aqui se a impressora de etiquetas usar outro tamanho.
LARGURA_ETIQUETA = 8 * cm
ALTURA_ETIQUETA = 5 * cm


def _desenho_qrcode(dado_texto, tamanho_pts):
    """Monta um Drawing do QR Code (gerado nativamente pelo reportlab, sem depender
    de nenhuma biblioteca externa) já escalado para tamanho_pts x tamanho_pts."""
    widget = QrCodeWidget(dado_texto)
    x0, y0, x1, y1 = widget.getBounds()
    largura_nativa = x1 - x0
    altura_nativa = y1 - y0
    escala = tamanho_pts / largura_nativa if largura_nativa else 1
    desenho = Drawing(
        tamanho_pts, tamanho_pts,
        transform=[escala, 0, 0, tamanho_pts / altura_nativa if altura_nativa else 1, 0, 0],
    )
    desenho.add(widget)
    return desenho


def _cabecalho(titulo):
    styles = getSampleStyleSheet()
    style_titulo = styles["Heading1"]
    style_titulo.textColor = AZUL_MARINHA
    elementos = [
        Paragraph("SISPARQUE - Sistema de Inventário", style_titulo),
        Paragraph(titulo, styles["Heading2"]),
        Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}", styles["Normal"]),
        Spacer(1, 0.5 * cm),
    ]
    return elementos


# ---------------------------------------------------------------------------
# Tabelas de listagem com boa leitura na impressão:
#  - escolhe o papel pelo nº de colunas (A4 em pé, A4 deitado ou A3 deitado);
#  - a tabela ocupa a largura toda da folha;
#  - a letra é a MAIOR que couber (até 10pt), nunca menor que 6,5pt;
#  - texto comprido quebra linha dentro da célula em vez de esticar a coluna.
# ---------------------------------------------------------------------------
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.lib.styles import ParagraphStyle

FONTE_MAX, FONTE_MIN = 10.0, 6.5


def _papel_para(qtd_colunas):
    if qtd_colunas <= 5:
        return A4
    if qtd_colunas <= 10:
        return landscape(A4)
    return landscape(A3)


def _tabela_legivel(dados, largura_util):
    """Monta a Table já dimensionada para a largura útil da folha."""
    texto = [["" if v is None else str(v) for v in linha] for linha in dados]
    ncol = len(texto[0])
    pad = 8  # padding esquerdo+direito de cada célula, em pontos

    def larguras_naturais(fonte):
        larg = []
        for c in range(ncol):
            maior = 0
            for li, linha in enumerate(texto):
                nome_fonte = "Helvetica-Bold" if li == 0 else "Helvetica"
                # coluna de texto longo conta no máx. ~38 caracteres (o resto quebra linha)
                valor = linha[c] if len(linha[c]) <= 38 else linha[c][:38]
                maior = max(maior, stringWidth(valor, nome_fonte, fonte))
            larg.append(maior + pad)
        return larg

    fonte = FONTE_MAX
    while fonte > FONTE_MIN and sum(larguras_naturais(fonte)) > largura_util:
        fonte -= 0.25
    larg = larguras_naturais(fonte)
    total = sum(larg)
    # estica (ou encolhe) proporcionalmente para ocupar exatamente a largura da folha
    larg = [w * largura_util / total for w in larg]

    est_cab = ParagraphStyle("cab", fontName="Helvetica-Bold", fontSize=fonte,
                             leading=fonte * 1.2, textColor=colors.white)
    est_cel = ParagraphStyle("cel", fontName="Helvetica", fontSize=fonte, leading=fonte * 1.25)
    from xml.sax.saxutils import escape
    linhas = [[Paragraph(escape(v), est_cab) for v in texto[0]]]
    for linha in texto[1:]:
        linhas.append([Paragraph(escape(v), est_cel) for v in linha])

    respiro = max(3, fonte * 0.45)
    tabela = Table(linhas, colWidths=larg, repeatRows=1)
    tabela.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), AZUL_MARINHA),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), respiro),
        ("BOTTOMPADDING", (0, 0), (-1, -1), respiro),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#9AA0A6")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, AZUL_CLARO]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return tabela


def _rodape(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawString(doc.leftMargin, 0.6 * cm, "SISPARQUE — Sistema de Inventário Patrimonial")
    canvas.drawRightString(doc.pagesize[0] - doc.rightMargin, 0.6 * cm, f"Página {doc.page}")
    canvas.restoreState()


def _gerar_pdf_tabela(titulo, dados, extras_elementos=None):
    buffer = BytesIO()
    papel = _papel_para(len(dados[0]))
    margem = 1.2 * cm
    doc = SimpleDocTemplate(
        buffer, pagesize=papel, topMargin=1.2 * cm, bottomMargin=1.4 * cm,
        leftMargin=margem, rightMargin=margem, title=titulo,
    )
    elementos = _cabecalho(titulo)
    elementos.append(_tabela_legivel(dados, papel[0] - 2 * margem))
    for el in (extras_elementos or []):
        elementos.append(el)
    doc.build(elementos, onFirstPage=_rodape, onLaterPages=_rodape)
    buffer.seek(0)
    return buffer


ORDEM_CAMPOS_PDF_MAQUINA = [
    "id", "nome_completo", "nip", "posto_graduacao", "corpo_quadro", "especialidade",
    "ip", "num_maquina", "mac", "disponivel", "departamento_setor", "num_pat", "sistema_operacional",
    "memoria_tipo", "memoria_qtd", "armazenamento_tipo", "armazenamento_capacidade", "armazenamento_interface",
    "teclado", "mouse", "lacre", "processador_fabricante", "processador_modelo",
    "data_compra", "historico", "data_revitalizacao",
]


def dados_maquinas(maquinas, rotulos=None, colunas=None):
    """Tabela (cabeçalho + linhas) do inventário de máquinas — usada no PDF e nas planilhas.
    rotulos = {campo: nome} dos campos renomeados (ex.: nome_completo → Responsável).
    colunas = lista de campos escolhidos na tela, na ordem da tela (None = todas)."""
    curtos = [
        "ID", "Nome Completo", "NIP", "Posto/Grad", "Corpo/Qd", "Especial.",
        "IP", "Num Máquina", "MAC", "Disponível", "Setor", "Num Pat", "SO",
        "Mem. Tipo", "Mem. Qtd", "Arm. Tipo", "Arm. Cap.", "Arm. Interf.",
        "Teclado", "Mouse", "Lacre", "Proc. Fab.", "Proc. Modelo",
        "Data Compra", "Histórico", "Data Revital.",
    ]
    nome = dict(zip(ORDEM_CAMPOS_PDF_MAQUINA, curtos))
    nome.update(rotulos or {})
    chaves = [c for c in (colunas or ORDEM_CAMPOS_PDF_MAQUINA) if c in nome] or ORDEM_CAMPOS_PDF_MAQUINA
    dados = [[nome[c] for c in chaves]]
    for m in maquinas:
        qtd = len(m.historicos) if m.historicos else 0
        linha = []
        for c in chaves:
            if c == "id":
                linha.append(m.id)
            elif c == "historico":
                linha.append(f"{qtd} reg." if qtd else "-")
            elif c == "nome_completo":
                linha.append(m.nome_completo)
            else:
                linha.append(getattr(m, c, None) or "-")
        dados.append(linha)
    return dados


def gerar_pdf_maquinas(maquinas):
    """Inventário completo de máquinas (todas as colunas) — A3 deitado, letra
    ajustada para o maior tamanho que couber."""
    return _gerar_pdf_tabela("Inventário Completo de Máquinas", dados_maquinas(maquinas))


def dados_modulo(campos, extras, itens, carregar_extras):
    cabecalho = ["ID"] + [rotulo for _, rotulo in campos] + [e.nome for e in extras]
    dados = [cabecalho]
    for item in itens:
        linha = [item.id] + [getattr(item, chave, None) or "-" for chave, _ in campos]
        valores_extra = carregar_extras(item)
        linha += [valores_extra.get(e.chave, "-") or "-" for e in extras]
        dados.append(linha)
    return dados


def dados_contatos(contatos):
    return [["Empresa", "Telefone", "E-mail", "Observações"]] + [
        [c["nome"] or "-", c["telefone"] or "-", c["email"] or "-", c["obs"] or "-"]
        for c in (contatos or [])
    ]


def gerar_pdf_modulo(titulo, campos, extras, itens, carregar_extras, contatos=None):
    """
    PDF genérico para módulos com campos dinâmicos (Switch, Impressora, Telefonia...).
    O papel e o tamanho da letra se ajustam ao nº de colunas (poucas colunas = A4
    em pé com letra grande, ocupando a folha toda).
    contatos: lista opcional de dicts {'nome','telefone','email','obs'} — entra numa
    segunda tabela ao final do PDF (fornecedores/assistência técnica).
    """
    dados = dados_modulo(campos, extras, itens, carregar_extras)
    cabecalho = dados[0]

    extras_el = []
    if contatos:
        styles = getSampleStyleSheet()
        largura = _papel_para(len(cabecalho))[0] - 2 * 1.2 * cm
        extras_el.append(Spacer(1, 0.7 * cm))
        extras_el.append(Paragraph("Contatos / Fornecedores", styles["Heading2"]))
        extras_el.append(Spacer(1, 0.2 * cm))
        extras_el.append(_tabela_legivel(dados_contatos(contatos), largura))
    return _gerar_pdf_tabela(titulo, dados, extras_el)


def gerar_pdf_relatorio_setor(linhas, totais_so, totais_setor=None):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    elementos = _cabecalho("Relatório por Setor / Sistema Operacional")

    styles = getSampleStyleSheet()

    if totais_setor:
        elementos.append(Paragraph("Total por Setor", styles["Heading3"]))
        dados0 = [["Setor", "Total"]] + [[s or "-", qtd] for s, qtd in totais_setor]
        t0 = Table(dados0, repeatRows=1, colWidths=[10 * cm, 4 * cm])
        t0.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), AZUL_MARINHA),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, AZUL_CLARO]),
        ]))
        elementos.append(t0)
        elementos.append(Spacer(1, 1 * cm))

    elementos.append(Paragraph("Por Setor e Sistema Operacional", styles["Heading3"]))
    dados1 = [["Setor", "Sistema Operacional", "Total"]] + [
        [s or "-", so or "-", qtd] for s, so, qtd in linhas
    ]
    t1 = Table(dados1, repeatRows=1, colWidths=[7 * cm, 6 * cm, 3 * cm])
    t1.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), AZUL_MARINHA),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, AZUL_CLARO]),
    ]))
    elementos.append(t1)
    elementos.append(Spacer(1, 1 * cm))

    elementos.append(Paragraph("Totais Gerais por Sistema Operacional", styles["Heading3"]))
    total_geral = sum(qtd for _, qtd in totais_so)
    dados2 = [["Sistema Operacional", "Qtd Total"]] + [[so or "-", qtd] for so, qtd in totais_so]
    dados2.append(["TOTAL GERAL", total_geral])
    t2 = Table(dados2, repeatRows=1, colWidths=[8 * cm, 4 * cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), AZUL_MARINHA),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, AZUL_CLARO]),
        ("BACKGROUND", (0, -1), (-1, -1), AZUL_MARINHA),
        ("TEXTCOLOR", (0, -1), (-1, -1), colors.white),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
    ]))
    elementos.append(t2)

    doc.build(elementos)
    buffer.seek(0)
    return buffer


def _desenhar_etiqueta(c, identificador, nivel_rcc, qr_dado, cabecalho_texto):
    """Desenha o conteúdo comum de uma etiqueta (usado por Máquina e Switch) na
    página atual do canvas — já posicionado dentro de LARGURA_ETIQUETA x ALTURA_ETIQUETA.
    Etiqueta INDIVIDUAL: um badge só, na cor do Nível RCC daquele equipamento
    específico (vermelho=RCC-1, amarelo=RCC-2, verde=RCC-3). Sem rodapé de texto —
    só identificação + RCC + QR Code."""
    margem = 0.3 * cm
    tamanho_qr = 2.65 * cm
    cor_rcc = CORES_RCC.get(nivel_rcc, COR_RCC_PADRAO)
    cor_texto_badge = TEXTO_RCC.get(nivel_rcc, colors.white)

    # Moldura leve
    c.setStrokeColor(colors.HexColor("#999999"))
    c.setLineWidth(0.6)
    c.rect(1, 1, LARGURA_ETIQUETA - 2, ALTURA_ETIQUETA - 2)

    # Cabeçalho institucional
    c.setFont("Helvetica-Bold", 7)
    c.setFillColor(AZUL_MARINHA)
    c.drawString(margem, ALTURA_ETIQUETA - margem - 6, cabecalho_texto)

    # Identificação principal
    tam_fonte_id = 17 if len(identificador) <= 13 else 13
    c.setFont("Helvetica-Bold", tam_fonte_id)
    c.setFillColor(colors.black)
    y_id = ALTURA_ETIQUETA - margem - 6 - 22
    c.drawString(margem, y_id, identificador[:20])

    # Badge único do Nível RCC daquele equipamento (etiqueta individual)
    largura_badge = 2.1 * cm
    altura_badge = 0.6 * cm
    y_badge = y_id - 14 - altura_badge
    c.setFillColor(cor_rcc)
    c.roundRect(margem, y_badge, largura_badge, altura_badge, 3, fill=1, stroke=0)
    c.setFillColor(cor_texto_badge)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(margem + largura_badge / 2, y_badge + altura_badge / 2 - 3.8, nivel_rcc)

    # QR Code
    qr = _desenho_qrcode(qr_dado, tamanho_qr)
    x_qr = LARGURA_ETIQUETA - margem - tamanho_qr
    y_qr = (ALTURA_ETIQUETA - tamanho_qr) / 2
    renderPDF.draw(qr, c, x_qr, y_qr)


def gerar_etiqueta_maquina(maquina):
    """Etiqueta física INDIVIDUAL (PDF) de uma Máquina — identificação CTECCFN-XXXX
    (gerada a partir do IP) + Nível RCC daquela máquina (1 cor só) + QR Code de
    conferência. Sem nome de usuário nem rodapé de texto, por privacidade e limpeza
    visual — quem precisar de setor/IP escaneia o QR Code. Tamanho: ver
    LARGURA/ALTURA_ETIQUETA."""
    buffer = BytesIO()
    c = _canvas.Canvas(buffer, pagesize=(LARGURA_ETIQUETA, ALTURA_ETIQUETA))
    identificador = maquina.num_maquina or f"MAQ-{maquina.id}"
    nivel = maquina.nivel_rcc or "?"
    # Conteúdo do QR focado em auditoria física: identificação + RCC + número do
    # lacre no momento da impressão — sem IP/setor (rede/localização não ajudam a
    # detectar rompimento/troca de lacre, e ficam expostos a qualquer um que
    # escaneie a etiqueta fisicamente, sem precisar de acesso ao sistema).
    qr_dado = f"SISPARQUE|MAQUINA|{identificador}|RCC:{nivel}|LACRE:{maquina.lacre or '-'}"
    _desenhar_etiqueta(
        c, identificador, nivel, qr_dado=qr_dado,
        cabecalho_texto="CTecCFN — Assessoria de TI",
    )
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def gerar_etiqueta_switch(switch):
    """Etiqueta física (PDF) de um Switch — nasce RCC-1 por padrão (material sensível).
    Sem IP cadastrado no módulo de Switch, a identificação usa a 'Chave' do registro."""
    buffer = BytesIO()
    c = _canvas.Canvas(buffer, pagesize=(LARGURA_ETIQUETA, ALTURA_ETIQUETA))
    identificador = switch.chave or f"SWITCH-{switch.id}"
    nivel = switch.nivel_rcc or "?"
    # Mesmo raciocínio da Máquina: QR focado em auditoria (identificação + RCC +
    # lacre), sem o rack/local — isso já fica no sistema, não precisa estar
    # exposto pra quem escanear a etiqueta fisicamente.
    qr_dado = f"SISPARQUE|SWITCH|{identificador}|RCC:{nivel}|LACRE:{switch.lacres or '-'}"
    _desenhar_etiqueta(
        c, identificador, nivel, qr_dado=qr_dado,
        cabecalho_texto="CTecCFN — Switch",
    )
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def _montar_grafico_pizza_reportlab(dados, titulo):
    """
    dados: lista de tuplas (rótulo, quantidade, '#hexcolor').
    Retorna um Drawing do reportlab com o gráfico de pizza + legenda, pronto pra
    colocar num PDF (diferente dos gráficos CSS usados na tela, aqui é desenho vetorial de verdade).
    """
    dados = [d for d in dados if d[1] > 0]
    largura, altura = 500, 260
    desenho = Drawing(largura, altura)
    desenho.add(String(largura / 2, altura - 15, titulo, textAnchor="middle", fontSize=12, fillColor=AZUL_MARINHA))

    pizza = Pie()
    pizza.x = 40
    pizza.y = 20
    pizza.width = 180
    pizza.height = 180
    pizza.data = [qtd for _, qtd, _ in dados]
    pizza.labels = [f"{qtd}" for _, qtd, _ in dados]
    pizza.simpleLabels = 1
    pizza.sideLabels = 0
    for i, (_, _, cor) in enumerate(dados):
        pizza.slices[i].fillColor = colors.HexColor(cor)
        pizza.slices[i].strokeColor = colors.white
        pizza.slices[i].strokeWidth = 1
    desenho.add(pizza)

    legenda = Legend()
    legenda.x = 260
    legenda.y = altura - 40
    legenda.dx = 8
    legenda.dy = 8
    legenda.fontSize = 8
    legenda.alignment = "left"
    legenda.columnMaximum = 12
    legenda.colorNamePairs = [
        (colors.HexColor(cor), f"{rotulo} ({qtd})") for rotulo, qtd, cor in dados
    ]
    desenho.add(legenda)

    return desenho


def gerar_pdf_grafico_setor(dados_setor, dados_so):
    """
    Gera um PDF com os dois gráficos de pizza (Setor e Sistema Operacional)
    desenhados de verdade (não é print de tela) — usado pelo botão "PDF do Gráfico"
    no Dashboard.
    dados_setor / dados_so: listas de (rótulo, quantidade, '#hexcolor').
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    elementos = _cabecalho("Dashboard - Gráficos")

    elementos.append(_montar_grafico_pizza_reportlab(dados_setor, "Máquinas por Setor"))
    elementos.append(Spacer(1, 0.8 * cm))
    elementos.append(_montar_grafico_pizza_reportlab(dados_so, "Máquinas por Sistema Operacional"))

    doc.build(elementos)
    buffer.seek(0)
    return buffer
