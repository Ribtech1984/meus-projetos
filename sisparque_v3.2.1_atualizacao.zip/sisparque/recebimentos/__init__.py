"""
SISPARQUE - Modulo RECEBIMENTOS
Anotacao de lotes de material que chegam (ex.: Material da Receita).

Ligado no app.py (logo abaixo do LoginManager):
    from recebimentos import recebimentos_bp
    app.register_blueprint(recebimentos_bp)
Item de menu: "recebimentos" em estrutura_menu() do app.py.
Tabelas rec_lote e rec_item no proprio sisparque.db (criadas sozinhas).
Colunas dos itens: tela Editar Colunas do sistema (tipo "recebimento");
colunas personalizadas ficam no campo JSON rec_item.extras.
"""
import json
import os
import sqlite3
from datetime import date, datetime
from io import BytesIO

from flask import (Blueprint, current_app, flash, g, redirect, render_template,
                   request, send_file, url_for)
from flask_login import current_user

recebimentos_bp = Blueprint("recebimentos", __name__,
                            url_prefix="/recebimentos",
                            template_folder="templates")

SITUACOES = ["No depósito", "Distribuído", "Em teste", "Defeito", "Descarte"]

ESQUEMA = """
CREATE TABLE IF NOT EXISTS rec_lote (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo      TEXT NOT NULL,
    data_chegada TEXT,
    origem      TEXT,
    documento   TEXT,
    observacao  TEXT,
    criado_por  TEXT,
    criado_em   TEXT
);
CREATE TABLE IF NOT EXISTS rec_item (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    lote_id     INTEGER NOT NULL REFERENCES rec_lote(id) ON DELETE CASCADE,
    material    TEXT NOT NULL,
    tipo        TEXT,
    modelo      TEXT,
    qtd         INTEGER DEFAULT 1,
    serie       TEXT,
    situacao    TEXT DEFAULT 'No depósito',
    destino     TEXT,
    observacao  TEXT
);
CREATE INDEX IF NOT EXISTS ix_rec_item_lote ON rec_item(lote_id);
CREATE TABLE IF NOT EXISTS rec_entrega (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    lote_id     INTEGER NOT NULL REFERENCES rec_lote(id) ON DELETE CASCADE,
    data        TEXT,
    destino     TEXT NOT NULL,
    recebedor   TEXT,
    documento   TEXT,
    observacao  TEXT,
    registrado_por TEXT,
    registrado_em  TEXT
);
CREATE TABLE IF NOT EXISTS rec_entrega_item (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    entrega_id  INTEGER NOT NULL REFERENCES rec_entrega(id) ON DELETE CASCADE,
    item_id     INTEGER NOT NULL REFERENCES rec_item(id) ON DELETE CASCADE,
    qtd         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_rec_entrega_lote ON rec_entrega(lote_id);
CREATE INDEX IF NOT EXISTS ix_rec_ei_item ON rec_entrega_item(item_id);
"""



# ---------------------------------------------------------------- banco
def _caminho_db():
    uri = current_app.config.get("SQLALCHEMY_DATABASE_URI", "")
    if uri.startswith("sqlite:///"):
        return uri[len("sqlite:///"):]
    return os.path.join(current_app.root_path, "sisparque.db")


def db():
    if "rec_db" not in g:
        con = sqlite3.connect(_caminho_db())
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        con.executescript(ESQUEMA)
        cols = {r[1] for r in con.execute("PRAGMA table_info(rec_item)")}
        if "extras" not in cols:
            con.execute("ALTER TABLE rec_item ADD COLUMN extras TEXT")
            con.commit()
        cols = {r[1] for r in con.execute("PRAGMA table_info(rec_entrega)")}
        if "tipo_destino" not in cols:
            con.execute("ALTER TABLE rec_entrega ADD COLUMN tipo_destino TEXT DEFAULT 'Interno'")
            con.commit()
        g.rec_db = con
    return g.rec_db


@recebimentos_bp.teardown_app_request
def _fecha_db(_exc):
    con = g.pop("rec_db", None)
    if con is not None:
        con.close()


# ---------------------------------------------------------------- login
@recebimentos_bp.before_request
def _exige_login():
    if not current_user.is_authenticated:
        return current_app.login_manager.unauthorized()
    return None


def _usuario():
    return getattr(current_user, "display_name", "") or ""


def _opcoes(tipo):
    """Listas editaveis em Configuracoes (tabela opcoes_config do sistema)."""
    try:
        return [r[0] for r in db().execute(
            "SELECT valor FROM opcoes_config WHERE tipo=? ORDER BY valor", (tipo,))]
    except sqlite3.Error:
        return []


# Campos de fabrica dos itens (mesma lista de CAMPOS_FIXOS_POR_TIPO["recebimento"])
CAMPOS_FIXOS = ["material", "tipo", "modelo", "qtd", "serie", "situacao", "destino", "observacao"]
ROTULOS_PADRAO = {"material": "Material", "tipo": "Tipo / Marca", "modelo": "Modelo", "qtd": "Qtd",
                  "serie": "Nº de série", "situacao": "Situação", "destino": "Destino",
                  "observacao": "Observação"}


def colunas():
    """Colunas visiveis na ordem do Editar Colunas. Cada uma:
    {'chave_form': nome do campo no form, 'rotulo', 'fixo': chave fixa ou None,
     'extra': chave do campo extra ou None}"""
    func = current_app.extensions.get("sisparque_colunas")
    if func is None:  # rodando fora do SISPARQUE: so os campos de fabrica
        return [{"chave_form": c, "rotulo": ROTULOS_PADRAO[c], "fixo": c, "extra": None}
                for c in CAMPOS_FIXOS]
    saida = []
    for item in func("recebimento"):
        if item["origem"] == "fixo":
            if item["campo_fixo"] not in CAMPOS_FIXOS:
                continue
            saida.append({"chave_form": item["campo_fixo"], "rotulo": item["rotulo"],
                          "fixo": item["campo_fixo"], "extra": None})
        else:
            ch = item["campo_extra"].chave
            saida.append({"chave_form": f"extra_{ch}", "rotulo": item["rotulo"],
                          "fixo": None, "extra": ch})
    return saida


def _extras(item):
    try:
        return json.loads(item["extras"] or "{}") if item is not None else {}
    except (ValueError, TypeError, KeyError, IndexError):
        return {}


def valor(item, col):
    """Valor de uma coluna (fixa ou personalizada) num item."""
    if item is None:
        return ""
    if col["fixo"]:
        v = item[col["fixo"]]
    else:
        v = _extras(item).get(col["extra"], "")
    return "" if v is None else v


@recebimentos_bp.context_processor
def _ctx():
    return {"SITUACOES": SITUACOES, "opcoes_rec": _opcoes, "valor_rec": valor}


def _int(valor, padrao=1):
    try:
        return max(0, int(str(valor).strip()))
    except (TypeError, ValueError):
        return padrao


def _br(data_iso):
    try:
        return datetime.strptime(data_iso, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return data_iso or ""


recebimentos_bp.add_app_template_filter(_br, "data_br")


def entregue_por_item(lote_id=None):
    """{item_id: quantidade ja entregue}"""
    sql = """SELECT ei.item_id, SUM(ei.qtd) FROM rec_entrega_item ei
               JOIN rec_item i ON i.id = ei.item_id"""
    args = ()
    if lote_id is not None:
        sql += " WHERE i.lote_id=?"
        args = (lote_id,)
    sql += " GROUP BY ei.item_id"
    return {r[0]: r[1] or 0 for r in db().execute(sql, args)}


def status_lote(total, entregue, linhas):
    if not linhas:
        return ("Sem itens", "sit-descarte")
    if entregue <= 0:
        return ("Em estoque", "sit-deposito")
    if entregue >= total:
        return ("Concluído", "sit-distribuido")
    return ("Entrega parcial", "sit-teste")


def _ajusta_situacao(item_ids):
    """Saldo zerado -> Distribuído; voltou a ter saldo -> No depósito.
    So mexe em quem esta nesses dois estados (Defeito/Descarte/Em teste ficam)."""
    if not item_ids:
        return
    ent = entregue_por_item()
    for iid in set(item_ids):
        it = db().execute("SELECT qtd, situacao FROM rec_item WHERE id=?", (iid,)).fetchone()
        if it is None:
            continue
        saldo = (it["qtd"] or 0) - ent.get(iid, 0)
        if saldo <= 0 and it["situacao"] == "No depósito":
            db().execute("UPDATE rec_item SET situacao='Distribuído' WHERE id=?", (iid,))
        elif saldo > 0 and it["situacao"] == "Distribuído":
            db().execute("UPDATE rec_item SET situacao='No depósito' WHERE id=?", (iid,))


TIPOS_DESTINO = ("Interno", "Externo")


def _destinos(tipo="Interno"):
    """Interno: setores de Configuracoes. Externo: OMs da lista 'Destino Externo (OM)'.
    Mais os destinos desse tipo ja usados em entregas anteriores."""
    v = set(_opcoes("setor" if tipo == "Interno" else "rec_destino_externo"))
    v.update(r[0] for r in db().execute(
        "SELECT DISTINCT destino FROM rec_entrega WHERE destino<>'' AND COALESCE(tipo_destino,'Interno')=?",
        (tipo,)))
    return sorted(v, key=str.lower)


def _setores():
    return _destinos("Interno")


# ---------------------------------------------------------------- lotes
@recebimentos_bp.route("/")
def lista():
    busca = (request.args.get("q") or "").strip()
    linhas_lote = db().execute("""
        SELECT l.*, COUNT(i.id) AS linhas, COALESCE(SUM(i.qtd),0) AS total,
               COALESCE((SELECT SUM(ei.qtd) FROM rec_entrega_item ei
                           JOIN rec_item i2 ON i2.id = ei.item_id
                          WHERE i2.lote_id = l.id), 0) AS entregue
          FROM rec_lote l LEFT JOIN rec_item i ON i.lote_id = l.id
         GROUP BY l.id
         ORDER BY COALESCE(l.data_chegada, l.criado_em) DESC, l.id DESC""").fetchall()
    filtro = request.args.get("status", "")
    lotes = []
    for l in linhas_lote:
        d = dict(l)
        d["saldo"] = d["total"] - d["entregue"]
        d["status"], d["status_cls"] = status_lote(d["total"], d["entregue"], d["linhas"])
        if not filtro or d["status"] == filtro:
            lotes.append(d)
    achados = []
    if busca:
        termo = f"%{busca}%"
        achados = db().execute("""
            SELECT i.*, l.titulo AS lote_titulo FROM rec_item i
              JOIN rec_lote l ON l.id = i.lote_id
             WHERE i.material LIKE ? OR i.tipo LIKE ? OR i.modelo LIKE ?
                OR i.serie LIKE ? OR i.destino LIKE ? OR i.observacao LIKE ?
                OR i.extras LIKE ?
             ORDER BY l.id DESC, i.id""", (termo,) * 7).fetchall()
    return render_template("recebimentos/lista.html", lotes=lotes, filtro=filtro,
                           busca=busca, achados=achados, colunas=colunas(),
                           qtd_lotes=len(linhas_lote))


@recebimentos_bp.route("/novo", methods=["GET", "POST"])
def novo():
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        if not titulo:
            flash("Informe o título do recebimento.", "erro")
            return render_template("recebimentos/lote_form.html", lote=request.form)
        cur = db().execute(
            """INSERT INTO rec_lote (titulo, data_chegada, origem, documento,
                                     observacao, criado_por, criado_em)
               VALUES (?,?,?,?,?,?,?)""",
            (titulo, request.form.get("data_chegada") or None,
             request.form.get("origem", "").strip(),
             request.form.get("documento", "").strip(),
             request.form.get("observacao", "").strip(),
             _usuario(), datetime.now().strftime("%Y-%m-%d %H:%M")))
        db().commit()
        flash("Recebimento criado. Agora lance os itens.", "ok")
        return redirect(url_for("recebimentos.ver", lote_id=cur.lastrowid))
    return render_template("recebimentos/lote_form.html",
                           lote={"data_chegada": date.today().isoformat()})


def _lote_ou_404(lote_id):
    lote = db().execute("SELECT * FROM rec_lote WHERE id=?", (lote_id,)).fetchone()
    if lote is None:
        flash("Recebimento não encontrado.", "erro")
    return lote


@recebimentos_bp.route("/<int:lote_id>/editar", methods=["GET", "POST"])
def editar_lote(lote_id):
    lote = _lote_ou_404(lote_id)
    if lote is None:
        return redirect(url_for("recebimentos.lista"))
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        if not titulo:
            flash("Informe o título do recebimento.", "erro")
            return render_template("recebimentos/lote_form.html", lote=request.form, editando=True)
        db().execute("""UPDATE rec_lote SET titulo=?, data_chegada=?, origem=?,
                        documento=?, observacao=? WHERE id=?""",
                     (titulo, request.form.get("data_chegada") or None,
                      request.form.get("origem", "").strip(),
                      request.form.get("documento", "").strip(),
                      request.form.get("observacao", "").strip(), lote_id))
        db().commit()
        flash("Recebimento atualizado.", "ok")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id))
    return render_template("recebimentos/lote_form.html", lote=lote, editando=True)


@recebimentos_bp.route("/<int:lote_id>/excluir", methods=["POST"])
def excluir_lote(lote_id):
    db().execute("""DELETE FROM rec_entrega_item WHERE entrega_id IN
                    (SELECT id FROM rec_entrega WHERE lote_id=?)""", (lote_id,))
    db().execute("DELETE FROM rec_entrega WHERE lote_id=?", (lote_id,))
    db().execute("DELETE FROM rec_item WHERE lote_id=?", (lote_id,))
    db().execute("DELETE FROM rec_lote WHERE id=?", (lote_id,))
    db().commit()
    flash("Recebimento excluído.", "ok")
    return redirect(url_for("recebimentos.lista"))


# ---------------------------------------------------------------- itens
@recebimentos_bp.route("/<int:lote_id>")
def ver(lote_id):
    lote = _lote_ou_404(lote_id)
    if lote is None:
        return redirect(url_for("recebimentos.lista"))
    itens = db().execute("SELECT * FROM rec_item WHERE lote_id=? ORDER BY id",
                         (lote_id,)).fetchall()
    editar_id = request.args.get("editar", type=int)
    item_edit = next((i for i in itens if i["id"] == editar_id), None)
    total = sum(i["qtd"] or 0 for i in itens)
    cols = colunas()
    tem_situacao = any(c["fixo"] == "situacao" for c in cols)
    entregue = entregue_por_item(lote_id)
    total_entregue = sum(entregue.values())
    entregas = []
    for e in db().execute("SELECT * FROM rec_entrega WHERE lote_id=? ORDER BY data DESC, id DESC",
                          (lote_id,)).fetchall():
        d = dict(e)
        d["itens"] = db().execute("""SELECT ei.qtd, i.material, i.tipo, i.modelo FROM rec_entrega_item ei
                                       JOIN rec_item i ON i.id = ei.item_id
                                      WHERE ei.entrega_id=? ORDER BY i.id""", (e["id"],)).fetchall()
        d["total"] = sum(x["qtd"] for x in d["itens"])
        entregas.append(d)
    status, status_cls = status_lote(total, total_entregue, len(itens))
    return render_template("recebimentos/lote.html", lote=lote, itens=itens,
                           item_edit=item_edit, total=total, colunas=cols,
                           tem_situacao=tem_situacao, entregue=entregue,
                           total_entregue=total_entregue, entregas=entregas,
                           status=status, status_cls=status_cls)


def _valor_fixo(chave, bruto):
    if chave == "qtd":
        return _int(bruto, 1)
    if chave == "situacao":
        return bruto if bruto in SITUACOES else SITUACOES[0]
    return (bruto or "").strip()


@recebimentos_bp.route("/<int:lote_id>/item", methods=["POST"])
def gravar_item(lote_id):
    if _lote_ou_404(lote_id) is None:
        return redirect(url_for("recebimentos.lista"))
    f = request.form
    item_id = f.get("item_id", type=int)
    atual = None
    if item_id:
        atual = db().execute("SELECT * FROM rec_item WHERE id=? AND lote_id=?",
                             (item_id, lote_id)).fetchone()
        if atual is None:
            flash("Item não encontrado.", "erro")
            return redirect(url_for("recebimentos.ver", lote_id=lote_id))

    # So mexe nos campos que estao na tela: coluna oculta guarda o valor que ja tinha.
    dados = {c: _valor_fixo(c, f.get(c)) for c in CAMPOS_FIXOS if c in f}
    if atual is None:
        if not dados.get("material"):
            flash("Informe o material.", "erro")
            return redirect(url_for("recebimentos.ver", lote_id=lote_id))
    elif "material" in dados and not dados["material"]:
        flash("Informe o material.", "erro")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id))

    if atual is not None and "qtd" in dados:
        ja = entregue_por_item(lote_id).get(item_id, 0)
        if dados["qtd"] < ja:
            flash(f"Já foram entregues {ja} unidade(s) desse item; a quantidade não pode ficar menor que isso.", "erro")
            return redirect(url_for("recebimentos.ver", lote_id=lote_id, editar=item_id))

    extras = _extras(atual) if atual is not None else {}
    for chave_form, v in f.items():
        if chave_form.startswith("extra_"):
            extras[chave_form[len("extra_"):]] = v.strip()
    dados["extras"] = json.dumps(extras, ensure_ascii=False)

    if atual is not None:
        sets = ", ".join(f"{c}=?" for c in dados)
        db().execute(f"UPDATE rec_item SET {sets} WHERE id=? AND lote_id=?",
                     list(dados.values()) + [item_id, lote_id])
        _ajusta_situacao([item_id])
        flash("Item atualizado.", "ok")
    else:
        dados["lote_id"] = lote_id
        nomes = ", ".join(dados)
        marcas = ", ".join("?" * len(dados))
        db().execute(f"INSERT INTO rec_item ({nomes}) VALUES ({marcas})", list(dados.values()))
        flash("Item gravado.", "ok")
    db().commit()
    return redirect(url_for("recebimentos.ver", lote_id=lote_id))


@recebimentos_bp.route("/<int:lote_id>/item/<int:item_id>/excluir", methods=["POST"])
def excluir_item(lote_id, item_id):
    if entregue_por_item(lote_id).get(item_id):
        flash("Esse item já tem entregas registradas. Estorne as entregas dele antes de excluir.", "erro")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id))
    db().execute("DELETE FROM rec_item WHERE id=? AND lote_id=?", (item_id, lote_id))
    db().commit()
    flash("Item excluído.", "ok")
    return redirect(url_for("recebimentos.ver", lote_id=lote_id))


@recebimentos_bp.route("/<int:lote_id>/situacao", methods=["POST"])
def situacao_em_massa(lote_id):
    """Muda a situação/destino de varios itens marcados de uma vez."""
    ids = [int(x) for x in request.form.getlist("sel") if x.isdigit()]
    nova = request.form.get("nova_situacao")
    destino = request.form.get("novo_destino", "").strip()
    if ids and nova in SITUACOES:
        marcas = ",".join("?" * len(ids))
        if destino:
            db().execute(f"UPDATE rec_item SET situacao=?, destino=? WHERE lote_id=? AND id IN ({marcas})",
                         [nova, destino, lote_id] + ids)
        else:
            db().execute(f"UPDATE rec_item SET situacao=? WHERE lote_id=? AND id IN ({marcas})",
                         [nova, lote_id] + ids)
        db().commit()
        flash(f"{len(ids)} item(ns) marcados como '{nova}'.", "ok")
    else:
        flash("Marque pelo menos um item e escolha a situação.", "erro")
    return redirect(url_for("recebimentos.ver", lote_id=lote_id))


# ---------------------------------------------------------------- PDF
@recebimentos_bp.route("/<int:lote_id>/pdf")
def pdf(lote_id):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (Paragraph, SimpleDocTemplate, Spacer, Table,
                                    TableStyle)

    lote = _lote_ou_404(lote_id)
    if lote is None:
        return redirect(url_for("recebimentos.lista"))
    itens = db().execute("SELECT * FROM rec_item WHERE lote_id=? ORDER BY id",
                         (lote_id,)).fetchall()

    verde = colors.HexColor("#3d4a2e")
    creme = colors.HexColor("#f1ead8")
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=14 * mm,
                            rightMargin=14 * mm, topMargin=12 * mm, bottomMargin=14 * mm,
                            title=f"Recebimento - {lote['titulo']}")
    est = getSampleStyleSheet()
    cab = ParagraphStyle("cab", parent=est["Normal"], fontSize=9, leading=12)
    cel = ParagraphStyle("cel", parent=est["Normal"], fontSize=8.5, leading=10)
    tit = ParagraphStyle("tit", parent=est["Title"], fontSize=15, textColor=verde,
                         spaceAfter=2)
    sub = ParagraphStyle("sub", parent=est["Normal"], fontSize=9, alignment=1,
                         textColor=colors.HexColor("#555555"))

    def esc(txt):
        txt = "" if txt is None else str(txt)
        return txt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def p(txt, st=cel):
        return Paragraph(esc(txt), st)

    def rot(rotulo, valor, st=cab):
        return Paragraph(f"<b>{rotulo}:</b> {esc(valor) or '-'}", st)

    corpo = [Paragraph("SISPARQUE — Termo de Recebimento de Material", tit),
             Paragraph(f"Emitido em {datetime.now():%d/%m/%Y %H:%M}", sub),
             Spacer(1, 5 * mm)]

    info = [[rot("Recebimento", lote["titulo"]),
             rot("Data de chegada", _br(lote["data_chegada"]))],
            [rot("Origem", lote["origem"]), rot("Documento", lote["documento"])]]
    if lote["observacao"]:
        info.append([rot("Observação", lote["observacao"]), ""])
    ti = Table(info, colWidths=[134 * mm, 134 * mm])
    estilo_info = [("BOX", (0, 0), (-1, -1), 0.6, verde),
                   ("BACKGROUND", (0, 0), (-1, -1), creme),
                   ("VALIGN", (0, 0), (-1, -1), "TOP"),
                   ("TOPPADDING", (0, 0), (-1, -1), 4)]
    if lote["observacao"]:
        estilo_info.append(("SPAN", (0, 2), (1, 2)))
    ti.setStyle(TableStyle(estilo_info))
    corpo += [ti, Spacer(1, 5 * mm)]

    cols = colunas()
    h = ParagraphStyle("h", parent=cel, textColor=colors.white, fontName="Helvetica-Bold")
    linhas = [[p("UN", h)] + [p(c["rotulo"].upper(), h) for c in cols]]
    for n, i in enumerate(itens, 1):
        linhas.append([p(f"{n:02d}")] + [p(valor(i, c)) for c in cols])
    total = sum(i["qtd"] or 0 for i in itens)
    negr = ParagraphStyle("negr", parent=cel, fontName="Helvetica-Bold")
    rodape = [p("")] + ["" for _ in cols]
    if cols:
        rodape[1] = p("TOTAL", negr)
    pos_qtd = next((k for k, c in enumerate(cols, 1) if c["fixo"] == "qtd"), None)
    if pos_qtd is not None:
        rodape[pos_qtd] = p(total, negr)
    elif len(rodape) > 2:
        rodape[2] = p(f"{total} unidade(s)", negr)
    linhas.append(rodape)
    peso = {"qtd": 0.45, "situacao": 0.85, "observacao": 1.2}
    pesos = [peso.get(c["fixo"], 1.0) for c in cols] or [1.0]
    sobra = 268 - 11
    larg = [11] + [sobra * w / sum(pesos) for w in pesos]
    tt = Table(linhas, colWidths=[w * mm for w in larg][:len(linhas[0])], repeatRows=1)
    st = [("BACKGROUND", (0, 0), (-1, 0), verde),
          ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#b9b09a")),
          ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#e2dbc6"))]
    for r in range(1, len(linhas) - 1):
        if r % 2 == 0:
            st.append(("BACKGROUND", (0, r), (-1, r), creme))
    tt.setStyle(TableStyle(st))
    corpo += [tt, Spacer(1, 18 * mm)]

    ass = Table([["_" * 42, "_" * 42],
                 [p("Recebido por (nome / posto / NIP)", sub), p("Conferido por (nome / posto / NIP)", sub)]],
                colWidths=[134 * mm, 134 * mm])
    ass.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
    corpo.append(ass)

    doc.build(corpo)
    buf.seek(0)
    nome = "".join(c if c.isalnum() else "_" for c in lote["titulo"])[:40]
    return send_file(buf, mimetype="application/pdf", as_attachment=False,
                     download_name=f"recebimento_{nome}.pdf")


# ---------------------------------------------------------------- entregas
@recebimentos_bp.route("/<int:lote_id>/entregar", methods=["GET", "POST"])
def entregar(lote_id):
    """Saida de material: um ou mais itens do lote para um destino/recebedor."""
    lote = _lote_ou_404(lote_id)
    if lote is None:
        return redirect(url_for("recebimentos.lista"))
    ent = entregue_por_item(lote_id)
    ids = [int(x) for x in (request.values.getlist("sel") or request.values.getlist("item"))
           if str(x).isdigit()]
    if request.method == "GET" and not ids:
        flash("Marque na caixinha os itens que vão ser entregues e clique em Entregar marcados.", "erro")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id))
    itens = []
    for iid in ids:
        it = db().execute("SELECT * FROM rec_item WHERE id=? AND lote_id=?", (iid, lote_id)).fetchone()
        if it is not None:
            d = dict(it)
            d["saldo"] = (it["qtd"] or 0) - ent.get(iid, 0)
            itens.append(d)
    sem_saldo = [i for i in itens if i["saldo"] <= 0]
    itens = [i for i in itens if i["saldo"] > 0]
    if request.method == "GET" and not itens:
        flash("Os itens marcados não têm saldo para entregar.", "erro")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id))

    if request.method == "POST" and request.form.get("confirmar"):
        f = request.form
        destino = f.get("destino", "").strip()
        tipo_destino = f.get("tipo_destino") if f.get("tipo_destino") in TIPOS_DESTINO else "Interno"
        erros = []
        if not destino:
            erros.append("Informe o destino da entrega.")
        quantidades = {}
        for i in itens:
            q = _int(f.get(f"qtd_{i['id']}"), 0)
            if q > i["saldo"]:
                erros.append(f"{i['material']}: saldo é {i['saldo']}, não dá para entregar {q}.")
            elif q > 0:
                quantidades[i["id"]] = q
        if not quantidades and not erros:
            erros.append("Coloque a quantidade a entregar em pelo menos um item.")
        if erros:
            for e in erros:
                flash(e, "erro")
            return render_template("recebimentos/entregar.html", lote=lote, itens=itens,
                                   sem_saldo=sem_saldo, form=f, setores=_destinos("Interno"),
                                   externos=_destinos("Externo"), colunas=colunas())
        cur = db().execute(
            """INSERT INTO rec_entrega (lote_id, data, destino, tipo_destino, recebedor, documento,
                                        observacao, registrado_por, registrado_em)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (lote_id, f.get("data") or date.today().isoformat(), destino, tipo_destino,
             f.get("recebedor", "").strip(), f.get("documento", "").strip(),
             f.get("observacao", "").strip(), _usuario(),
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        for iid, q in quantidades.items():
            db().execute("INSERT INTO rec_entrega_item (entrega_id, item_id, qtd) VALUES (?,?,?)",
                         (cur.lastrowid, iid, q))
        _ajusta_situacao(list(quantidades))
        db().commit()
        flash(f"Entrega registrada: {sum(quantidades.values())} unidade(s) para {destino}. "
              f"Use o botão Guia para imprimir o documento de entrega.", "ok")
        return redirect(url_for("recebimentos.ver", lote_id=lote_id) + "#entregas")

    return render_template("recebimentos/entregar.html", lote=lote, itens=itens,
                           sem_saldo=sem_saldo, form={"data": date.today().isoformat(), "tipo_destino": "Interno"},
                           setores=_destinos("Interno"), externos=_destinos("Externo"),
                           colunas=colunas())


@recebimentos_bp.route("/entrega/<int:entrega_id>/estornar", methods=["POST"])
def estornar(entrega_id):
    e = db().execute("SELECT * FROM rec_entrega WHERE id=?", (entrega_id,)).fetchone()
    if e is None:
        flash("Entrega não encontrada.", "erro")
        return redirect(url_for("recebimentos.lista"))
    ids = [r[0] for r in db().execute("SELECT item_id FROM rec_entrega_item WHERE entrega_id=?",
                                      (entrega_id,))]
    db().execute("DELETE FROM rec_entrega_item WHERE entrega_id=?", (entrega_id,))
    db().execute("DELETE FROM rec_entrega WHERE id=?", (entrega_id,))
    _ajusta_situacao(ids)
    db().commit()
    flash("Entrega estornada: o material voltou para o saldo.", "ok")
    return redirect(url_for("recebimentos.ver", lote_id=e["lote_id"]) + "#entregas")


# ---------------------------------------------------------------- estoque geral
@recebimentos_bp.route("/estoque")
def estoque():
    destino_f = (request.args.get("destino") or "").strip()
    ent = entregue_por_item()
    itens = db().execute("""SELECT i.*, l.titulo AS lote_titulo FROM rec_item i
                              JOIN rec_lote l ON l.id = i.lote_id""").fetchall()
    resumo = {}
    for i in itens:
        chave = ((i["material"] or "").strip().title(), (i["tipo"] or "").strip())
        r = resumo.setdefault(chave, {"material": chave[0], "tipo": chave[1], "recebido": 0,
                                      "entregue": 0, "defeito": 0, "lotes": set()})
        r["recebido"] += i["qtd"] or 0
        r["entregue"] += ent.get(i["id"], 0)
        if i["situacao"] in ("Defeito", "Descarte"):
            r["defeito"] += (i["qtd"] or 0) - ent.get(i["id"], 0)
        r["lotes"].add(i["lote_titulo"])
    resumo = sorted(resumo.values(), key=lambda r: (r["material"].lower(), r["tipo"].lower()))
    for r in resumo:
        r["saldo"] = r["recebido"] - r["entregue"]
        r["lotes"] = ", ".join(sorted(r["lotes"]))
    totais = {k: sum(r[k] for r in resumo) for k in ("recebido", "entregue", "saldo")}

    por_destino = db().execute("""SELECT e.destino, COALESCE(e.tipo_destino,'Interno') AS tipo_destino,
                                         COUNT(DISTINCT e.id) AS entregas, SUM(ei.qtd) AS qtd,
                                         MAX(e.data) AS ultima
                                    FROM rec_entrega e JOIN rec_entrega_item ei ON ei.entrega_id = e.id
                                   GROUP BY e.destino, COALESCE(e.tipo_destino,'Interno')
                                   ORDER BY qtd DESC""").fetchall()
    sql = """SELECT e.*, l.titulo AS lote_titulo, ei.qtd, i.material, i.tipo, i.modelo
               FROM rec_entrega e JOIN rec_entrega_item ei ON ei.entrega_id = e.id
               JOIN rec_item i ON i.id = ei.item_id JOIN rec_lote l ON l.id = e.lote_id"""
    args = ()
    if destino_f:
        sql += " WHERE e.destino=?"
        args = (destino_f,)
    sql += " ORDER BY e.data DESC, e.id DESC, i.id LIMIT 300"
    movimentos = db().execute(sql, args).fetchall()
    return render_template("recebimentos/estoque.html", resumo=resumo, totais=totais,
                           por_destino=por_destino, movimentos=movimentos, destino_f=destino_f)


# ---------------------------------------------------------------- exportar
def _monta_planilha(lote_id):
    """Monta a Planilha (formatada) do recebimento. Usada tanto pela exportacao
    .xlsx quanto pela .ods - o mesmo conteudo, so muda o formato do arquivo."""
    from planilhas import Planilha, C

    lote = _lote_ou_404(lote_id)
    if lote is None:
        return None, None
    cols = colunas()
    ent = entregue_por_item(lote_id)
    itens = db().execute("SELECT * FROM rec_item WHERE lote_id=? ORDER BY id", (lote_id,)).fetchall()

    # colunas da tabela: UN + colunas configuradas + Entregue + Saldo
    ncols = 1 + len(cols) + 2

    p = Planilha("Recebimento")
    # larguras (em caracteres): UN estreito, colunas pelo rotulo, Entregue/Saldo medios
    larg = [5] + [max(14, len(c["rotulo"]) + 4) for c in cols] + [10, 8]
    p.largura(larg)

    # --- cabecalho do documento (linhas de largura total, sem cortar texto) ---
    p.linha([C("Recebimento: " + (lote["titulo"] or ""), "titulo", colspan=ncols)])
    meta = "Chegada: %s     ·     Origem: %s     ·     Documento: %s" % (
        _br(lote["data_chegada"]) or "-", lote["origem"] or "-", lote["documento"] or "-")
    p.linha([C(meta, "rotulo", colspan=ncols)])
    if lote["observacao"]:
        p.linha([C("Observacao: " + lote["observacao"], "info", colspan=ncols)])
    p.linha_vazia()

    # --- tabela de itens ---
    p.linha([C("UN", "cab")] + [C(c["rotulo"], "cab") for c in cols]
            + [C("Entregue", "cab"), C("Saldo", "cab")])
    for n, i in enumerate(itens, 1):
        e = ent.get(i["id"], 0)
        saldo = (i["qtd"] or 0) - e
        linha = [C("%02d" % n, "texto")]
        for c in cols:
            v = valor(i, c)
            estilo = "num" if (c["fixo"] == "qtd") else "texto"
            linha.append(C(v, estilo))
        linha += [C(e, "num"), C(saldo, "num")]
        p.linha(linha)

    totais = "Totais:  recebido %d   ·   entregue %d   ·   saldo em estoque %d" % (
        sum((i["qtd"] or 0) for i in itens),
        sum(ent.get(i["id"], 0) for i in itens),
        sum((i["qtd"] or 0) - ent.get(i["id"], 0) for i in itens))
    p.linha([C(totais, "rotulo", colspan=ncols)])

    # --- entregas (se houver) ---
    entregas = db().execute("""SELECT e.data, e.destino, e.recebedor, e.documento, i.material, i.tipo, ei.qtd
                                 FROM rec_entrega e JOIN rec_entrega_item ei ON ei.entrega_id=e.id
                                 JOIN rec_item i ON i.id=ei.item_id
                                WHERE e.lote_id=? ORDER BY e.data, e.id""", (lote_id,)).fetchall()
    if entregas:
        p.linha_vazia()
        p.linha([C("ENTREGAS", "secao", colspan=ncols)])
        p.linha([C("Data", "cab"), C("Destino", "cab"), C("Recebedor", "cab"),
                 C("Documento", "cab"), C("Material", "cab"), C("Tipo / Marca", "cab"),
                 C("Qtd", "cab")])
        for e in entregas:
            p.linha([C(_br(e["data"]), "texto"), C(e["destino"] or "", "texto"),
                     C(e["recebedor"] or "", "texto"), C(e["documento"] or "", "texto"),
                     C(e["material"] or "", "texto"), C(e["tipo"] or "", "texto"),
                     C(e["qtd"], "num")])

    nome = "".join(c if c.isalnum() else "_" for c in (lote["titulo"] or "recebimento"))[:40]
    return p, nome


@recebimentos_bp.route("/<int:lote_id>/xlsx")
def exportar(lote_id):
    """Exporta o recebimento em Excel (.xlsx), ja formatado."""
    p, nome = _monta_planilha(lote_id)
    if p is None:
        return redirect(url_for("recebimentos.lista"))
    dados = BytesIO(p.xlsx())
    return send_file(dados,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     as_attachment=True, download_name=f"recebimento_{nome}.xlsx")


@recebimentos_bp.route("/<int:lote_id>/ods")
def exportar_ods(lote_id):
    """Exporta o recebimento em LibreOffice Calc (.ods), ja formatado."""
    p, nome = _monta_planilha(lote_id)
    if p is None:
        return redirect(url_for("recebimentos.lista"))
    dados = BytesIO(p.ods())
    return send_file(dados,
                     mimetype="application/vnd.oasis.opendocument.spreadsheet",
                     as_attachment=True, download_name=f"recebimento_{nome}.ods")


# ---------------------------------------------------------------- guia de entrega
@recebimentos_bp.route("/entrega/<int:entrega_id>/guia")
def guia(entrega_id):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    e = db().execute("""SELECT e.*, l.titulo AS lote_titulo, l.origem, l.documento AS lote_doc
                          FROM rec_entrega e JOIN rec_lote l ON l.id = e.lote_id
                         WHERE e.id=?""", (entrega_id,)).fetchone()
    if e is None:
        flash("Entrega não encontrada.", "erro")
        return redirect(url_for("recebimentos.lista"))
    itens = db().execute("""SELECT i.*, ei.qtd AS qtd_entregue FROM rec_entrega_item ei
                              JOIN rec_item i ON i.id = ei.item_id
                             WHERE ei.entrega_id=? ORDER BY i.id""", (entrega_id,)).fetchall()
    # colunas descritivas (sem qtd/situacao/destino/obs, que nao fazem sentido na guia)
    cols = [c for c in colunas() if c["fixo"] not in ("qtd", "situacao", "destino", "observacao")]

    verde = colors.HexColor("#3d4a2e")
    creme = colors.HexColor("#f1ead8")
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm,
                            title=f"Guia de entrega {entrega_id:04d}")
    est = getSampleStyleSheet()
    cab = ParagraphStyle("cab", parent=est["Normal"], fontSize=9.5, leading=13)
    cel = ParagraphStyle("cel", parent=est["Normal"], fontSize=8.5, leading=10)
    h = ParagraphStyle("h", parent=cel, textColor=colors.white, fontName="Helvetica-Bold")
    negr = ParagraphStyle("negr", parent=cel, fontName="Helvetica-Bold")
    tit = ParagraphStyle("tit", parent=est["Title"], fontSize=15, textColor=verde, spaceAfter=2)
    sub = ParagraphStyle("sub", parent=est["Normal"], fontSize=9, alignment=1,
                         textColor=colors.HexColor("#555555"))

    def esc(t):
        t = "" if t is None else str(t)
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def p(t, st=cel):
        return Paragraph(esc(t), st)

    def rot(r, v):
        return Paragraph(f"<b>{r}:</b> {esc(v) or '-'}", cab)

    corpo = [Paragraph(f"SISPARQUE — Guia de Entrega de Material Nº {entrega_id:04d}", tit),
             Paragraph(f"Emitida em {datetime.now():%d/%m/%Y %H:%M}", sub), Spacer(1, 5 * mm)]
    externo = (e["tipo_destino"] or "Interno") == "Externo"
    info = [[rot("Destino (OM externa)" if externo else "Destino (setor)", e["destino"]),
             rot("Data da entrega", _br(e["data"]))],
            [rot("Recebedor", e["recebedor"]), rot("Documento", e["documento"])],
            [rot("Material do recebimento", e["lote_titulo"]), rot("Origem", e["origem"])]]
    if e["observacao"]:
        info.append([rot("Observação", e["observacao"]), ""])
    ti = Table(info, colWidths=[90 * mm, 90 * mm])
    st_info = [("BOX", (0, 0), (-1, -1), 0.6, verde), ("BACKGROUND", (0, 0), (-1, -1), creme),
               ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if e["observacao"]:
        st_info.append(("SPAN", (0, len(info) - 1), (1, len(info) - 1)))
    ti.setStyle(TableStyle(st_info))
    corpo += [ti, Spacer(1, 5 * mm)]

    linhas = [[p("UN", h)] + [p(c["rotulo"].upper(), h) for c in cols] + [p("QTD", h)]]
    for n, i in enumerate(itens, 1):
        linhas.append([p(f"{n:02d}")] + [p(valor(i, c)) for c in cols] + [p(i["qtd_entregue"], negr)])
    total = sum(i["qtd_entregue"] for i in itens)
    rodape = [p("")] + ["" for _ in cols] + [p(total, negr)]
    if cols:
        rodape[1] = p("TOTAL", negr)
    linhas.append(rodape)
    sobra = 180 - 10 - 16
    larg = [10] + [sobra / max(len(cols), 1)] * len(cols) + [16]
    tt = Table(linhas, colWidths=[w * mm for w in larg], repeatRows=1)
    st = [("BACKGROUND", (0, 0), (-1, 0), verde),
          ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#b9b09a")),
          ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#e2dbc6"))]
    for r in range(2, len(linhas) - 1, 2):
        st.append(("BACKGROUND", (0, r), (-1, r), creme))
    tt.setStyle(TableStyle(st))
    corpo += [tt, Spacer(1, 6 * mm),
              Paragraph("Declaro ter recebido o material acima relacionado, em condições de uso, "
                        "ficando sob minha responsabilidade.", cab),
              Spacer(1, 20 * mm)]
    ass = Table([["_" * 40, "_" * 40],
                 [p("Entregue por (nome / posto / NIP)", sub), p("Recebido por (nome / posto / NIP)", sub)]],
                colWidths=[90 * mm, 90 * mm])
    ass.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
    corpo.append(ass)
    doc.build(corpo)
    buf.seek(0)
    return send_file(buf, mimetype="application/pdf", as_attachment=False,
                     download_name=f"guia_entrega_{entrega_id:04d}.pdf")
