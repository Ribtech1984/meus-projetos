"""
Migra os dados do backup .sql do SISPARQUE (PHP/MariaDB) para o novo
banco SQLite do SISPARQUE Python.

Uso:
    python3 migrar_dados.py caminho/para/sisparque.sql

Não precisa de MySQL/MariaDB instalado — o script lê o arquivo .sql
como texto e interpreta os comandos INSERT INTO diretamente.
"""
import re
import sys
from datetime import datetime

from models import (
    db, Usuario, Maquina, Switch, Impressora, ContatoTI, Telefone,
    ContatoTelefonia, OpcaoConfig, HistoricoManutencao,
)


def extrair_tuplas(sql_texto, nome_tabela):
    """Extrai as tuplas de valores de todos os INSERT INTO `nome_tabela` (...) VALUES (...);"""
    padrao_insert = re.compile(
        r"INSERT INTO `" + re.escape(nome_tabela) + r"`.*?VALUES\s*(.*?);",
        re.IGNORECASE | re.DOTALL,
    )
    tuplas = []
    for bloco in padrao_insert.findall(sql_texto):
        tuplas.extend(_dividir_tuplas(bloco))
    return tuplas


def _dividir_tuplas(bloco):
    """Divide um bloco '(a, b, ...), (c, d, ...)' em uma lista de tuplas de valores brutos."""
    tuplas = []
    i, n = 0, len(bloco)
    while i < n:
        if bloco[i] == "(":
            fim = _fim_tupla(bloco, i)
            tuplas.append(_parse_tupla(bloco[i + 1:fim]))
            i = fim + 1
        else:
            i += 1
    return tuplas


def _fim_tupla(texto, inicio):
    """Dado o índice de um '(' de abertura, acha o ')' correspondente respeitando aspas."""
    profundidade = 0
    dentro_aspas = False
    i = inicio
    while i < len(texto):
        c = texto[i]
        if dentro_aspas:
            if c == "\\":
                i += 2
                continue
            if c == "'":
                dentro_aspas = False
        else:
            if c == "'":
                dentro_aspas = True
            elif c == "(":
                profundidade += 1
            elif c == ")":
                profundidade -= 1
                if profundidade == 0:
                    return i
        i += 1
    return len(texto) - 1


def _parse_tupla(texto):
    """Divide o conteúdo interno de uma tupla em valores Python (str ou None)."""
    valores = []
    atual = []
    dentro_aspas = False
    i, n = 0, len(texto)
    while i < n:
        c = texto[i]
        if dentro_aspas:
            if c == "\\" and i + 1 < n:
                atual.append(texto[i + 1])
                i += 2
                continue
            if c == "'":
                if i + 1 < n and texto[i + 1] == "'":
                    atual.append("'")
                    i += 2
                    continue
                dentro_aspas = False
                i += 1
                continue
            atual.append(c)
            i += 1
        else:
            if c == "'":
                dentro_aspas = True
                i += 1
                continue
            if c == ",":
                valores.append("".join(atual).strip())
                atual = []
                i += 1
                continue
            atual.append(c)
            i += 1
    valores.append("".join(atual).strip())

    resultado = []
    for v in valores:
        if v.upper() == "NULL":
            resultado.append(None)
        else:
            resultado.append(v)
    return resultado


def normalizar_nip(nip):
    """Converte '04036832' ou '04.0368.32' para o formato padrão XX.XXXX.XX."""
    if not nip:
        return nip
    digitos = re.sub(r"\D", "", nip)
    if len(digitos) == 8:
        return f"{digitos[0:2]}.{digitos[2:6]}.{digitos[6:8]}"
    return nip  # deixa como está se não bater com o formato esperado


def normalizar_sim_nao(valor):
    if not valor:
        return "Sim"
    return "Não" if valor.strip().lower().startswith("n") else "Sim"


def adicionar_opcao(cache, tipo, valor):
    if not valor:
        return
    valor = valor.strip()
    if not valor:
        return
    chave = (tipo, valor)
    if chave in cache:
        return
    if not OpcaoConfig.query.filter_by(tipo=tipo, valor=valor).first():
        db.session.add(OpcaoConfig(tipo=tipo, valor=valor))
    cache.add(chave)


def _int_ou_none(valor):
    try:
        return int(str(valor).strip())
    except (TypeError, ValueError):
        return None


def migrar(app, caminho_sql, substituir=True, ignorar_setor_vago=True):
    """Importa o .sql do SISPARQUE antigo.

    substituir=True (padrão): APAGA máquinas, histórico, switches, impressoras,
    telefonia e contatos atuais e coloca no lugar exatamente o que está no .sql —
    o resultado bate 1 para 1 com o sistema antigo, sem somar com o que já existia.
    Usuários, cores, opções e configurações NÃO são apagados.

    ignorar_setor_vago=True: não importa máquinas cujo setor é "VAGO", que o
    sistema antigo já escondia da tela (assim o total bate com o que ele mostrava).

    Retorna um dict com as quantidades importadas.
    """
    with open(caminho_sql, "r", encoding="utf-8") as f:
        sql_texto = f.read()

    resumo = {}
    with app.app_context():
        db.create_all()

        if substituir:
            HistoricoManutencao.query.delete()
            Maquina.query.delete()
            Switch.query.delete()
            Impressora.query.delete()
            ContatoTI.query.delete()
            Telefone.query.delete()
            ContatoTelefonia.query.delete()
            db.session.commit()

        cache_opcoes = {(o.tipo, o.valor) for o in OpcaoConfig.query.all()}

        # ---------------- MÁQUINAS ----------------
        colunas_maquinas = [
            "id", "nome_completo", "nip", "posto_grad", "corpo_quadro", "especialidade",
            "ip", "numero_maquina", "disponivel", "mac", "setor", "numero_patrimonial",
            "so", "memoria_tipo", "memoria_qtd", "armazenamento_tipo",
            "armazenamento_capacidade", "armazenamento_interface", "teclado", "mouse",
            "lacre", "processador_tipo", "processador_modelo", "data_compra",
            "historico_manutencao", "data_revitalizacao",
        ]
        tuplas = extrair_tuplas(sql_texto, "maquinas")
        total_maquinas = 0
        for t in tuplas:
            if len(t) != len(colunas_maquinas):
                print(f"  [aviso] linha de maquinas com {len(t)} campos (esperado {len(colunas_maquinas)}), pulando: {t[:3]}")
                continue
            reg = dict(zip(colunas_maquinas, t))

            if ignorar_setor_vago and (reg["setor"] or "").strip().upper() == "VAGO":
                continue  # o sistema antigo não mostrava essas — fica igual a ele

            ip = (reg["ip"] or "").strip()
            if not substituir and ip and Maquina.query.filter_by(ip=ip).first():
                continue  # modo "somar": não duplica a mesma máquina

            id_antigo = _int_ou_none(reg["id"])
            if id_antigo and db.session.get(Maquina, id_antigo):
                id_antigo = None  # id já usado — deixa o banco escolher outro
            m = Maquina(
                id=id_antigo,
                nome_completo=(reg["nome_completo"] or "").strip() or "SEM NOME",
                nip=normalizar_nip(reg["nip"]),
                posto_graduacao=(reg["posto_grad"] or "").strip(),
                corpo_quadro=(reg["corpo_quadro"] or "").strip(),
                especialidade=(reg["especialidade"] or "").strip(),
                ip=ip,
                num_maquina=(reg["numero_maquina"] or "").strip(),
                mac=(reg["mac"] or "").strip().upper(),
                lacre=(reg["lacre"] or "").strip(),
                processador_fabricante=(reg["processador_tipo"] or "").strip(),
                processador_modelo=(reg["processador_modelo"] or "").strip(),
                data_compra=(reg["data_compra"] or "").strip(),
                historico_manutencao=(reg["historico_manutencao"] or "").strip(),
                data_revitalizacao=(reg["data_revitalizacao"] or "").strip(),
                departamento_setor=(reg["setor"] or "").strip(),
                disponivel=normalizar_sim_nao(reg["disponivel"]),
                num_pat=(reg["numero_patrimonial"] or "").strip(),
                sistema_operacional=(reg["so"] or "").strip(),
                memoria_tipo=(reg["memoria_tipo"] or "").strip(),
                memoria_qtd=(reg["memoria_qtd"] or "").strip(),
                armazenamento_tipo=(reg["armazenamento_tipo"] or "").strip(),
                armazenamento_capacidade=(reg["armazenamento_capacidade"] or "").strip(),
                armazenamento_interface=(reg["armazenamento_interface"] or "").strip(),
                teclado=normalizar_sim_nao(reg["teclado"]),
                mouse=normalizar_sim_nao(reg["mouse"]),
            )
            db.session.add(m)
            db.session.flush()  # garante que m.id já existe para o histórico abaixo
            total_maquinas += 1

            if m.historico_manutencao:
                db.session.add(HistoricoManutencao(
                    maquina_id=m.id,
                    data=(m.data_compra or datetime.now().strftime("%Y-%m-%d")),
                    descricao=m.historico_manutencao,
                    usuario_nome="Migração do sistema antigo",
                ))

            for tipo, valor in [
                ("posto_graduacao", m.posto_graduacao), ("corpo_quadro", m.corpo_quadro),
                ("setor", m.departamento_setor), ("sistema_operacional", m.sistema_operacional),
                ("processador_fabricante", m.processador_fabricante),
            ]:
                adicionar_opcao(cache_opcoes, tipo, valor)

        db.session.commit()
        resumo["maquinas"] = total_maquinas
        print(f">> {total_maquinas} máquinas importadas.")

        # ---------------- SWITCH ----------------
        cols = ["id", "chave", "rack_departamento", "lacres", "data_registro"]
        tuplas = extrair_tuplas(sql_texto, "switch")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            chave_switch = (reg["chave"] or "").strip()
            rack = (reg["rack_departamento"] or "").strip()
            # Vários switches podem ter a MESMA chave (ex.: chave 03 em 5 racks
            # diferentes) — por isso compara chave + rack, nunca só a chave.
            if not substituir and Switch.query.filter_by(chave=chave_switch, rack_departamento=rack).first():
                continue
            db.session.add(Switch(
                chave=chave_switch,
                rack_departamento=(reg["rack_departamento"] or "").strip(),
                lacres=(reg["lacres"] or "").strip(),
            ))
            adicionar_opcao(cache_opcoes, "setor", reg["rack_departamento"])
            total += 1
        db.session.commit()
        resumo["switches"] = total
        print(f">> {total} switches importados.")

        # ---------------- IMPRESSORAS ----------------
        cols = ["id", "local_printer", "ip", "modelo", "serie", "toner", "mac"]
        tuplas = extrair_tuplas(sql_texto, "impressoras")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            ip_impressora = (reg["ip"] or "").strip()
            if not substituir and ip_impressora and Impressora.query.filter_by(ip=ip_impressora).first():
                continue
            db.session.add(Impressora(
                local_printer=(reg["local_printer"] or "").strip(),
                ip=ip_impressora,
                modelo=(reg["modelo"] or "").strip(),
                serie=(reg["serie"] or "").strip(),
                toner=(reg["toner"] or "").strip(),
                mac=(reg["mac"] or "").strip(),
            ))
            adicionar_opcao(cache_opcoes, "setor", reg["local_printer"])
            total += 1
        db.session.commit()
        resumo["impressoras"] = total
        print(f">> {total} impressoras importadas.")

        # ---------------- CONTATOS TI ----------------
        cols = ["id", "empresa", "telefone", "email", "obs"]
        tuplas = extrair_tuplas(sql_texto, "contatos_ti")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            empresa = (reg["empresa"] or "").strip()
            if not substituir and empresa and ContatoTI.query.filter_by(
                    empresa=empresa, telefone=(reg["telefone"] or "").strip()).first():
                continue
            db.session.add(ContatoTI(
                empresa=empresa,
                telefone=(reg["telefone"] or "").strip(),
                email=(reg["email"] or "").strip(),
                obs=(reg["obs"] or "").strip(),
            ))
            total += 1
        db.session.commit()
        print(f">> {total} contatos de TI importados.")

        # ---------------- TELEFONIA ----------------
        cols = ["id", "modelo", "ramal", "ip", "local", "data_criacao"]
        tuplas = extrair_tuplas(sql_texto, "telefonia")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            ramal = (reg["ramal"] or "").strip()
            if not substituir and ramal and Telefone.query.filter_by(
                    ramal=ramal, ip=(reg["ip"] or "").strip()).first():
                continue
            db.session.add(Telefone(
                modelo=(reg["modelo"] or "").strip(),
                ramal=ramal,
                ip=(reg["ip"] or "").strip(),
                local=(reg["local"] or "").strip(),
            ))
            total += 1
        db.session.commit()
        resumo["telefones"] = total
        print(f">> {total} aparelhos de telefonia importados.")

        # ---------------- CONTATOS TELEFONIA ----------------
        cols = ["id", "servico_empresa", "numero", "contato_tecnico", "email_suporte",
                "observacoes", "data_atualizacao"]
        tuplas = extrair_tuplas(sql_texto, "contatos_telefonia")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            servico = (reg["servico_empresa"] or "").strip()
            numero = (reg["numero"] or "").strip()
            if not substituir and servico and ContatoTelefonia.query.filter_by(servico_empresa=servico, numero=numero).first():
                continue
            db.session.add(ContatoTelefonia(
                servico_empresa=servico,
                numero=numero,
                contato_tecnico=(reg["contato_tecnico"] or "").strip(),
                email_suporte=(reg["email_suporte"] or "").strip(),
                observacoes=(reg["observacoes"] or "").strip(),
            ))
            total += 1
        db.session.commit()
        print(f">> {total} contatos de telefonia importados.")

        # ---------------- USUÁRIOS ----------------
        cols = ["id", "nip", "senha", "ultimo_acesso", "nome", "posto_grad", "setor",
                "email", "status", "data_cadastro"]
        tuplas = extrair_tuplas(sql_texto, "usuarios")
        total = 0
        for t in tuplas:
            if len(t) != len(cols):
                continue
            reg = dict(zip(cols, t))
            nip = normalizar_nip(reg["nip"])
            if Usuario.query.filter_by(nip=nip).first():
                continue  # já existe (ex: admin ou já migrado antes)
            u = Usuario(
                nip=nip,
                nome_completo=(reg["nome"] or "SEM NOME").strip(),
                posto_graduacao=(reg["posto_grad"] or "").strip(),
                is_admin=False,
            )
            # a senha original estava em texto puro no banco antigo — aplicamos hash agora
            u.set_senha((reg["senha"] or "mudar123").strip())
            db.session.add(u)
            total += 1
        db.session.commit()
        print(f">> {total} usuários importados (senhas convertidas para hash seguro).")

        print("\n>> Migração concluída com sucesso!")
    return resumo


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 migrar_dados.py caminho/para/sisparque.sql")
        sys.exit(1)
    from app import app  # import local, só quando rodado como script standalone
    migrar(app, sys.argv[1])
