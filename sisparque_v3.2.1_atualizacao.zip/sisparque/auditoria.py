"""Trilha de auditoria do SISPARQUE.

Registra SOZINHO, sem precisar mexer em cada tela:
  - quem criou, alterou ou excluiu máquina, impressora, telefone, switch, histórico,
    usuário, opção de lista, coluna, item de menu, módulo e configurações;
  - em cada alteração, o campo que mudou e o valor de antes e de depois;
  - senha trocada (sem nunca gravar a senha).

Os eventos de login (entrou, saiu, senha errada, bloqueio, sessão encerrada) são
registrados pelo app com registrar_evento().

Tudo vai para o arquivo auditoria.db (separado do banco principal). O registro só
é gravado DEPOIS que a alteração foi salva de verdade (commit): se der erro e nada
for salvo, nada entra na auditoria.
"""
import json
from datetime import datetime

from flask import g, has_app_context, has_request_context, request
from flask_login import current_user
from sqlalchemy import event
from sqlalchemy.orm import Session
from sqlalchemy import inspect as sa_inspect

from models import (db, LogAuditoria, Maquina, Impressora, Telefone, Switch, HistoricoManutencao, MaquinaForaRede,
                    Usuario, OpcaoConfig, CampoExtra, ItemMenuConfig, ModuloPersonalizado,
                    RegistroModulo, ConfiguracaoSistema, CAMPOS_FIXOS_POR_TIPO)


def _rotulos(tipo):
    return {chave: rotulo for chave, rotulo in CAMPOS_FIXOS_POR_TIPO.get(tipo, [])}


# modelo -> (nome que aparece, função de descrição, rótulos dos campos)
MONITORADOS = {
    Maquina: ("Máquina", lambda o: f"{o.nome_completo or 'sem nome'} ({(o.ip or '').strip() or 'sem IP'})", _rotulos("maquina")),
    Impressora: ("Impressora", lambda o: f"{o.modelo or 'Impressora'} — {o.local_printer or '-'} ({(o.ip or '').strip() or 'sem IP'})", _rotulos("impressora")),
    Telefone: ("Telefone", lambda o: f"Ramal {o.ramal or '-'} — {o.local or '-'} ({(o.ip or '').strip() or 'sem IP'})", _rotulos("telefone")),
    MaquinaForaRede: ("Máquina fora da rede", lambda o: f"{o.quantidade or '1'}x {o.equipamento or 'máquina'} — {o.responsavel or '-'} / {o.setor or '-'}", _rotulos("fora_rede")),
    Switch: ("Switch", lambda o: f"{o.chave or 'Switch'} — {o.rack_departamento or '-'}", _rotulos("switch")),
    HistoricoManutencao: ("Histórico de manutenção", lambda o: f"Máquina ID {o.maquina_id}: {(o.descricao or '')[:80]}", {"data": "Data", "descricao": "Descrição"}),
    Usuario: ("Usuário", lambda o: f"{o.nome_completo or ''} (NIP/CPF {o.nip})",
              {"nome_completo": "Nome", "posto_graduacao": "Posto/Grad", "is_admin": "Administrador", "is_geral": "Administrador geral",
               "nome_guerra": "Nome de guerra", "pode_mudar_tema": "Pode mudar tema", "nip": "NIP/CPF"}),
    OpcaoConfig: ("Opção de lista", lambda o: f"{o.tipo}: {o.valor}", {"valor": "Valor", "cor": "Cor"}),
    CampoExtra: ("Coluna personalizada", lambda o: f"{o.tipo}: {o.nome}", {"nome": "Nome"}),
    ItemMenuConfig: ("Item do menu", lambda o: f"Menu: {o.chave}", {"nome": "Nome", "visivel": "Visível", "icone": "Ícone"}),
    ModuloPersonalizado: ("Módulo do menu", lambda o: o.nome or o.slug, {"nome": "Nome", "icone": "Ícone"}),
    RegistroModulo: ("Registro de módulo", lambda o: f"Módulo ID {o.modulo_id}", {}),
    ConfiguracaoSistema: ("Configurações do sistema", lambda o: "Configurações do sistema", {}),
}

# campos que nunca entram (barulho ou sigilo)
IGNORAR = {"id", "criado_em", "senha_hash", "falhas_login", "bloqueado_ate", "posicao", "ordem", "pode_editar_colunas"}


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Sim" if v else "Não"
    if isinstance(v, datetime):
        return v.strftime("%d/%m/%Y %H:%M")
    s = str(v)
    return s if len(s) <= 300 else s[:297] + "..."


def _quem():
    if has_request_context():
        try:
            if current_user.is_authenticated:
                return current_user.id, current_user.display_name
        except Exception:
            pass
    return None, "Sistema"


def _ip():
    if has_request_context():
        return (request.headers.get("X-Forwarded-For", "").split(",")[0].strip() or request.remote_addr or "")[:45]
    return ""


def _diff_extras(antes, depois):
    """O campo 'extras' é JSON (colunas personalizadas): mostra campo a campo."""
    try:
        a = json.loads(antes or "{}") or {}
        d = json.loads(depois or "{}") or {}
    except (ValueError, TypeError):
        return [{"campo": "Colunas personalizadas", "antes": _fmt(antes), "depois": _fmt(depois)}]
    out = []
    for k in sorted(set(a) | set(d)):
        if (a.get(k) or "") != (d.get(k) or ""):
            out.append({"campo": f"Coluna '{k}'", "antes": _fmt(a.get(k)), "depois": _fmt(d.get(k))})
    return out


def _alteracoes(obj, rotulos):
    mudancas, senha_trocada = [], False
    for attr in sa_inspect(obj).mapper.column_attrs:
        nome = attr.key
        hist = sa_inspect(obj).attrs[nome].history
        if not hist.has_changes():
            continue
        if nome == "senha_hash":
            senha_trocada = True
            continue
        if nome in IGNORAR:
            continue
        antes = hist.deleted[0] if hist.deleted else None
        depois = hist.added[0] if hist.added else None
        if _fmt(antes) == _fmt(depois):
            continue
        if nome == "extras":
            mudancas.extend(_diff_extras(antes, depois))
        else:
            mudancas.append({"campo": rotulos.get(nome, nome.replace("_", " ").capitalize()),
                             "antes": _fmt(antes), "depois": _fmt(depois)})
    return mudancas, senha_trocada


def _linha(acao, tipo, objeto_id, descricao, detalhes=None, usuario=None):
    uid, unome = usuario if usuario else _quem()
    return {
        "quando": datetime.now(), "usuario_id": uid, "usuario_nome": (unome or "")[:150], "acao": acao,
        "tipo": tipo, "objeto_id": objeto_id, "descricao": (descricao or "")[:300],
        "detalhes": json.dumps(detalhes, ensure_ascii=False) if isinstance(detalhes, (list, dict)) else detalhes,
        "ip_origem": _ip(),
    }


def _gravar(linhas):
    if not linhas:
        return
    try:
        with db.engines["auditoria"].begin() as conn:
            conn.execute(LogAuditoria.__table__.insert(), linhas)
    except Exception as e:  # a auditoria nunca pode derrubar o sistema
        print(f">> AVISO: não consegui gravar a auditoria: {e}")


def _desligada():
    # Só registra o que é feito por alguém usando o sistema (há uma requisição em andamento).
    # Inicialização, instalação e scripts de manutenção não poluem a trilha.
    if not has_request_context():
        return True
    return getattr(g, "sem_auditoria", False)


def _depois_do_flush(session, flush_context):
    if _desligada():
        return
    pendentes = session.info.setdefault("auditoria_pendente", [])
    for obj in list(session.new):
        cfg = MONITORADOS.get(type(obj))
        if cfg:
            tipo, desc, _ = cfg
            pendentes.append(_linha("Criou", tipo, getattr(obj, "id", None), desc(obj)))
    for obj in list(session.dirty):
        cfg = MONITORADOS.get(type(obj))
        if not cfg or not session.is_modified(obj, include_collections=False):
            continue
        tipo, desc, rotulos = cfg
        mudancas, senha = _alteracoes(obj, rotulos)
        if senha:
            pendentes.append(_linha("Trocou senha", tipo, obj.id, desc(obj), "A senha foi alterada (o valor nunca é registrado)."))
        if mudancas:
            pendentes.append(_linha("Alterou", tipo, obj.id, desc(obj), mudancas))
    for obj in list(session.deleted):
        cfg = MONITORADOS.get(type(obj))
        if cfg:
            tipo, desc, _ = cfg
            pendentes.append(_linha("Excluiu", tipo, getattr(obj, "id", None), desc(obj)))


def _depois_do_commit(session):
    linhas = session.info.pop("auditoria_pendente", [])
    _gravar(linhas)


def _depois_do_rollback(session):
    session.info.pop("auditoria_pendente", None)


def iniciar_auditoria():
    event.listen(Session, "after_flush", _depois_do_flush)
    event.listen(Session, "after_commit", _depois_do_commit)
    event.listen(Session, "after_soft_rollback", lambda s, prev: _depois_do_rollback(s))


def registrar_evento(acao, tipo="Acesso", descricao="", detalhes=None, objeto_id=None, usuario=None):
    """Grava na hora um evento que não vem de alteração no banco (login, saída, bloqueio...)."""
    _gravar([_linha(acao, tipo, objeto_id, descricao, detalhes, usuario)])
