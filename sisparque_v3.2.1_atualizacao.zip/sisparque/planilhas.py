# -*- coding: utf-8 -*-
"""
SISPARQUE - Gerador de planilhas .xlsx (Excel) e .ods (LibreOffice Calc)
SEM dependencias externas: usa so a biblioteca padrao do Python (zipfile + XML).
Por isso NAO precisa instalar nada no servidor - a atualizacao continua sendo
so copiar a pasta do sisparque por cima da que esta em /opt.

Uso:
    from planilhas import Planilha, C
    p = Planilha("Recebimento")
    p.largura([5, 30, 18, 10, 10])       # largura das colunas (em caracteres)
    p.linha([C("Material", "cab"), C("Qtd", "cab")])
    p.linha([C("Teclado", "texto"), C(10, "num")])
    dados_xlsx = p.xlsx()                 # bytes do arquivo .xlsx
    dados_ods  = p.ods()                  # bytes do arquivo .ods

Estilos de celula disponiveis (parametro de C):
    "titulo" - negrito grande, sem borda           (titulo do documento)
    "rotulo" - negrito, sem borda                   (ex.: "Origem:")
    "info"   - normal, sem borda                    (valor ao lado do rotulo)
    "secao"  - negrito, fundo claro, com borda      (ex.: "ENTREGAS")
    "cab"    - negrito, texto branco, fundo azul-marinho, centralizado, com borda
    "texto"  - normal, com borda                    (celula de dado)
    "num"    - normal, alinhado a direita, com borda (numeros)
"""
import datetime
import zipfile
from io import BytesIO
from xml.sax.saxutils import escape

# Cor do cabeçalho das tabelas — acompanha a Aparência do sistema
COR_CAB = "3E4B2C"   # verde musgo (padrão)


def definir_tema_planilha(modo_visual):
    global COR_CAB
    COR_CAB = "0F1F45" if modo_visual == "marinho" else "3E4B2C"


# --------------------------------------------------------------------------
class C:
    """Uma celula. v = valor; estilo = um dos nomes acima; colspan = quantas
    colunas essa celula ocupa (para titulo/secao que atravessam a tabela)."""
    __slots__ = ("v", "estilo", "colspan")

    def __init__(self, v="", estilo="texto", colspan=1):
        self.v = v
        self.estilo = estilo
        self.colspan = max(1, int(colspan))

    def eh_numero(self):
        return self.estilo == "num" and _eh_num(self.v)


def _eh_num(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return True
    try:
        float(str(v).replace(",", "."))
        return True
    except (TypeError, ValueError):
        return False


def _num(v):
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip().replace(",", ".")
    f = float(s)
    return int(f) if f.is_integer() else f


# --------------------------------------------------------------------------
class Planilha:
    def __init__(self, nome="Planilha1"):
        self.nome = (nome or "Planilha1")[:31]
        self._linhas = []      # lista de listas de C
        self._larguras = []    # largura por coluna (em caracteres)
        # Impressão (opcional): linha do cabeçalho da tabela (repete em toda página,
        # fica congelada na tela e ganha filtro), papel deitado e rodapé com página.
        self.linha_cabecalho = None   # índice 0-based da linha de cabeçalho
        self.paisagem = True
        self.rodape = "SISPARQUE"

    def marcar_cabecalho(self):
        """Chame logo ANTES de adicionar a linha de cabeçalho da tabela."""
        self.linha_cabecalho = len(self._linhas)

    def largura(self, larguras):
        self._larguras = list(larguras)

    def linha(self, celulas):
        self._linhas.append(list(celulas))

    def linha_vazia(self):
        self._linhas.append([])

    # ---- larguras: usa as informadas ou calcula pelo conteudo --------------
    def _larguras_finais(self):
        ncols = 0
        for ln in self._linhas:
            c = sum(cel.colspan for cel in ln)
            ncols = max(ncols, c)
        larg = [10] * ncols
        if self._larguras:
            for i, w in enumerate(self._larguras[:ncols]):
                larg[i] = w
            return larg
        # auto: maior texto de cada coluna (ignora celulas com colspan>1)
        maxv = [8] * ncols
        for ln in self._linhas:
            col = 0
            for cel in ln:
                if cel.colspan == 1 and col < ncols:
                    maxv[col] = max(maxv[col], len(str(cel.v)) + 2)
                col += cel.colspan
        return [min(60, m) for m in maxv]

    def _fim_tabela(self):
        """Última linha (0-based) da tabela que começa no cabeçalho marcado."""
        i = self.linha_cabecalho
        while i + 1 < len(self._linhas) and self._linhas[i + 1] and \
                not any(c.colspan > 1 for c in self._linhas[i + 1]):
            i += 1
        return i

    # ======================================================================
    # XLSX  (Office Open XML)
    # ======================================================================
    def xlsx(self):
        larg = self._larguras_finais()
        estilos, mapa = _xlsx_estilos()

        cols_xml = "".join(
            '<col min="%d" max="%d" width="%.2f" customWidth="1"/>' % (i + 1, i + 1, w + 0.7)
            for i, w in enumerate(larg)
        )

        merges = []
        linhas_xml = []
        for r, ln in enumerate(self._linhas, start=1):
            celulas_xml = []
            col = 0
            for cel in ln:
                ref = "%s%d" % (_col_letra(col), r)
                s = mapa[cel.estilo]
                if cel.eh_numero():
                    celulas_xml.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, s, _num(cel.v)))
                else:
                    txt = escape(str(cel.v))
                    celulas_xml.append(
                        '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                        % (ref, s, txt))
                if cel.colspan > 1:
                    merges.append("%s:%s" % (ref, "%s%d" % (_col_letra(col + cel.colspan - 1), r)))
                    # celulas cobertas pelo merge (vazias, mesmo estilo p/ a borda fechar)
                    for k in range(1, cel.colspan):
                        rc = "%s%d" % (_col_letra(col + k), r)
                        celulas_xml.append('<c r="%s" s="%d"/>' % (rc, s))
                col += cel.colspan
            linhas_xml.append('<row r="%d">%s</row>' % (r, "".join(celulas_xml)))

        merge_xml = ""
        if merges:
            merge_xml = '<mergeCells count="%d">%s</mergeCells>' % (
                len(merges), "".join('<mergeCell ref="%s"/>' % m for m in merges))

        ncols = len(larg)
        ultima = _col_letra(max(ncols - 1, 0))
        views = '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'
        autofiltro = ""
        defined = ""
        if self.linha_cabecalho is not None:
            lc = self.linha_cabecalho + 1           # 1-based
            fim = self._fim_tabela() + 1
            views = ('<sheetViews><sheetView workbookViewId="0">'
                     '<pane ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/>'
                     '<selection pane="bottomLeft" activeCell="A%d" sqref="A%d"/>'
                     '</sheetView></sheetViews>') % (lc, lc + 1, lc + 1, lc + 1)
            autofiltro = '<autoFilter ref="A%d:%s%d"/>' % (lc, ultima, max(fim, lc))
            nome_aba = self.nome.replace("'", "''")
            defined = ('<definedNames>'
                       '<definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">\'%s\'!$A$%d:$%s$%d</definedName>'
                       '<definedName name="_xlnm.Print_Titles" localSheetId="0">\'%s\'!$%d:$%d</definedName>'
                       '</definedNames>') % (escape(nome_aba), lc, ultima, max(fim, lc), escape(nome_aba), lc, lc)
        orient = "landscape" if self.paisagem else "portrait"
        sheet = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
            '%s'
            '<cols>%s</cols>'
            '<sheetData>%s</sheetData>'
            '%s%s'
            '<printOptions horizontalCentered="1"/>'
            '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.6" header="0.2" footer="0.25"/>'
            '<pageSetup paperSize="9" orientation="%s" fitToWidth="1" fitToHeight="0"/>'
            '<headerFooter><oddFooter>&amp;L&amp;8%s&amp;R&amp;8Página &amp;P de &amp;N</oddFooter></headerFooter>'
            '</worksheet>'
        ) % (views, cols_xml, "".join(linhas_xml), autofiltro, merge_xml, orient, escape(self.rodape))

        content_types = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            '</Types>'
        )
        rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>'
        )
        workbook = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets><sheet name="%s" sheetId="1" r:id="rId1"/></sheets>'
            '%s'
            '</workbook>'
        ) % (escape(self.nome), defined)
        wb_rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '</Relationships>'
        )

        buf = BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", content_types)
            z.writestr("_rels/.rels", rels)
            z.writestr("xl/workbook.xml", workbook)
            z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
            z.writestr("xl/styles.xml", estilos)
            z.writestr("xl/worksheets/sheet1.xml", sheet)
        return buf.getvalue()

    # ======================================================================
    # ODS  (OpenDocument Spreadsheet - LibreOffice Calc)
    # ======================================================================
    def ods(self):
        larg = self._larguras_finais()

        # estilos de coluna (largura) + estilos de celula
        col_styles = "".join(
            '<style:style style:name="co%d" style:family="table-column">'
            '<style:table-column-properties style:column-width="%.2fcm"/></style:style>'
            % (i + 1, (w * 0.20) + 0.4) for i, w in enumerate(larg)
        )
        cell_styles = _ods_estilos_celula()

        linhas_xml = []
        for idx_ln, ln in enumerate(self._linhas):
            if not ln:
                linhas_xml.append('<table:table-row><table:table-cell/></table:table-row>')
                continue
            celulas_xml = []
            for cel in ln:
                st = ' table:style-name="ce_%s"' % cel.estilo
                span = ''
                if cel.colspan > 1:
                    span = ' table:number-columns-spanned="%d"' % cel.colspan
                if cel.eh_numero():
                    celulas_xml.append(
                        '<table:table-cell%s%s office:value-type="float" office:value="%s">'
                        '<text:p>%s</text:p></table:table-cell>'
                        % (st, span, _num(cel.v), escape(str(cel.v))))
                else:
                    celulas_xml.append(
                        '<table:table-cell%s%s office:value-type="string"><text:p>%s</text:p></table:table-cell>'
                        % (st, span, escape(str(cel.v))))
                for _ in range(cel.colspan - 1):
                    celulas_xml.append('<table:covered-table-cell/>')
            linha_xml = '<table:table-row>%s</table:table-row>' % "".join(celulas_xml)
            if idx_ln == self.linha_cabecalho:
                # repete esta linha no topo de cada página impressa
                linha_xml = '<table:table-header-rows>%s</table:table-header-rows>' % linha_xml
            linhas_xml.append(linha_xml)

        ncols = len(larg)
        nome_esc = escape(self.nome)
        faixa_filtro = ""
        if self.linha_cabecalho is not None:
            lc = self.linha_cabecalho + 1
            fim = self._fim_tabela() + 1
            faixa_filtro = (
                '<table:database-ranges><table:database-range table:name="__Anonymous_Sheet_DB__0" '
                'table:target-range-address="\'%s\'.A%d:\'%s\'.%s%d" table:display-filter-buttons="true"/>'
                '</table:database-ranges>') % (nome_esc, lc, nome_esc, _col_letra(ncols - 1), max(fim, lc))

        cols_decl = "".join(
            '<table:table-column table:style-name="co%d"/>' % (i + 1) for i in range(len(larg))
        )

        content = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<office:document-content '
            'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
            'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
            'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
            'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
            'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" '
            'office:version="1.2">'
            '<office:automatic-styles>%s%s'
            '<style:style style:name="ta1" style:family="table" style:master-page-name="Impressao">'
            '<style:table-properties table:display="true"/></style:style>'
            '</office:automatic-styles>'
            '<office:body><office:spreadsheet>'
            '<table:table table:name="%s" table:style-name="ta1">%s%s</table:table>'
            '%s'
            '</office:spreadsheet></office:body></office:document-content>'
        ) % (col_styles, cell_styles, nome_esc, cols_decl, "".join(linhas_xml), faixa_filtro)

        # Página: A4, deitada (ou em pé), ajustada à LARGURA da folha, rodapé com nº da página
        larg_pg, alt_pg = ("29.7cm", "21cm") if self.paisagem else ("21cm", "29.7cm")
        orient = "landscape" if self.paisagem else "portrait"
        styles_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<office:document-styles '
            'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
            'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
            'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
            'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" '
            'xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0" '
            'office:version="1.2">'
            '<office:automatic-styles>'
            '<style:page-layout style:name="pm1">'
            '<style:page-layout-properties fo:page-width="%s" fo:page-height="%s" '
            'style:print-orientation="%s" fo:margin-top="1cm" fo:margin-bottom="1cm" '
            'fo:margin-left="1cm" fo:margin-right="1cm" style:table-centering="horizontal" '
            'loext:scale-to-X="1" loext:scale-to-Y="0" style:print="objects charts drawings"/>'
            '<style:footer-style><style:header-footer-properties fo:min-height="0.6cm" fo:margin-top="0.2cm"/></style:footer-style>'
            '</style:page-layout>'
            '</office:automatic-styles>'
            '<office:master-styles>'
            '<style:master-page style:name="Impressao" style:page-layout-name="pm1">'
            '<style:header style:display="false"/>'
            '<style:footer>'
            '<style:region-left><text:p>%s</text:p></style:region-left>'
            '<style:region-right><text:p>Página <text:page-number>1</text:page-number> de <text:page-count>1</text:page-count></text:p></style:region-right>'
            '</style:footer>'
            '</style:master-page>'
            '</office:master-styles>'
            '</office:document-styles>'
        ) % (larg_pg, alt_pg, orient, escape(self.rodape))

        # Congela o cabeçalho da tabela na tela (rola os dados, o cabeçalho fica parado)
        settings_xml = None
        if self.linha_cabecalho is not None:
            lc = self.linha_cabecalho + 1
            settings_xml = (
                '<?xml version="1.0" encoding="UTF-8"?>'
                '<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
                'xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" office:version="1.2">'
                '<office:settings><config:config-item-set config:name="ooo:view-settings">'
                '<config:config-item-map-indexed config:name="Views"><config:config-item-map-entry>'
                '<config:config-item config:name="ViewId" config:type="string">view1</config:config-item>'
                '<config:config-item-map-named config:name="Tables">'
                '<config:config-item-map-entry config:name="%s">'
                '<config:config-item config:name="VerticalSplitMode" config:type="short">2</config:config-item>'
                '<config:config-item config:name="VerticalSplitPosition" config:type="int">%d</config:config-item>'
                '<config:config-item config:name="ActiveSplitRange" config:type="short">2</config:config-item>'
                '<config:config-item config:name="PositionTop" config:type="int">0</config:config-item>'
                '<config:config-item config:name="PositionBottom" config:type="int">%d</config:config-item>'
                '</config:config-item-map-entry></config:config-item-map-named>'
                '</config:config-item-map-entry></config:config-item-map-indexed>'
                '</config:config-item-set></office:settings></office:document-settings>'
            ) % (nome_esc, lc, lc)

        manifest = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">'
            '<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>'
            '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
            '<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>'
            + ('<manifest:file-entry manifest:full-path="settings.xml" manifest:media-type="text/xml"/>' if settings_xml else '')
            + '</manifest:manifest>'
        )

        buf = BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            # mimetype PRECISA ser o 1o arquivo e sem compressao
            zi = zipfile.ZipInfo("mimetype")
            zi.compress_type = zipfile.ZIP_STORED
            z.writestr(zi, "application/vnd.oasis.opendocument.spreadsheet")
            z.writestr("META-INF/manifest.xml", manifest)
            z.writestr("content.xml", content)
            z.writestr("styles.xml", styles_xml)
            if settings_xml:
                z.writestr("settings.xml", settings_xml)
        return buf.getvalue()


# --------------------------------------------------------------------------
# helpers XLSX
def _col_letra(idx):
    """0 -> A, 25 -> Z, 26 -> AA ..."""
    s = ""
    idx += 1
    while idx:
        idx, r = divmod(idx - 1, 26)
        s = chr(65 + r) + s
    return s


def _xlsx_estilos():
    """styles.xml: fontes, preenchimentos, bordas e cellXfs.
    Retorna (xml, mapa_nome_estilo->indice_cellXf)."""
    borda = ('<border><left style="thin"><color rgb="FFB0B0B0"/></left>'
             '<right style="thin"><color rgb="FFB0B0B0"/></right>'
             '<top style="thin"><color rgb="FFB0B0B0"/></top>'
             '<bottom style="thin"><color rgb="FFB0B0B0"/></bottom></border>')
    borders = ('<borders count="2">'
               '<border><left/><right/><top/><bottom/><diagonal/></border>'  # 0 = sem borda
               + borda +                                                     # 1 = com borda
               '</borders>')

    fonts = ('<fonts count="4">'
             '<font><sz val="11"/><name val="Calibri"/></font>'                       # 0 normal
             '<font><b/><sz val="11"/><name val="Calibri"/></font>'                   # 1 negrito
             '<font><b/><sz val="13"/><name val="Calibri"/></font>'                   # 2 titulo
             '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'  # 3 branco
             '</fonts>')

    fills = ('<fills count="4">'
             '<fill><patternFill patternType="none"/></fill>'                          # 0
             '<fill><patternFill patternType="gray125"/></fill>'                       # 1 (reservado)
             '<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/></patternFill></fill>'  # 2 azul cab
             '<fill><patternFill patternType="solid"><fgColor rgb="FFE8EEF5"/></patternFill></fill>'  # 3 secao claro
             '</fills>') % COR_CAB

    # cellXfs: cada estilo nomeado -> (font, fill, border, align)
    # align: 0 nenhum, 1 centro, 2 direita
    defs = [
        # nome,     font, fill, border, align
        ("titulo",  2,    0,    0,      0),
        ("rotulo",  1,    0,    0,      0),
        ("info",    0,    0,    0,      0),
        ("secao",   1,    3,    1,      0),
        ("cab",     3,    2,    1,      1),
        ("texto",   0,    0,    1,      3),
        ("num",     0,    0,    1,      2),
    ]
    xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>']  # 0 default
    mapa = {}
    for nome, f, fi, b, al in defs:
        align = ''
        if al == 1:
            align = '<alignment horizontal="center" vertical="center" wrapText="1"/>'
        elif al == 2:
            align = '<alignment horizontal="right"/>'
        elif al == 3:
            align = '<alignment vertical="center" wrapText="1"/>'
        apply_al = ' applyAlignment="1"' if align else ''
        xf = ('<xf numFmtId="0" fontId="%d" fillId="%d" borderId="%d" xfId="0" '
              'applyFont="1" applyFill="1" applyBorder="1"%s>%s</xf>'
              % (f, fi, b, apply_al, align))
        mapa[nome] = len(xfs)
        xfs.append(xf)

    styles = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '%s%s%s'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="%d">%s</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '</styleSheet>'
    ) % (fonts, fills, borders, len(xfs), "".join(xfs))
    return styles, mapa


# helpers ODS
def _ods_estilos_celula():
    borda = 'fo:border="0.5pt solid #b0b0b0"'
    def cel(nome, props_cell="", props_text="", props_par=""):
        xml = '<style:style style:name="ce_%s" style:family="table-cell">' % nome
        if props_cell:
            xml += '<style:table-cell-properties %s/>' % props_cell
        if props_par:
            xml += '<style:paragraph-properties %s/>' % props_par
        if props_text:
            xml += '<style:text-properties %s/>' % props_text
        xml += '</style:style>'
        return xml

    return "".join([
        cel("titulo", "", 'fo:font-weight="bold" fo:font-size="13pt"'),
        cel("rotulo", "", 'fo:font-weight="bold"'),
        cel("info", "", ""),
        cel("secao", 'fo:background-color="#e8eef5" %s' % borda, 'fo:font-weight="bold"'),
        cel("cab", 'fo:background-color="#%s" %s' % (COR_CAB, borda),
            'fo:font-weight="bold" fo:color="#ffffff" fo:font-size="11pt"', 'fo:text-align="center"'),
        cel("texto", borda + ' style:vertical-align="middle" fo:wrap-option="wrap" fo:padding="0.08cm"', 'fo:font-size="11pt"'),
        cel("num", borda + ' style:vertical-align="middle" fo:padding="0.08cm"', 'fo:font-size="11pt"', 'fo:text-align="end"'),
    ])


# --------------------------------------------------------------------------
def planilha_de_tabela(titulo, dados, contatos=None):
    """Monta uma Planilha pronta para imprimir a partir de uma tabela simples:
    dados = [cabecalho, linha1, linha2, ...]; contatos = tabela opcional
    (mesmo formato) que entra abaixo, como seção separada."""
    ncols = len(dados[0])
    p = Planilha(titulo[:31] if titulo else "Inventario")
    p.paisagem = ncols > 5
    p.rodape = "SISPARQUE — " + titulo
    p.linha([C("SISPARQUE — " + titulo, "titulo", colspan=ncols)])
    p.linha([C("Gerado em: " + datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "info", colspan=ncols)])
    p.linha_vazia()
    p.marcar_cabecalho()
    p.linha([C(h, "cab") for h in dados[0]])
    for linha in dados[1:]:
        cels = []
        for i, v in enumerate(linha):
            v = "" if v is None or v == "-" else v
            cels.append(C(v, "num" if i == 0 and _eh_num(v) else "texto"))
        p.linha(cels)
    if contatos and len(contatos) > 1:
        p.linha_vazia()
        p.linha([C("Contatos / Fornecedores", "secao", colspan=ncols)])
        p.linha([C(h, "cab") for h in contatos[0]])
        for linha in contatos[1:]:
            p.linha([C("" if v in (None, "-") else v, "texto") for v in linha])
    # larguras pelo conteúdo da tabela principal (texto longo limitado a 45)
    larg = []
    for c in range(ncols):
        maior = max(len(str(l[c])) if c < len(l) and l[c] is not None else 0 for l in dados)
        larg.append(max(6, min(45, maior + 2)))
    p.largura(larg)
    return p


# --------------------------------------------------------------------------
# PASTA COM VÁRIAS ABAS ("Exportar tudo")
# Junta várias Planilha num arquivo só (.xlsx ou .ods), uma por aba, cada aba
# com sua própria configuração de impressão (papel, cabeçalho repetido etc.).
# --------------------------------------------------------------------------
import re as _re


def _nomes_abas_unicos(planilhas):
    usados, nomes = set(), []
    for p in planilhas:
        base = _re.sub(r'[\[\]\:\*\?\/\\]', '-', p.nome or "Aba")[:31] or "Aba"
        nome, n = base, 2
        while nome.lower() in usados:
            suf = " (%d)" % n
            nome = base[:31 - len(suf)] + suf
            n += 1
        usados.add(nome.lower())
        nomes.append(nome)
    return nomes


def pasta_xlsx(planilhas):
    nomes = _nomes_abas_unicos(planilhas)
    folhas, definidos = [], []
    estilos = None
    for idx, (p, nome) in enumerate(zip(planilhas, nomes)):
        p.nome = nome
        with zipfile.ZipFile(BytesIO(p.xlsx())) as z:
            folhas.append(z.read("xl/worksheets/sheet1.xml").decode("utf-8"))
            wb = z.read("xl/workbook.xml").decode("utf-8")
            if estilos is None:
                estilos = z.read("xl/styles.xml").decode("utf-8")
        for m in _re.finditer(r'<definedName [^>]*>.*?</definedName>', wb):
            definidos.append(m.group(0).replace('localSheetId="0"', 'localSheetId="%d"' % idx))

    sheets_xml = "".join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(n), i + 1, i + 1)
                         for i, n in enumerate(nomes))
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets>%s</sheets>%s</workbook>'
    ) % (sheets_xml, ('<definedNames>%s</definedNames>' % "".join(definidos)) if definidos else "")
    wb_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                  'Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(len(folhas)))
        + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        % (len(folhas) + 1) + '</Relationships>'
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        + "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                  % (i + 1) for i in range(len(folhas)))
        + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>'
    )
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/styles.xml", estilos)
        for i, f in enumerate(folhas):
            if i:  # só a 1ª aba fica selecionada ao abrir
                f = f.replace('<sheetView workbookViewId="0"', '<sheetView tabSelected="0" workbookViewId="0"')
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), f)
    return buf.getvalue()


def pasta_ods(planilhas):
    nomes = _nomes_abas_unicos(planilhas)
    estilos_auto, tabelas, faixas = [], [], []
    page_layouts, master_pages, congelar = [], [], []
    estilos_celula_ok = False
    for idx, (p, nome) in enumerate(zip(planilhas, nomes), start=1):
        p.nome = nome
        with zipfile.ZipFile(BytesIO(p.ods())) as z:
            content = z.read("content.xml").decode("utf-8")
            styles = z.read("styles.xml").decode("utf-8")
        auto = _re.search(r'<office:automatic-styles>(.*)</office:automatic-styles>', content, _re.S).group(1)
        # renomeia os estilos desta aba para não colidir com as outras
        auto = _re.sub(r'style:name="co(\d+)"', r'style:name="s%dco\1"' % idx, auto)
        auto = auto.replace('style:name="ta1"', 'style:name="ta%d"' % idx)
        auto = auto.replace('style:master-page-name="Impressao"', 'style:master-page-name="Impressao%d"' % idx)
        celulas = "".join(_re.findall(r'<style:style style:name="ce_.*?</style:style>', auto, _re.S))
        auto = _re.sub(r'<style:style style:name="ce_.*?</style:style>', '', auto, flags=_re.S)
        if not estilos_celula_ok:
            auto += celulas
            estilos_celula_ok = True
        estilos_auto.append(auto)
        tabela = _re.search(r'<table:table .*?</table:table>', content, _re.S).group(0)
        tabela = _re.sub(r'table:style-name="co(\d+)"', r'table:style-name="s%dco\1"' % idx, tabela)
        tabela = tabela.replace('table:style-name="ta1"', 'table:style-name="ta%d"' % idx)
        tabelas.append(tabela)
        fx = _re.search(r'<table:database-range .*?/>', content)
        if fx:
            faixas.append(fx.group(0).replace('__Anonymous_Sheet_DB__0', '__Anonymous_Sheet_DB__%d' % (idx - 1)))
        pl = _re.search(r'<style:page-layout style:name="pm1">.*?</style:page-layout>', styles, _re.S).group(0)
        page_layouts.append(pl.replace('style:name="pm1"', 'style:name="pm%d"' % idx))
        mp = _re.search(r'<style:master-page style:name="Impressao".*?</style:master-page>', styles, _re.S).group(0)
        mp = _re.sub(r' de <text:page-count>.*?</text:page-count>', '', mp)
        master_pages.append(mp.replace('style:name="Impressao"', 'style:name="Impressao%d"' % idx)
                              .replace('style:page-layout-name="pm1"', 'style:page-layout-name="pm%d"' % idx))
        if p.linha_cabecalho is not None:
            lc = p.linha_cabecalho + 1
            congelar.append(
                '<config:config-item-map-entry config:name="%s">'
                '<config:config-item config:name="VerticalSplitMode" config:type="short">2</config:config-item>'
                '<config:config-item config:name="VerticalSplitPosition" config:type="int">%d</config:config-item>'
                '<config:config-item config:name="ActiveSplitRange" config:type="short">2</config:config-item>'
                '<config:config-item config:name="PositionTop" config:type="int">0</config:config-item>'
                '<config:config-item config:name="PositionBottom" config:type="int">%d</config:config-item>'
                '</config:config-item-map-entry>' % (escape(nome), lc, lc))

    ns = ('xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
          'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
          'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
          'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
          'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" '
          'xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0" ')
    content = ('<?xml version="1.0" encoding="UTF-8"?><office:document-content %s office:version="1.2">'
               '<office:automatic-styles>%s</office:automatic-styles>'
               '<office:body><office:spreadsheet>%s%s</office:spreadsheet></office:body>'
               '</office:document-content>') % (
        ns, "".join(estilos_auto), "".join(tabelas),
        ('<table:database-ranges>%s</table:database-ranges>' % "".join(faixas)) if faixas else "")
    styles = ('<?xml version="1.0" encoding="UTF-8"?><office:document-styles %s office:version="1.2">'
              '<office:automatic-styles>%s</office:automatic-styles>'
              '<office:master-styles>%s</office:master-styles></office:document-styles>') % (
        ns, "".join(page_layouts), "".join(master_pages))
    settings = ('<?xml version="1.0" encoding="UTF-8"?>'
                '<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
                'xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" office:version="1.2">'
                '<office:settings><config:config-item-set config:name="ooo:view-settings">'
                '<config:config-item-map-indexed config:name="Views"><config:config-item-map-entry>'
                '<config:config-item config:name="ViewId" config:type="string">view1</config:config-item>'
                '<config:config-item-map-named config:name="Tables">%s</config:config-item-map-named>'
                '</config:config-item-map-entry></config:config-item-map-indexed>'
                '</config:config-item-set></office:settings></office:document-settings>') % "".join(congelar)
    manifest = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">'
        '<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>'
        '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
        '<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>'
        '<manifest:file-entry manifest:full-path="settings.xml" manifest:media-type="text/xml"/>'
        '</manifest:manifest>'
    )
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        zi = zipfile.ZipInfo("mimetype")
        zi.compress_type = zipfile.ZIP_STORED
        z.writestr(zi, "application/vnd.oasis.opendocument.spreadsheet")
        z.writestr("META-INF/manifest.xml", manifest)
        z.writestr("content.xml", content)
        z.writestr("styles.xml", styles)
        z.writestr("settings.xml", settings)
    return buf.getvalue()
