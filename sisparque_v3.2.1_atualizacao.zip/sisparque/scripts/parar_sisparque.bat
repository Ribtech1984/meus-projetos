@echo off
REM ============================================================
REM  Para o SISPARQUE quando ele estiver rodando em segundo
REM  plano (iniciado pelo iniciar_silencioso.vbs).
REM  Ajuste CAMINHO_PROJETO se necessario.
REM ============================================================
SET CAMINHO_PROJETO=C:\SISPARQUE\sisparque_py

IF NOT EXIST "%CAMINHO_PROJETO%\sisparque.pid" (
    echo O SISPARQUE nao parece estar rodando ^(arquivo sisparque.pid nao encontrado^).
    pause
    exit /b
)

set /p PID=<"%CAMINHO_PROJETO%\sisparque.pid"
echo Parando o processo SISPARQUE ^(PID %PID%^)...
taskkill /PID %PID% /F

echo.
echo SISPARQUE parado.
pause
