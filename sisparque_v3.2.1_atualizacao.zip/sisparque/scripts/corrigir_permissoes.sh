#!/usr/bin/env bash
# ============================================================
# Corrige a permissão de TODOS os arquivos do SISPARQUE pro
# usuário de serviço "sisparque" — roda isso sempre que aparecer
# "Sem permissão pra salvar arquivo" em qualquer tela do sistema.
#
# Uso:
#   sudo bash corrigir_permissoes.sh
# ============================================================
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Rode com sudo: sudo bash corrigir_permissoes.sh"
  exit 1
fi

PASTA_INSTALACAO="/opt/sisparque"
USUARIO_SERVICO="sisparque"

echo ">> Corrigindo o dono de todos os arquivos em $PASTA_INSTALACAO..."
chown -R "$USUARIO_SERVICO":"$USUARIO_SERVICO" "$PASTA_INSTALACAO"
chmod -R u+rwX "$PASTA_INSTALACAO"

# Deixa o usuário que rodou o sudo (o do WinSCP) gravar na pasta,
# para atualizar só copiando a pasta nova por cima.
USUARIO_LOGIN="${SUDO_USER:-$(logname 2>/dev/null)}"
if [ -n "$USUARIO_LOGIN" ] && [ "$USUARIO_LOGIN" != "root" ]; then
    usermod -aG "$USUARIO_SERVICO" "$USUARIO_LOGIN" 2>/dev/null || true
fi
chmod -R ug+rwX "$PASTA_INSTALACAO"
find "$PASTA_INSTALACAO" -type d -exec chmod g+s {} + 2>/dev/null || true

echo ">> Reiniciando o serviço..."
systemctl restart sisparque
sleep 2

if systemctl is-active --quiet sisparque; then
  echo ">> OK — serviço rodando normalmente."
else
  echo ">> ATENÇÃO: serviço não subiu. Rode: sudo journalctl -u sisparque -n 40 --no-pager"
fi
