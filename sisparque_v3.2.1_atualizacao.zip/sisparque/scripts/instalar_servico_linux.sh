#!/usr/bin/env bash
# ============================================================
# Instala o SISPARQUE como serviço permanente (systemd) em
# QUALQUER distribuição Linux moderna: Oracle Linux, RHEL,
# Ubuntu, Debian, Fedora, etc. Detecta sozinho o gerenciador
# de pacotes (dnf/yum/apt) e o resto do processo é idêntico
# em todas elas, porque o systemd é padrão em todas.
#
# Uso:
#   sudo bash instalar_servico_linux.sh
#
# Rode este script de DENTRO da pasta scripts/, dentro do
# projeto sisparque_py já extraído (app.py, requirements.txt, etc).
# ============================================================
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Rode este script com sudo: sudo bash instalar_servico_linux.sh"
  exit 1
fi

PASTA_PROJETO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PASTA_INSTALACAO="/opt/sisparque"
USUARIO_SERVICO="sisparque"

echo ">> Pasta do projeto detectada: $PASTA_PROJETO"

# --- 1. Detecta o gerenciador de pacotes e instala Python + sqlite3 (usado no backup) ---
if command -v dnf >/dev/null 2>&1; then
    echo ">> Sistema baseado em RHEL/Oracle Linux/Fedora (dnf) detectado."
    dnf install -y python3 python3-pip sqlite cronie   # no Oracle Linux o venv já vem no python3
    systemctl enable --now crond 2>/dev/null || true
elif command -v apt >/dev/null 2>&1; then
    echo ">> Sistema baseado em Debian/Ubuntu (apt) detectado."
    apt update -y
    apt install -y python3 python3-pip python3-venv sqlite3 cron
    systemctl enable --now cron 2>/dev/null || true
else
    echo "Gerenciador de pacotes não reconhecido. Instale Python 3.9+ manualmente e rode este script de novo."
    exit 1
fi

# --- 2. Copia o projeto para /opt/sisparque (local padrão de produção) ---
mkdir -p "$PASTA_INSTALACAO"
if [ "$PASTA_PROJETO" != "$PASTA_INSTALACAO" ]; then
    # Copia sem levar venv, bancos e backups de outro computador
    tar -C "$PASTA_PROJETO" --exclude='./venv' --exclude='*.db' --exclude='./backups' \
        --exclude='__pycache__' --exclude='*.pid' -cf - . | tar -C "$PASTA_INSTALACAO" -xf -
    echo ">> Projeto copiado para $PASTA_INSTALACAO"
else
    echo ">> Projeto já está em $PASTA_INSTALACAO"
fi

# --- 3. Cria usuário de serviço sem privilégios (mais seguro) ---
if ! id "$USUARIO_SERVICO" >/dev/null 2>&1; then
    useradd -r -s /sbin/nologin "$USUARIO_SERVICO"
    echo ">> Usuário de serviço '$USUARIO_SERVICO' criado."
fi
chown -R "$USUARIO_SERVICO":"$USUARIO_SERVICO" "$PASTA_INSTALACAO"

# --- 4. Cria o ambiente virtual e instala as dependências ---
# Cria a venv do zero (uma venv vinda de outro computador não funciona aqui)
rm -rf "$PASTA_INSTALACAO/venv"
python3 -m venv "$PASTA_INSTALACAO/venv"
"$PASTA_INSTALACAO/venv/bin/pip" install --upgrade pip -q 2>/dev/null || true

# Tenta instalar puxando da internet (funciona se tiver proxy configurado nas
# variáveis http_proxy/https_proxy, ou acesso direto). Se não conseguir (rede
# fechada, proxy não configurado, etc), cai sozinho pros pacotes que já vêm
# prontos dentro do projeto (pasta pacotes_offline/), sem precisar de nenhum
# passo manual extra.
PASTA_PACOTES_OFFLINE="$PASTA_INSTALACAO/pacotes_offline"
if "$PASTA_INSTALACAO/venv/bin/pip" install -r "$PASTA_INSTALACAO/requirements.txt" -q 2>/tmp/pip_erro.log; then
    echo ">> Dependências instaladas pela internet/proxy."
elif [ -d "$PASTA_PACOTES_OFFLINE" ] && [ "$(ls -A "$PASTA_PACOTES_OFFLINE" 2>/dev/null)" ]; then
    echo ">> Sem internet (ou proxy não configurado) — usando os pacotes que já vêm no projeto..."
    "$PASTA_INSTALACAO/venv/bin/pip" install --no-index --find-links="$PASTA_PACOTES_OFFLINE" -r "$PASTA_INSTALACAO/requirements.txt" -q
    echo ">> Dependências instaladas a partir dos pacotes offline inclusos no projeto."
else
    echo ">> ERRO: não consegui instalar as dependências (sem internet e sem a pasta pacotes_offline/)."
    cat /tmp/pip_erro.log
    exit 1
fi

chown -R "$USUARIO_SERVICO":"$USUARIO_SERVICO" "$PASTA_INSTALACAO"

# Deixa o usuário que rodou o sudo (o do WinSCP) gravar na pasta,
# para atualizar só copiando a pasta nova por cima.
USUARIO_LOGIN="${SUDO_USER:-$(logname 2>/dev/null)}"
if [ -n "$USUARIO_LOGIN" ] && [ "$USUARIO_LOGIN" != "root" ]; then
    usermod -aG "$USUARIO_SERVICO" "$USUARIO_LOGIN" 2>/dev/null || true
fi
chmod -R ug+rwX "$PASTA_INSTALACAO"
find "$PASTA_INSTALACAO" -type d -exec chmod g+s {} + 2>/dev/null || true

# --- 5. Gera uma chave secreta aleatória (se ainda não tiver uma) ---
ARQUIVO_ENV="$PASTA_INSTALACAO/.env_sisparque"
if [ ! -f "$ARQUIVO_ENV" ]; then
    CHAVE=$(python3 -c "import secrets; print(secrets.token_hex(32))")
    echo "SISPARQUE_SECRET_KEY=$CHAVE" > "$ARQUIVO_ENV"
    chown "$USUARIO_SERVICO":"$USUARIO_SERVICO" "$ARQUIVO_ENV"
    chmod 600 "$ARQUIVO_ENV"
fi

# --- 6. Cria o serviço systemd ---
cat > /etc/systemd/system/sisparque.service <<EOF
[Unit]
Description=SISPARQUE - Sistema de Inventario (Python/Flask)
After=network.target

[Service]
User=$USUARIO_SERVICO
Group=$USUARIO_SERVICO
WorkingDirectory=$PASTA_INSTALACAO
EnvironmentFile=$ARQUIVO_ENV
ExecStart=$PASTA_INSTALACAO/venv/bin/python3 $PASTA_INSTALACAO/serve_waitress.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

echo ">> Serviço systemd criado em /etc/systemd/system/sisparque.service"

# --- 7. Libera a porta no firewall (firewalld = Oracle Linux/RHEL; ufw = Ubuntu/Debian) ---
if command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
    firewall-cmd --permanent --add-port=5000/tcp
    firewall-cmd --reload
    echo ">> Porta 5000 liberada no firewalld."
elif command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
    ufw allow 5000/tcp
    echo ">> Porta 5000 liberada no ufw."
else
    echo ">> Nenhum firewall ativo detectado (ou não reconhecido) — nada a liberar."
fi

# --- 8. Corrige o contexto do SELinux, se estiver ativo (comum no Oracle Linux) ---
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
    if command -v restorecon >/dev/null 2>&1; then
        restorecon -Rv "$PASTA_INSTALACAO" >/dev/null 2>&1 || true
        echo ">> Contexto do SELinux ajustado para $PASTA_INSTALACAO."
    fi
fi

# --- 9. Ativa e inicia o serviço ---
systemctl daemon-reload
systemctl enable sisparque
systemctl start sisparque

# --- 10. Configura o backup automático diário (via cron) ---
chmod +x "$PASTA_INSTALACAO/scripts/backup_sisparque.sh"
LINHA_CRON="0 3 * * * root bash $PASTA_INSTALACAO/scripts/backup_sisparque.sh"
ARQUIVO_CRON="/etc/cron.d/sisparque_backup"
echo "$LINHA_CRON" > "$ARQUIVO_CRON"
chmod 644 "$ARQUIVO_CRON"
echo ">> Backup automático configurado: todo dia às 3h da manhã, em $PASTA_INSTALACAO/backups/"
echo ">> Mantém os últimos 30 dias automaticamente (backups mais antigos são apagados sozinhos)."

# Faz um primeiro backup imediato, só pra confirmar que está tudo funcionando
bash "$PASTA_INSTALACAO/scripts/backup_sisparque.sh" || true

sleep 2
echo ""
echo "============================================================"
if systemctl is-active --quiet sisparque; then
    echo " SISPARQUE instalado e RODANDO como serviço permanente!"
    echo " Acesse via navegador em: http://$(hostname -I | awk '{print $1}'):5000"
else
    echo " ATENÇÃO: o serviço não subiu. Rode para ver o erro exato:"
    echo "   sudo systemctl status sisparque"
    echo "   sudo journalctl -u sisparque -n 50 --no-pager"
fi
echo ""
echo " Backup automático: todo dia às 3h, em $PASTA_INSTALACAO/backups/"
echo ""
echo " Comandos úteis:"
echo "   sudo systemctl status sisparque   (ver se está rodando)"
echo "   sudo systemctl restart sisparque  (reiniciar)"
echo "   sudo systemctl stop sisparque     (parar)"
echo "   sudo journalctl -u sisparque -f   (ver logs em tempo real)"
echo "============================================================"
