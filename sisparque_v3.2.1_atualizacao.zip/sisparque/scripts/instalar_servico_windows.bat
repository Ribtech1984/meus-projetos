@echo off
REM ============================================================
REM  Instala o SISPARQUE como Servico do Windows, usando o NSSM.
REM  Rode este arquivo como ADMINISTRADOR (botao direito > Executar
REM  como administrador).
REM
REM  Antes de rodar, ajuste as 3 linhas abaixo (CAMINHO_PYTHON,
REM  CAMINHO_PROJETO, CAMINHO_NSSM) para o seu computador.
REM ============================================================

REM --- AJUSTE AQUI ---
SET CAMINHO_PYTHON=C:\SISPARQUE\venv\Scripts\python.exe
SET CAMINHO_PROJETO=C:\SISPARQUE\sisparque_py
SET CAMINHO_NSSM=C:\SISPARQUE\nssm\nssm.exe
REM --------------------

echo Instalando o servico SISPARQUE...
"%CAMINHO_NSSM%" install SISPARQUE "%CAMINHO_PYTHON%" "%CAMINHO_PROJETO%\serve_waitress.py"

echo Configurando pasta de trabalho...
"%CAMINHO_NSSM%" set SISPARQUE AppDirectory "%CAMINHO_PROJETO%"

echo Configurando reinicio automatico em caso de falha...
"%CAMINHO_NSSM%" set SISPARQUE AppExit Default Restart
"%CAMINHO_NSSM%" set SISPARQUE AppRestartDelay 5000

echo Configurando nome de exibicao e descricao...
"%CAMINHO_NSSM%" set SISPARQUE DisplayName "SISPARQUE - Sistema de Inventario CTecCFN"
"%CAMINHO_NSSM%" set SISPARQUE Description "Sistema de inventario da Assessoria de TI. Acesse via navegador em http://localhost:5000"

echo Configurando log de saida (util para depuracao)...
"%CAMINHO_NSSM%" set SISPARQUE AppStdout "%CAMINHO_PROJETO%\sisparque_servico.log"
"%CAMINHO_NSSM%" set SISPARQUE AppStderr "%CAMINHO_PROJETO%\sisparque_servico_erro.log"

echo Configurando inicio automatico com o Windows...
"%CAMINHO_NSSM%" set SISPARQUE Start SERVICE_AUTO_START

echo.
echo ============================================================
echo  Servico "SISPARQUE" instalado!
echo  Para iniciar agora:   nssm start SISPARQUE
echo  Para parar:           nssm stop SISPARQUE
echo  Para remover:         nssm remove SISPARQUE confirm
echo  Ou use o "services.msc" do Windows para gerenciar visualmente.
echo ============================================================
pause
