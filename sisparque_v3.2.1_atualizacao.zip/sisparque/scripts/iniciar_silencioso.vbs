' ============================================================
'  Inicia o SISPARQUE em segundo plano, SEM abrir janela de
'  console nenhuma (nem CMD, nem PowerShell) e SEM precisar
'  de NSSM, serviço do Windows, ou instalar nada extra.
'
'  Como funciona: usa o "pythonw.exe" (que já vem instalado
'  junto com o Python normal) em vez do "python.exe" — a única
'  diferença entre os dois é que o pythonw.exe NUNCA abre uma
'  janela preta, mesmo rodando um servidor web. É o jeito mais
'  simples e mais "invisível" de deixar isso rodando, sem
'  levantar suspeita nenhuma de antivírus (é só o interpretador
'  Python padrão, sem compilar nada, sem empacotar nada).
'
'  COMO USAR:
'  1) Ajuste as duas linhas "CAMINHO_..." abaixo pro seu PC.
'  2) Dê duplo clique neste arquivo pra testar — nenhuma janela
'     deve aparecer, mas o sistema já estará no ar.
'  3) Pra iniciar sozinho com o Windows: aperte Win+R, digite
'     shell:startup, e coloque um ATALHO deste arquivo .vbs
'     dentro da pasta que abrir. Pronto — todo boot do Windows
'     já sobe o SISPARQUE em segundo plano, sem CMD, sem nada.
' ============================================================

CAMINHO_PYTHONW = "C:\SISPARQUE\venv\Scripts\pythonw.exe"
CAMINHO_SCRIPT  = "C:\SISPARQUE\sisparque_py\serve_waitress.py"
PASTA_PROJETO   = "C:\SISPARQUE\sisparque_py"

Set objShell = CreateObject("WScript.Shell")
objShell.CurrentDirectory = PASTA_PROJETO
comando = """" & CAMINHO_PYTHONW & """ """ & CAMINHO_SCRIPT & """"

' O "0" no final = janela oculta. O "False" = não espera terminar (roda em segundo plano).
objShell.Run comando, 0, False
