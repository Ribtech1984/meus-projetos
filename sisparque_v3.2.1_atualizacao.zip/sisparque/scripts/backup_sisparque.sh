#!/usr/bin/env bash
# ============================================================
# Faz backup do banco de dados do SISPARQUE (sisparque.db).
#
# Usa "sqlite3 .backup" em vez de copiar o arquivo direto — isso
# é seguro mesmo com o sistema rodando e alguém salvando algo
# bem naquele instante (evita backup corrompido/incompleto).
#
# Mantém os últimos 30 backups diários e apaga os mais antigos
# automaticamente, pra não lotar o disco com o tempo.
#
# Rodado sozinho todo dia de madrugada via cron (configurado
# automaticamente pelo instalar_servico_linux.sh).
# ============================================================
set -e

PASTA_SISPARQUE="/opt/sisparque"
BANCO="$PASTA_SISPARQUE/sisparque.db"
PASTA_BACKUPS="$PASTA_SISPARQUE/backups"
DATA=$(date +%Y-%m-%d_%H-%M-%S)
DIAS_PARA_MANTER=30

mkdir -p "$PASTA_BACKUPS"

if [ ! -f "$BANCO" ]; then
    echo "$(date): banco $BANCO não encontrado, nada pra fazer backup ainda." >> "$PASTA_BACKUPS/backup.log"
    exit 0
fi

DESTINO="$PASTA_BACKUPS/sisparque_$DATA.db"

if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "$BANCO" ".backup '$DESTINO'"
else
    cp "$BANCO" "$DESTINO"
fi

echo "$(date): backup criado em $DESTINO" >> "$PASTA_BACKUPS/backup.log"

find "$PASTA_BACKUPS" -name "sisparque_*.db" -mtime +$DIAS_PARA_MANTER -delete

# Trilha de auditoria (arquivo separado desde a versão 4.6)
AUDITORIA="$PASTA_SISPARQUE/auditoria.db"
if [ -f "$AUDITORIA" ]; then
    DEST_AUD="$PASTA_BACKUPS/auditoria_$DATA.db"
    if command -v sqlite3 >/dev/null 2>&1; then
        sqlite3 "$AUDITORIA" ".backup '$DEST_AUD'"
    else
        cp "$AUDITORIA" "$DEST_AUD"
    fi
    echo "$(date): backup da auditoria criado em $DEST_AUD" >> "$PASTA_BACKUPS/backup.log"
    find "$PASTA_BACKUPS" -name "auditoria_*.db" -mtime +$DIAS_PARA_MANTER -delete
fi
