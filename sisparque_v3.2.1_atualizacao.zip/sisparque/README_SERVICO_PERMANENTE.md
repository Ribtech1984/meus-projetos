# SISPARQUE — Rodando Permanentemente, Sem CMD, Sem Bloqueio do Kaspersky

Este guia resolve exatamente o que você pediu: o sistema fica de pé 24h/7,
inicia sozinho com o Windows, você fecha o CMD e ele continua rodando, e a
forma como isso é feito foi escolhida **especificamente** para não acionar
o Kaspersky Endpoint Security da Marinha.

## Por que NÃO vamos gerar um .exe (PyInstaller)

Você mencionou "deixar o Python executável" — mas preciso ser direto com
você sobre um ponto técnico importante: transformar o SISPARQUE num único
arquivo `.exe` (com PyInstaller, cx_Freeze, etc.) é exatamente o tipo de
coisa que mais aciona falso-positivo de antivírus corporativo. Esses
compiladores empacotam o interpretador Python inteiro dentro de um binário
novo, não assinado digitalmente, que se autoextrai na memória — isso é
literalmente o comportamento que um heurístico de antivírus (Kaspersky
incluso) foi treinado pra desconfiar, porque é o mesmo padrão que malware
empacotado usa.

**A solução que reduz esse risco de verdade é o oposto**: usar o Python
já instalado no seu computador (o `python.exe` oficial, assinado pela
Python Software Foundation, que o Kaspersky já reconhece) rodando o script
`.py` como está, gerenciado por um **serviço do Windows** — sem compilar
nada, sem empacotar nada. Do ponto de vista do Windows, "SISPARQUE" vira um
serviço comum, igual a qualquer outro que já roda em segundo plano no seu
PC, e o processo real é só `python.exe serve_waitress.py`, que é muito mais
fácil de whitelistar e muito menos suspeito.

## O que muda tecnicamente

- **Antes**: `python app.py` → servidor de desenvolvimento do Flask →
  precisa do CMD aberto → morre se fechar a janela.
- **Depois**: `python serve_waitress.py` → servidor de produção (Waitress,
  puro Python) → roda dentro de um **Serviço do Windows** → inicia sozinho
  quando o Windows liga → continua rodando mesmo sem ninguém logado →
  reinicia sozinho se cair.

## Passo a passo (Windows 11) — MÉTODO SIMPLES (recomendado)

Como o NSSM te deu erro, vamos pelo caminho mais simples possível: nenhuma
instalação extra, nenhum serviço do Windows, só um truque do próprio Python
que já está no seu PC.

**Como funciona**: todo Python vem com dois programas — `python.exe` (abre
janela preta, é o que você vem usando) e `pythonw.exe` (idêntico, mas
**nunca abre janela nenhuma**, nem preta nem nada). Vamos usar o
`pythonw.exe` pra rodar o SISPARQUE totalmente invisível, e colocar um
atalho na pasta de Inicialização do Windows pra ele subir sozinho todo
boot — sem CMD, sem PowerShell, sem instalar nada, sem admin.

### 1. Ajuste o arquivo `scripts\iniciar_silencioso.vbs`

Abra esse arquivo com o Bloco de Notas e troque as 3 primeiras linhas
pelos caminhos reais do seu PC:

```vbs
CAMINHO_PYTHONW = "C:\SISPARQUE\venv\Scripts\pythonw.exe"
CAMINHO_SCRIPT  = "C:\SISPARQUE\sisparque_py\serve_waitress.py"
PASTA_PROJETO   = "C:\SISPARQUE\sisparque_py"
```
Se seu venv está em `D:\Downloads\sisparque_py\venv`, por exemplo, o
`pythonw.exe` fica em `D:\Downloads\sisparque_py\venv\Scripts\pythonw.exe`.

### 2. Instale o Waitress (se ainda não instalou)

```
venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Teste com um duplo clique

Dê duplo clique em `iniciar_silencioso.vbs`. **Nenhuma janela deve
aparecer** — isso é esperado, é assim mesmo que funciona. Espere uns 3
segundos e abra o navegador em `http://localhost:5000`. Se o SISPARQUE
carregar, funcionou.

### 4. Faça ele iniciar sozinho com o Windows

Aperte `Win + R`, digite `shell:startup` e aperte Enter — isso abre a
pasta de Inicialização do Windows. Copie o arquivo `iniciar_silencioso.vbs`
pra dentro dessa pasta (ou crie um atalho dele lá).

Pronto. Todo boot do Windows, esse script roda sozinho, sem nenhuma janela,
sem ninguém precisar fazer login pra iniciar (se você configurar login
automático) — e o SISPARQUE já fica disponível na rede.

### 5. Como parar

Como não tem janela pra fechar, use o `scripts\parar_sisparque.bat` (ajuste
o caminho `CAMINHO_PROJETO` dentro dele primeiro, igual fez no `.vbs`). Ele
lê o processo certo e encerra só ele — não mexe em outros programas.

### 6. Como reiniciar (depois de atualizar o sistema, por exemplo)

Rode `parar_sisparque.bat`, espere terminar, e dê duplo clique de novo em
`iniciar_silencioso.vbs`.

---

## Alternativa: Serviço do Windows via NSSM (mais robusto, mas mais chato de configurar)

Se no ambiente da Marinha (com mais controle de administrador) você quiser
algo mais "oficial" — que apareça em `services.msc`, reinicie sozinho se
cair, etc — o NSSM ainda é uma opção válida. Segue o passo a passo abaixo.
Mas pro seu teste em casa agora, o método silencioso acima já resolve.

### 1. Baixe o NSSM

NSSM ("the Non-Sucking Service Manager") é uma ferramenta gratuita,
amplamente usada há mais de 15 anos por administradores Windows
exatamente pra isso: transformar qualquer programa/script num serviço do
Windows, sem precisar programar nada em C#/.NET. Baixe em:
https://nssm.cc/download (pegue a versão `nssm-2.24.zip` ou mais recente,
pasta `win64`).

Extraia o `nssm.exe` para, por exemplo, `C:\SISPARQUE\nssm\nssm.exe`.

### 2. Organize as pastas

```
C:\SISPARQUE\
  ├── venv\                  (ambiente virtual Python, já criado antes)
  ├── sisparque_py\          (o projeto, com app.py, serve_waitress.py, etc.)
  └── nssm\nssm.exe
```

Se seu projeto já está em outro lugar (ex: `D:\Downloads\sisparque_py`),
sem problema — só ajuste os caminhos no próximo passo.

### 3. Edite e rode o instalador do serviço

Abra `scripts\instalar_servico_windows.bat` num editor de texto (Bloco de
Notas mesmo) e ajuste as 3 primeiras linhas com os caminhos reais do seu
computador:

```bat
SET CAMINHO_PYTHON=C:\SISPARQUE\venv\Scripts\python.exe
SET CAMINHO_PROJETO=C:\SISPARQUE\sisparque_py
SET CAMINHO_NSSM=C:\SISPARQUE\nssm\nssm.exe
```

Depois, clique com o botão direito no arquivo `.bat` → **"Executar como
administrador"**. Ele vai criar o serviço `SISPARQUE` configurado para:
- Iniciar automaticamente com o Windows
- Reiniciar sozinho se o processo cair
- Gravar logs em `sisparque_servico.log` (útil se algo der errado)

### 4. Inicie o serviço

Ainda no CMD como administrador:
```
C:\SISPARQUE\nssm\nssm.exe start SISPARQUE
```
Ou, mais visual: aperte `Win + R`, digite `services.msc`, ache
**"SISPARQUE - Sistema de Inventario CTecCFN"** na lista, botão direito →
Iniciar.

### 5. Teste o reinício automático

Reinicie o Windows e confira se o SISPARQUE volta sozinho, sem você
precisar abrir nada. Se sim, está pronto para produção.

---

## Kaspersky — o que fazer (e o que eu não posso prometer)

Preciso ser honesto com você aqui: **nenhuma técnica de programação
consegue garantir 100% que um antivírus corporativo nunca vai emitir um
alerta** — isso é uma decisão de política de segurança que fica nas mãos
de quem administra o console do Kaspersky (KSC) na sua rede, não do
desenvolvedor da aplicação. O que eu posso garantir é que a abordagem
acima (Python interpretado direto, sem compilar exe, seja pelo método
silencioso ou pelo NSSM) é a que **minimiza muito** esse risco comparado a
gerar um `.exe` compilado.

Mesmo assim, o procedimento correto e definitivo é pedir para quem
administra o Kaspersky da OM criar uma **exclusão/whitelist** para:

1. A pasta inteira `C:\SISPARQUE\` (ou onde você instalar), tanto para
   verificação em tempo real quanto sob demanda;
2. O processo `python.exe`/`pythonw.exe` quando rodando a partir dessa
   pasta específica;
3. Se o Kaspersky tiver módulo de firewall/rede próprio, liberar a porta
   5000 (ou a porta que você configurar) para tráfego interno.

Isso é feito no console de administração (Kaspersky Security Center) pela
equipe de TI/segurança da rede — é o canal certo e é rápido de fazer numa
vez só, cobrindo o sistema de forma permanente.

---

## Linux — Oracle Linux, Ubuntu, Debian ou qualquer outra distro

Criei um script único (`scripts/instalar_servico_linux.sh`) que funciona
em qualquer distribuição Linux moderna — ele detecta sozinho se o sistema
usa `dnf` (Oracle Linux, RHEL, Fedora) ou `apt` (Ubuntu, Debian) e ajusta
os comandos automaticamente. O resultado final é sempre o mesmo: um
serviço `systemd` chamado `sisparque`, rodando permanentemente, reiniciando
sozinho se cair, sem terminal nenhum precisando ficar aberto.

### Como usar

1. Copie a pasta `sisparque_py` inteira pro servidor Linux (via `scp`,
   `rsync`, ou como preferir).
2. No servidor, entre na pasta e rode:
   ```bash
   cd sisparque_py
   sudo bash scripts/instalar_servico_linux.sh
   ```
3. Pronto. O script sozinho: instala o Python se precisar, copia o
   projeto pra `/opt/sisparque`, cria um usuário de serviço sem
   privilégios, instala as dependências, gera uma chave secreta aleatória,
   e sobe o serviço já configurado pra iniciar automaticamente com o
   servidor.

### Comandos úteis depois de instalado

```bash
sudo systemctl status sisparque    # ver se está rodando
sudo systemctl restart sisparque   # reiniciar (ex: depois de atualizar)
sudo systemctl stop sisparque      # parar
sudo journalctl -u sisparque -f    # ver os logs em tempo real
```
