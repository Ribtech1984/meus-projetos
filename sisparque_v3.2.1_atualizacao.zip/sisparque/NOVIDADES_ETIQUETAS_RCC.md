# Etiquetas com Nível RCC + QR Code

## O que foi adicionado
- Campo **Nível RCC** (RCC-1 vermelho / RCC-2 amarelo / RCC-3 verde) em
  **Máquinas** e **Switch** — **sem valor padrão nenhum**. O sistema nunca
  decide isso sozinho: fica em branco até você escolher manualmente pra cada
  equipamento (ex: servidores viram RCC-1, estação comum vira RCC-2 ou RCC-3 —
  quem decide é você, na hora de cadastrar/editar).
- Botão **"Gerar Etiqueta (QR Code)"**:
  - Em Máquinas: na tela de Editar Máquina e na coluna Ações da listagem.
  - Em Switch: na coluna Ações da tabela.
  - **Bloqueado se o Nível RCC ainda não foi definido** — mostra um aviso e
    manda você classificar antes, em vez de gerar etiqueta com nível "chutado".
- A etiqueta é **individual** — um PDF de 8cm x 5cm por equipamento, só com o
  Nível RCC daquele equipamento específico (não os três juntos), contendo:
  - Identificação (o `Num da Máquina` CTECCFN-XXXX, ou a `Chave` do switch)
  - Badge colorido do nível RCC daquela etiqueta
  - QR Code com dados focados em **auditoria física** (identificação + RCC +
    número do lacre no momento da impressão) — sem IP/setor/rack, que são
    dados de rede/localização que não ajudam a detectar rompimento de lacre e
    ficam expostos a qualquer um que escaneie a etiqueta fisicamente, sem
    precisar de acesso ao sistema. A ideia: escaneou, viu o lacre que *deveria*
    estar ali; se o lacre físico atual for outro, foi trocado.
  - Sem rodapé de texto e sem nome de usuário (por privacidade e limpeza visual)
- Na **listagem** (Máquinas e Switch): quem ainda não tem Nível RCC definido
  aparece com badge **cinza "Não definido"** (não amarelo, não nada — é
  literalmente "ainda não sei").
- O **filtro "Nível RCC"** sempre mostra as 4 opções fixas — RCC-1, RCC-2,
  RCC-3 e **"Não definido"** — independente do que já está cadastrado. Use
  "Não definido" pra achar rapidinho tudo que ainda falta classificar (ex: os
  servidores que estão na lista e precisam virar RCC-1).

## Sem dependência nova
O QR Code é gerado pelo próprio **ReportLab** (`reportlab.graphics.barcode.qr`),
que já é dependência do projeto — não foi adicionado nenhum pacote novo, então
não precisa mexer em `pacotes_offline/` nem `requirements.txt`.

## Migração de banco já em uso
Não precisa rodar nada manualmente. O mecanismo que já existia no sistema
(`_auto_migrar_colunas_faltantes`, chamado no início da aplicação) detecta a
coluna nova (`nivel_rcc`) e adiciona sozinha nas tabelas `maquinas` e
`switches` na primeira execução após a atualização — sem apagar nada.
Registros antigos ficam com Nível RCC em branco (aparecem como "Não definido")
até você editar cada um e escolher o nível.

## Ajustar o tamanho da etiqueta
Se a impressora de etiquetas usar outro tamanho de rolo, mude as constantes
`LARGURA_ETIQUETA` / `ALTURA_ETIQUETA` no topo de `pdf_reports.py` (em cm).

## Testado
- Cadastro/edição salvando o Nível RCC (Máquina e Switch)
- Migração automática num banco simulando um `sisparque.db` de produção antigo
- Geração dos PDFs de etiqueta + QR Code decodificado de volta com OpenCV
- Bloqueio da geração de etiqueta quando o Nível RCC não foi definido (com
  redirecionamento e aviso)
- Badge cinza "Não definido" na listagem pra quem não tem RCC ainda
- Filtro "Nível RCC" trazendo as 4 opções fixas e filtrando corretamente,
  inclusive "Não definido"

